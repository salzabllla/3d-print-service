export const WA_CONSENT_EXAMPLE='[Nama] setuju biaya Rp[jumlah] lewat WA pada [tanggal dan jam].';
export const WA_CONSENT_NAME_HELP='[Nama] adalah nama pemohon yang mengajukan cetak 3D.';
export const ADMIN_GUIDE_STEPS=[
 {title:'Buka pengajuan',lines:['Buka menu Pengajuan, lalu pilih pengajuan berstatus Pemeriksaan.','Periksa nama, kebutuhan cetak, dan file pemohon.'],link:'/admin/pengajuan',linkLabel:'Buka Pengajuan'},
 {title:'Periksa file dan tentukan biaya',lines:['Buka file STL dan lakukan slicing. Isi berat filamen dan estimasi waktu cetak.','Jika memakai filamen prodi/pengelola, pilih gulungan. Periksa biaya, lalu klik Simpan Penawaran.'],note:'Tarif dihitung otomatis. Jika memberi diskon, isi juga alasannya.',extraTitle:'Gulungan belum bisa dipakai?',extra:'Buka Filamen. Lengkapi harga acuan dan berat awal sesuai data pembelian gulungan.',link:'/admin/filamen',linkLabel:'Buka Filamen'},
 {title:'Minta persetujuan pemohon',lines:['Klik Buka Pesan WhatsApp. Periksa pesannya, lalu kirim kepada pemohon.','Pemohon menyetujui biaya melalui tautan pribadi Cek Status.'],note:'Membuka WhatsApp belum mengirim pesan secara otomatis.',consentExample:true},
 {title:'Jika biaya ditanggung pembimbing',optional:true,lines:['Pemohon mengunggah form bertanda tangan melalui Cek Status.','Unduh form, periksa data serta tanda tangan pemohon dan pembimbing, lalu klik Verifikasi Form.'],note:'Hanya untuk Internal Elektro. Setelah diverifikasi, biaya ditagihkan ke pembimbing.',extraTitle:'Pemohon membayar sendiri?',extra:'Tidak perlu form pembimbing. Lanjut ke langkah berikutnya.'},
 {title:'Mulai cetak',lines:['Saat status Antrean cetak, pilih printer dan gulungan yang akan digunakan.','Klik Mulai Cetak. Filamen untuk antrean dicadangkan otomatis.'],note:'Pemohon yang membawa filamen sendiri tidak perlu gulungan pengelola.',link:'/admin/pengajuan',linkLabel:'Buka Pengajuan'},
 {title:'Catat hasil cetak',lines:['Setelah cetak selesai, periksa hasil dan isi gram aktual yang terpakai.','Centang hasil sudah diperiksa, lalu klik Tandai Siap Diambil. Stok otomatis berkurang sesuai pemakaian.'],extraTitle:'Jika cetak gagal',extra:'Isi filamen yang terpakai dan alasan gagal. Klik Catat Gagal, Kembali ke Antrean untuk menyiapkan cetak ulang.'},
 {title:'Terima dan catat pembayaran',lines:['Saat pemohon mengambil hasil, terima uang tunai atau periksa transaksi QRIS di merchant.','Isi nama pembayar dan nominal yang benar-benar diterima, lalu klik Verifikasi Pembayaran.'],note:'Pembayaran sebagian tetap dicatat. Pemohon yang membayar sendiri perlu melunasi sebelum mengambil hasil.',extraTitle:'Pembimbing yang membayar',extra:'Jika form pembimbing sudah diverifikasi, hasil boleh diserahkan sebelum pembimbing melunasi. Catat pembayaran saat uangnya benar-benar diterima.'},
 {title:'Serahkan hasil cetak',lines:['Setelah hasil diserahkan kepada pemohon, klik Tandai Sudah Diambil.','Invoice lunas dapat diunduh pemohon melalui Cek Status setelah pembayaran lunas diverifikasi.'],note:'Laporan penggunaan ada di Statistik. Uang yang diterima dan bukti transaksi ada di Arus Kas.',link:'/admin/statistik',linkLabel:'Buka Statistik'},
];
export const ADMIN_GUIDE_STATUSES=[
 ['Pemeriksaan','Operator memeriksa file dan menentukan biaya.'],
 ['Persetujuan biaya','Menunggu pemohon menyetujui biaya.'],
 ['Pemeriksaan form','Operator memeriksa form bertanda tangan pembimbing.'],
 ['Antrean cetak','Pengajuan sudah dapat disiapkan untuk dicetak.'],
 ['Sedang dicetak','Printer sedang mengerjakan pengajuan.'],
 ['Siap diambil','Cetak selesai. Hasil belum diserahkan kepada pemohon.'],
 ['Sudah diambil','Hasil sudah diserahkan. Tagihan pembimbing tetap dicek sampai lunas.'],
 ['Ditolak / Dibatalkan','Pengajuan tidak dilanjutkan.'],
];
export const ADMIN_GUIDE_MENUS=[
 ['Pengajuan','Periksa file, tentukan biaya, cetak, dan catat pembayaran.'],
 ['Printer','Lihat printer yang tersedia atau sedang digunakan.'],
 ['Filamen','Catat gulungan, penambahan stok, dan harga acuan. Pemakaian cetak tercatat otomatis.'],
 ['Statistik','Dosen Pembimbing untuk tanggungan pembimbing. Mahasiswa untuk Internal tanpa tanggungan pembimbing. Luar Elektro untuk kebutuhan luar Elektro.'],
 ['Arus Kas','Catat pemasukan lain, pengeluaran, saldo awal, dan bukti transaksi. Pembayaran cetak masuk otomatis setelah diverifikasi.'],
 ['Riwayat','Lihat pengajuan yang sedang dicetak, sudah selesai, ditolak, atau dibatalkan.'],
];
export const guideSeenKey = uid => `hmte-admin-guide-v1:${uid}`;

// Existing completed records retained by the user on 2026-10-30. New requests require a verified form.
export const historicalSupervisorApprovals = Object.freeze({
  "1nMkcnbH6T58Ka9junaV": "Agus Ramelan",
  "3TJFNwJ7TMm42CG89w4m": "Agus Ramelan",
  "KClokj5VTM9MzwFcczpi": "Agus Ramelan",
  "REZDn0g65gzcS8iYwOAD": "Hari Maghfiroh",
  "ejaQjTyXT5Tyh0PvZoTF": "Agus Ramelan",
  "f2393YFFS6Fd2SohsUt3": "Agus Ramelan",
  "fD7RSwhMkzNIWnydcAIA": "Agus Ramelan",
  "j4FoYT75dgicr17epJO4": "Agus Ramelan",
  "lVpf4oVrtbR6ZPBre4Pe": "Agus Ramelan",
  "rDumPcNNvB6ZzQm4MNDM": "Agus Ramelan",
  "xwMJCj7a6lZMPtv5ryCI": "Agus Ramelan"
});

const page = name => `/admin/${name}`;
const menu = (from, to, label, description) => ({
  route: page(from), target: `menu-${to}`, title: `Klik ${label}`,
  text: description, destination: page(to), action: `Buka ${label}`,
});
export const ADMIN_TOUR_STEPS = [
  {route:page('dashboard'),target:'dashboard-summary',title:'Ringkasan bulan ini',text:'Pilih bulan untuk melihat jumlah pengajuan, cetak selesai, dan filamen yang tercatat.'},
  menu('dashboard','pengajuan','Pengajuan','Mulai di sini untuk memeriksa pengajuan yang masuk.'),
  {route:page('pengajuan'),target:'request-list',title:'Periksa pengajuan',text:'Cari nama atau pilih status Pemeriksaan. Tombol Detail membuka file, perhitungan biaya, persetujuan, dan tindakan cetak sesuai tahapnya.'},
  menu('pengajuan','filamen','Filamen','Sebelum menyiapkan cetak, periksa gulungan dan stok yang tersedia.'),
  {route:page('filamen'),target:'filament-stock',title:'Stok dan harga acuan',text:'Gulungan Baru untuk mencatat gulungan. Harga Acuan untuk harga beli dan berat gulungan baru. Stok fisik berkurang otomatis saat cetak diselesaikan dengan gram aktual.'},
  menu('filamen','printer','Printer','Lihat printer yang tersedia atau sedang dipakai.'),
  {route:page('printer'),target:'printer-list',title:'Pantau printer',text:'Status dan pengajuan yang sedang dicetak ada di sini. Jalankan cetak dari Detail Pengajuan setelah biaya disetujui atau form pembimbing diverifikasi.'},
  menu('printer','statistik','Statistik','Buka rekap penggunaan dan unduh laporannya.'),
  {route:page('statistik'),target:'recap-tabs',title:'Pilih rekap yang diperlukan',text:'Dosen Pembimbing untuk biaya ditanggung pembimbing. Mahasiswa untuk kebutuhan Internal lainnya. Luar Elektro untuk kebutuhan di luar Elektro. Pilih periode, lalu Unduh Excel.'},
  menu('statistik','arus-kas','Arus Kas','Catatan uang masuk dan keluar diperiksa di sini.'),
  {route:page('arus-kas'),target:'cash-table',title:'Uang yang benar-benar diterima',text:'Pembayaran terverifikasi masuk otomatis. Tambah Pemasukan untuk hibah atau donasi. Tambah Bukti untuk melampirkan bukti transaksi. Uang sebelum pencatatan diisi sebagai saldo awal.'},
  menu('arus-kas','panduan','Panduan','Buka panduan kerja dari pemeriksaan file sampai hasil diserahkan.'),
  {route:page('panduan'),target:'written-guide',title:'Panduan bisa dibuka lagi',text:'Pilih langkah 1 sampai 8 untuk membaca cara kerja setiap tahap. Tombol Tutorial di atas halaman dapat dipakai lagi oleh semua admin.',action:'Selesai'},
];
export const tourKey = uid => `hmte-admin-tour-v1:${uid}`;
export function readTourProgress(uid, storage) {
  if (!uid) return null;
  try {
    const data=JSON.parse(storage.getItem(tourKey(uid)));
    if (!data || !Number.isInteger(data.index) || data.index<0 || data.index>=ADMIN_TOUR_STEPS.length || !['paused','done','later'].includes(data.status)) return null;
    return {index:data.index,status:data.status};
  } catch { return null; }
}
export function saveTourProgress(uid, progress, storage) {
  if (!uid) return;
  try {storage.setItem(tourKey(uid),JSON.stringify(progress));} catch {/* The tour also works without browser storage. */}
}

export const lecturerReference = [{id:'demo-lecturer',name:'Dosen Contoh'}];

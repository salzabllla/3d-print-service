export const defaultPicIndex = (pics = []) => Math.max(0, pics.findIndex(pic => /\bnabil\b/i.test(pic.name || '')));

export function buildWhatsAppLink(phone, message) {
  const digits = String(phone || '').replace(/[\s()+-]/g, '').replace(/^0/, '62');
  if (!/^62\d{8,13}$/.test(digits)) throw new Error('Nomor WhatsApp tujuan belum valid. Periksa kontak PIC/pemohon.');
  const encoded = encodeURIComponent(message);
  return `https://wa.me/${digits}?text=${encoded}`;
}

export function isValidGoogleDriveLink(url) {
  if (!url) return false;
  return /^https:\/\/(drive\.google\.com|docs\.google\.com)\//.test(url.trim());
}

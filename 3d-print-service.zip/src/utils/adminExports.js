import { cashEvidenceLink } from './cashEvidence.js';
import * as XLSX from 'xlsx';
import { toDate, needLabel } from './billing.js';
import { reportMinutes, reportCost } from './usageReport.js';
import { cashDate } from './cash.js';
import { RECAPS, recapGroups, recapRequests } from './recaps.js';

function sheet(rows, headers, widths, numeric = []) {
  const ws = XLSX.utils.aoa_to_sheet([headers, ...rows], { cellDates: true });
  ws['!cols'] = widths.map(wch => ({ wch }));
  ws['!rows'] = [{ hpt: 22 }, ...rows.map(() => ({ hpt: 19 }))];
  ws['!autofilter'] = { ref: ws['!ref'] };
  for (let r = 1; r <= rows.length; r++) {
    for (const c of numeric) {
      const cell = ws[XLSX.utils.encode_cell({ r, c })];
      if (cell?.t === 'n') cell.z = '#,##0.##';
    }
  }
  return ws;
}

export function usageWorkbook(completed, groups, period='Semua Periode', category='dosen') {
  const wb=XLSX.utils.book_new();
  const keys=new Set(groups.map(g=>g.key));
  const selected=recapRequests(completed,category).filter(r=>keys.has(recapGroups([r],category)[0]?.key));
  const sections=[{label:'DATA LAMA',items:selected.filter(r=>!r.pricingVersion)},{label:'DATA BARU',items:selected.filter(r=>!!r.pricingVersion)}];
  const rows=[['3D Print Service'],['Dikelola oleh Badan Usaha HMTE'],[`Periode pengajuan: ${period}`],[`Rekap ${RECAPS[category].label}`]];
  const headings=[];
  const totalRow=(label,items)=>{
    const summary=recapGroups(items,category);
    return [label,items.length,summary.reduce((n,g)=>n+g.menit,0)/60,items.length&&summary.every(g=>g.tanpaGram===g.jumlah)?'Belum tercatat':summary.reduce((n,g)=>n+g.gram,0),summary.reduce((n,g)=>n+g.nilaiRekap,0)];
  };
  for(const {label,items} of sections){
    headings.push(rows.length);rows.push([label],[category==='dosen'?'Dosen Pembimbing':'Nama pemohon','Cetak selesai','Durasi (jam)','Gram tercatat (g)','Nilai rekap (Rp)']);
    const summary=recapGroups(items,category);
    if(!summary.length)rows.push(['Belum ada data']);
    for(const g of summary)rows.push([g.nama,g.jumlah,g.menit/60,g.tanpaGram===g.jumlah?'Belum tercatat':g.gram,g.nilaiRekap]);
    rows.push(totalRow('TOTAL '+label,items),[]);
  }
  headings.push(rows.length);rows.push(totalRow('TOTAL KESELURUHAN',selected),[],['Data lama: sampai 1 jam gratis, di atas 1 jam seluruh durasi x Rp1.000/jam.'],['Data baru memakai biaya tersimpan. Nilai rekap bukan pemasukan kas.'],['Gram kosong berarti belum tercatat. Durasi berdasarkan estimasi sistem.'],[]);
  for(const {label,items} of sections){
    headings.push(rows.length);rows.push(['RINCIAN '+label],[category==='dosen'?'Dosen Pembimbing':'Nama pemohon','Tanggal pengajuan','Estimasi (menit)','Gram tercatat (g)','Nilai rekap (Rp)','Kode pengajuan','Nama pemohon','Kebutuhan','Keperluan','Sumber filamen','Dasar biaya','Durasi (jam)']);
    if(!items.length)rows.push(['Belum ada data']);
    for(const r of items){const g=recapGroups([r],category)[0],cost=reportCost(r),minutes=reportMinutes(r);rows.push([g.nama,toDate(r.createdAt),minutes,r.aktualGram??r.beratGram??null,cost.amount,r.trackingCode,r.nama,needLabel(r),r.keperluan,r.sumberFilamen||'Belum tercatat',cost.basis,minutes===null?null:minutes/60]);}
    rows.push([]);
  }
  const ws=XLSX.utils.aoa_to_sheet(rows,{cellDates:true});
  ws['!cols']=[34,20,18,22,23,29,36,20,25,22,29,16].map(wch=>({wch}));
  ws['!rows']=rows.map((_,r)=>({hpt:headings.includes(r)?24:20}));
  for(let r=0;r<rows.length;r++)for(let c=0;c<rows[r].length;c++){
    const cell=ws[XLSX.utils.encode_cell({r,c})];
    if(cell?.t==='n')cell.z='#,##0.##';
    if(cell?.t==='d')cell.z='dd mmm yyyy';
  }
  XLSX.utils.book_append_sheet(wb,ws,'Penggunaan');
  return wb;
}

export function cashWorkbook(items) {
  const headers = ['Tanggal', 'Kode pengajuan / ref', 'Nama', 'Pembayar', 'Kategori', 'Uraian', 'Metode', 'Masuk', 'Keluar', 'Saldo', 'Link bukti', 'Operator', 'Biaya awal', 'Diskon', 'Keterangan diskon', 'Jasa cetak', 'Estimasi bahan', 'Subsidi Prodi'];
  const rows = items.map(r => [cashDate(r), r.trackingCode || r.id, r.nama, r.pembayar || '', r.kategori, r.uraian, r.metode, r.masuk, r.keluar, r.saldo, cashEvidenceLink(r), r.operator, r.biayaAwal??'', r.diskon??'', r.alasanDiskon||'', r.biayaJasa??'', r.biayaBahan??'', r.subsidiProdi??'']);
  const wb = XLSX.utils.book_new();
  const ws=sheet(rows, headers, [20, 28, 28, 28, 24, 35, 12, 18, 18, 18, 35, 26,18,18,35,18,18,18], [7, 8, 9,12,13,15,16,17]);
  rows.forEach((row,index)=>{if(/^https:\/\//.test(row[10]))ws[`K${index+2}`].l={Target:row[10],Tooltip:'Buka bukti (khusus admin)'};});
  XLSX.utils.book_append_sheet(wb, ws, 'Arus Kas');
  return wb;
}

export function filamentWorkbook(lots, moves) {
  const wb = XLSX.utils.book_new();
  const stock = lots.map(l => [l.nama, l.pemilik === 'prodi' ? 'Prodi' : 'HMTE / Pengelola', l.bahan, l.warna, l.gram, l.reserved || 0, l.gram - (l.reserved || 0),l.beratAwalGram??'',l.hargaGulungan??'',l.beratAwalGram>0&&Number.isFinite(l.hargaGulungan)?l.hargaGulungan/l.beratAwalGram:'']);
  const history = moves.map(m => [toDate(m.createdAt), m.nama, m.jenis, m.delta, m.reservedDelta || 0, m.trackingCode || '', m.alasan, m.operator]);
  XLSX.utils.book_append_sheet(wb, sheet(stock, ['Gulungan', 'Pemilik', 'Bahan', 'Warna', 'Sisa fisik (g)', 'Alokasi antrean (g)', 'Tersedia (g)','Berat saat baru (g)','Harga gulungan (Rp)','Harga acuan / g'], [28, 24, 15, 18, 20, 22, 20,22,24,20], [4, 5, 6,7,8,9]), 'Stok Filamen');
  XLSX.utils.book_append_sheet(wb, sheet(history, ['Tanggal', 'Gulungan', 'Jenis', 'Perubahan stok (g)', 'Perubahan alokasi (g)', 'Kode', 'Alasan', 'Operator'], [22, 28, 25, 23, 25, 28, 48, 30], [3, 4]), 'Riwayat Perubahan');
  return wb;
}

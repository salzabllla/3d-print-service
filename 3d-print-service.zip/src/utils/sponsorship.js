import { isExternal } from './billing.js';

export const SPONSOR_FORM_URL = '/forms/permohonan-biaya-pembimbing.docx';
export const hasQuote = r => Number.isFinite(r.totalBiaya) && r.totalBiaya >= 0 && ['quoted','approved'].includes(r.quoteStatus);
export const sponsorApproved = r => !isExternal(r) && r.penanggungBiaya === 'pembimbing' && r.formPembimbingStatus === 'verified';
export const canApplySponsorship = r => !!r.pricingVersion && (!r.biayaBahanOtomatis || (r.status==='menunggu' && r.customerDecision!=='accepted' && r.quoteStatus==='quoted')) && !isExternal(r) && !!r.dosenId && !['paid','waived'].includes(r.paymentStatus) && hasQuote(r) && !['ditolak','dibatalkan'].includes(r.status) && !sponsorApproved(r);
export function sponsorshipMatches(form,r) {
  return !!form && form.totalBiaya === r.totalBiaya && form.dosenId === r.dosenId && form.customerRevision === (r.customerRevision||0) && (form.quoteUpdatedAt?.toMillis?.()||0) === (r.quoteUpdatedAt?.toMillis?.()||0);
}

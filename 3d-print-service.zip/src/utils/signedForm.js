export const MAX_SIGNED_FORM_BYTES = 600 * 1024;
export function signedFormType(bytes) {
 if(bytes[0]===0x25&&bytes[1]===0x50&&bytes[2]===0x44&&bytes[3]===0x46&&bytes[4]===0x2d)return 'application/pdf';
 if([137,80,78,71,13,10,26,10].every((value,index)=>bytes[index]===value))return 'image/png';
 if(bytes[0]===255&&bytes[1]===216&&bytes[2]===255)return 'image/jpeg';
 throw new Error('Gunakan file PDF, JPG, atau PNG.');
}
export async function prepareSignedForm(file,{label='form bertanda tangan',defaultName='Form Pembimbing'}={}) {
 if(!file||!Number.isInteger(file.size)||file.size<=0)throw new Error(`Pilih file ${label}.`);
 if(file.size>MAX_SIGNED_FORM_BYTES)throw new Error('Maksimal 600 KB. Untuk file lebih besar, gunakan tautan Google Drive.');
 const bytes=new Uint8Array(await file.arrayBuffer());
 if(bytes.length!==file.size)throw new Error('File tidak terbaca lengkap. Pilih ulang file.');
 const type=signedFormType(bytes),extension=type==='application/pdf'?'pdf':type==='image/png'?'png':'jpg';
 const stem=String(file.name||defaultName).replace(/\.[^.]+$/,'').replace(/[^\p{L}\p{N} ._-]/gu,'').trim().slice(0,100)||defaultName;
 return {name:`${stem}.${extension}`,type,size:bytes.length,bytes};
}

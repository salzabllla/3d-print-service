import { isExternal, includeInSupervisorReport, groupSupervisors } from './billing.js';
export const RECAPS={
 dosen:{label:'Dosen Pembimbing',hint:'Biaya ditanggung pembimbing setelah form diverifikasi. Termasuk data lama Agus Ramelan dan Hari Maghfiroh.'},
 mahasiswa:{label:'Mahasiswa',hint:'Pengajuan Internal Elektro tanpa tagihan pembimbing. Nama dosen tidak dijadikan penanggung biaya.'},
 luar:{label:'Luar Elektro',hint:'Kebutuhan luar Elektro, direkap menurut nama pemohon.'},
};
export const validRecap = value => Object.hasOwn(RECAPS,value||'');
export const requestRecap = r => isExternal(r)?'luar':includeInSupervisorReport(r)?'dosen':'mahasiswa';
export const recapRequests = (requests,category='dosen') => requests.filter(r=>r.status==='selesai'&&requestRecap(r)===category);
export const recapGroups = (requests,category='dosen') => groupSupervisors(recapRequests(requests,category),{byApplicant:category!=='dosen'});

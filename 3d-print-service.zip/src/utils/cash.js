import { toDate } from './billing.js';

export const INCOME_CATEGORIES = ['Hibah', 'Donasi', 'Pemasukan lainnya'];
export const EXPENSE_CATEGORIES = ['Maintenance', 'Pembelian filamen', 'Operator', 'Kontribusi HMTE', 'Biaya QRIS', 'Lainnya'];
export function dateKey(value = new Date()) {
  const d = toDate(value);
  return d && !Number.isNaN(d.getTime()) ? `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}` : '';
}
export const cashDateKey = r => r.transactionDate || dateKey(r.createdAt);
export const cashDate = r => cashDateKey(r) ? new Date(`${cashDateKey(r)}T00:00:00`) : null;
export function validDate(value) {
  return typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value) && dateKey(new Date(`${value}T00:00:00`)) === value;
}
export function cashRows(items, opening) {
  let balance = opening?.amount ?? 0;
  return [...items].filter(r => !opening?.date || cashDateKey(r) >= opening.date)
    .sort((a,b) => cashDateKey(a).localeCompare(cashDateKey(b)) || (toDate(a.createdAt)?.getTime() || 0) - (toDate(b.createdAt)?.getTime() || 0) || a.id.localeCompare(b.id))
    .map(r => { balance += Number(r.masuk || 0) - Number(r.keluar || 0); return {...r, saldo: opening ? balance : null}; });
}
export function manualCashPayload(kind, data) {
  const income = kind === 'income';
  const categories = income ? INCOME_CATEGORIES : EXPENSE_CATEGORIES;
  if (!['income','expense'].includes(kind) || !data.nama?.trim() || data.nama.trim().length > 200 || !data.uraian?.trim() || data.uraian.trim().length > 1000 || !categories.includes(data.kategori) || !['tunai','qris','lainnya'].includes(data.metode) || !validDate(data.transactionDate) || !Number.isSafeInteger(data.nominal) || data.nominal <= 0 || data.nominal > 1e12) throw new Error('Lengkapi tanggal, nama/sumber, kategori, keterangan, metode, dan nominal rupiah yang valid.');
  if (data.bukti && (!/^https:\/\//.test(data.bukti) || data.bukti.length > 1500)) throw new Error('Link bukti harus berupa tautan HTTPS yang valid.');
  return {entryType:`manual-${kind}`, transactionDate:data.transactionDate, nama:data.nama.trim(), kategori:data.kategori, uraian:data.uraian.trim(), metode:data.metode, masuk:income?data.nominal:0, keluar:income?0:data.nominal, bukti:data.bukti?.trim() || ''};
}

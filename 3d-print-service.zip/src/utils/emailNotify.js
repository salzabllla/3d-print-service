import emailjs from '@emailjs/browser';

// Kirim notifikasi email ke PIC (diatur di template EmailJS, lihat README)
// saat ada pengajuan "jadi admin" baru masuk.
export async function notifyNewAdminRequest({ nama, email, peran }) {
  const serviceId = import.meta.env.VITE_EMAILJS_SERVICE_ID;
  const templateId = import.meta.env.VITE_EMAILJS_TEMPLATE_ID;
  const publicKey = import.meta.env.VITE_EMAILJS_PUBLIC_KEY;

  if (!serviceId || !templateId || !publicKey) {
    console.warn('EmailJS belum dikonfigurasi di .env notifikasi email dilewati.');
    return { skipped: true };
  }

  return emailjs.send(
    serviceId,
    templateId,
    {
      nama_pemohon: nama,
      email_pemohon: email,
      peran_diajukan: peran,
      tanggal: new Date().toLocaleString('id-ID'),
    },
    { publicKey }
  );
}

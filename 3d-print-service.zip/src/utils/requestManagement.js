import { isExternal, validateSubmission } from './billing.js';
import { isValidGoogleDriveLink } from './waLink.js';

export const editableFields = ['jenisPemohon','nama','nim','prodi','whatsapp','email','kebutuhan','sumberFilamen','metodePembayaran','dosenId','dosenPembimbing','asalPengguna','keperluan','linkStl','linkScreenshot','catatan','picIndex'];
export const quoteFields = ['beratGram','tarifPerGram','totalBiaya','versiTarif','filamentLotId','rincianVersion','biayaJasa','biayaBahan','subsidiProdi','biayaAwal','diskon','alasanDiskon','quoteUpdatedAt','biayaBahanOtomatis','acuanFilamenId','beratAcuanGulungan','hargaAcuanGulungan','customerDecision','customerQuoteAt','customerQuoteTotal','customerDecisionAt','customerDecisionBy'];
export const canManageRequest = r => ['2026-10-v1','2026-10-v2'].includes(r.pricingVersion) && r.status === 'menunggu' && ['unreviewed','quoted'].includes(r.quoteStatus) && r.paymentStatus === 'unpaid' && !r.printerId && r.formPembimbingStatus!=='verified' && r.customerDecision!=='accepted';
export function editPayload(form, lecturers) {
  const data = Object.fromEntries(editableFields.map(key=>[key, typeof form[key] === 'string' ? form[key].trim() : form[key]]));
  data.nim = (data.nim || '').toUpperCase();
  if(isExternal(data)){data.dosenId='';data.dosenPembimbing='';}
  data.asalPengguna = isExternal(data) ? 'Luar Prodi Teknik Elektro (UKM/Organisasi/Lomba/dll)' : 'Mahasiswa Prodi Teknik Elektro';
  data.catatan ||= '';
  data.picIndex = Number.isInteger(data.picIndex) && data.picIndex >= 0 ? data.picIndex : 0;
  validateSubmission(data,lecturers);
  if(!data.keperluan || data.keperluan.length>500)throw new Error('Isi keperluan cetak (maksimal 500 karakter).');
  if(!isValidGoogleDriveLink(data.linkStl)||!isValidGoogleDriveLink(data.linkScreenshot))throw new Error('Gunakan tautan Google Drive yang valid untuk file STL dan screenshot.');
  for(const [key,max] of Object.entries({nama:200,nim:100,prodi:200,whatsapp:30,email:250,catatan:2000,linkStl:1500,linkScreenshot:1500}))if(data[key]?.length>max)throw new Error(`Isian ${key} terlalu panjang.`);
  return data;
}
export const newManagementKey = () => [...crypto.getRandomValues(new Uint8Array(32))].map(n=>n.toString(16).padStart(2,'0')).join('');
export const isManagementKey = key => /^[a-f0-9]{64}$/.test(key || '');
export function managementUrl(r,key,origin=window.location.origin){
  return `${origin}/cek-status?kode=${encodeURIComponent(r.trackingCode)}#akses=${key}`;
}
export function rememberManagementKey(code,key){
  if(!isManagementKey(key))return false;
  try{localStorage.setItem(`3de-edit:${code}`,key);return true;}catch{return false;}
}
export function savedManagementKey(code){
  try{return localStorage.getItem(`3de-edit:${code}`)||'';}catch{return '';}
}
export function applicantMessage(r){
  const code=r.trackingCode;
  if(r.status==='dibatalkan')return `Pengajuan ${code} atas nama ${r.nama} telah saya batalkan melalui website.\nAlasan: ${r.cancelReason||'Tidak dicantumkan'}.\nTerima kasih.`;
  if(r.customerDecision==='accepted')return `Halo, saya ${r.nama}, pemohon ${code}.\nBiaya cetak sudah saya setujui melalui website. Mohon diproses sesuai antrean. Terima kasih.`;
  if(r.status==='menunggu'&&r.quoteStatus==='quoted')return `Halo, saya ${r.nama}, pemohon ${code}.\nSaya ingin mengonfirmasi biaya cetak yang tertera pada website.\nMohon konfirmasi sebelum dilanjutkan. Terima kasih.`;
  if(r.status==='menunggu'&&r.quoteStatus!=='approved')return `${r.customerRevision?'Pengajuan cetak 3D sudah saya revisi.':'Mengajukan cetak 3D.'}\nKode: ${code}\nNama: ${r.nama}\nMohon diperiksa${r.customerRevision?' kembali':''}, terima kasih.`;
  if(r.status==='selesai')return `Halo, saya ${r.nama}, pemohon ${code}.\nSaya ingin mengonfirmasi pengambilan hasil cetak dan ${r.paymentStatus==='paid'?'nota lunas':'pembayaran'}.\nMohon informasi waktu dan lokasi pengambilan. Terima kasih.`;
  return `Halo, saya ${r.nama}, pemohon ${code}.\nSaya ingin mengonfirmasi pengajuan cetak 3D ini. Terima kasih.`;
}

export function savedManagementEntries(){
 try{return Object.keys(localStorage).filter(k=>k.startsWith('3de-edit:')).slice(-50).map(k=>({code:k.slice(9),key:localStorage.getItem(k)})).filter(e=>isManagementKey(e.key));}catch{return [];}
}

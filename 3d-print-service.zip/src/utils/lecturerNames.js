import { lecturerReference } from '../data/lecturers.js';

const shortNames = {ramelan:'Agus Ramelan',hamka:'Muhammad Hamka Ibrahim','mufti reza':'Mufti Reza Aulia Putra'};
export function lecturerIdentity(request) {
  const original = typeof request.dosenPembimbing === 'string' ? request.dosenPembimbing.trim() : '';
  const clean = original.split(',')[0]
    .replace(/^(?:(?:prof|dr|ir|pak|bapak|bp)\.?\s+)+/i,'')
    .replace(/(?:\s+(?:s\.?\s*t\.?|m\.?\s*t\.?|m\.?\s*eng\.?|m\.?\s*sc\.?))+$/i,'')
    .replace(/[.\s]+$/,'').replace(/\s+/g,' ').trim();
  const lookup = shortNames[clean.toLowerCase()] || clean;
  const known = lecturerReference.find(d=>d.id===request.dosenId) || lecturerReference.find(d=>d.name.toLowerCase()===lookup.toLowerCase());
  return {id:known?.id || request.dosenId || clean.toLowerCase(), name:known?.name || clean, original};
}
export const lecturerName = request => lecturerIdentity(request).name || 'Belum tercatat';

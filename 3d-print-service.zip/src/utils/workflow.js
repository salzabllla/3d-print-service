import { sponsorApproved } from './sponsorship.js';
export const consentAccepted = r => r.customerDecision === 'accepted' && r.customerQuoteTotal === r.totalBiaya && (r.customerQuoteAt?.toMillis?.() ?? r.customerQuoteAt) === (r.quoteUpdatedAt?.toMillis?.() ?? r.quoteUpdatedAt);
export const readyForQueue = r => r.quoteStatus === 'approved' || sponsorApproved(r) || consentAccepted(r);
export function workflowStage(r) {
  if (r.status === 'dibatalkan') return { key:'cancelled', label:'Dibatalkan', next:'Pengajuan tidak dilanjutkan', step:-1 };
  if (r.status === 'ditolak') return { key:'rejected', label:'Ditolak', next:'Pemohon dapat menghubungi operator', step:-1 };
  if (r.status === 'selesai') return r.pickedUp ? { key:'complete', label:'Sudah diambil', next:sponsorApproved(r) && !['paid','waived'].includes(r.paymentStatus) ? 'Pembimbing menyelesaikan tagihan' : 'Pengajuan selesai', step:5 } : { key:'pickup', label:'Siap diambil', next:'Pemohon mengambil hasil cetak', step:4 };
  if (r.status === 'sedang_print') return { key:'printing', label:'Sedang dicetak', next:'Operator menyelesaikan dan memeriksa hasil', step:3 };
  if (r.formPembimbingStatus === 'pending') return { key:'sponsor', label:'Pemeriksaan form', next:'Operator memeriksa form pembimbing', step:1 };
  if (r.formPembimbingStatus === 'revision') return { key:'sponsor', label:'Perbaikan form', next:'Pemohon memperbaiki form pembimbing', step:1 };
  if (readyForQueue(r) || r.status === 'acc') return { key:'queue', label:r.failedPrints>0?'Antrean cetak ulang':'Antrean cetak', next:r.failedPrints>0?'Operator menyiapkan cetak ulang tanpa mengubah biaya':'Operator menyiapkan printer dan filamen', step:2 };
  if (r.quoteStatus === 'quoted') return { key:'decision', label:'Persetujuan biaya', next:'Pemohon memilih cara penyelesaian biaya', step:1 };
  return { key:'review', label:'Pemeriksaan', next:'Operator memeriksa file dan menetapkan biaya', step:0 };
}

export const requestFilterStage = r => !r.pricingVersion&&r.status==='selesai'?'legacy-complete':workflowStage(r).key;

export const WORKFLOW_VARIANT={review:'warning',decision:'warning',sponsor:'warning',queue:'info',printing:'primary',pickup:'primary',complete:'success',rejected:'danger',cancelled:'secondary','legacy-complete':'secondary'};
export const PUBLIC_STAGE_LABEL={review:'Pemeriksaan',decision:'Persetujuan biaya',sponsor:'Pemeriksaan form',queue:'Antrean cetak',printing:'Sedang dicetak',pickup:'Siap diambil',complete:'Sudah diambil',rejected:'Ditolak',cancelled:'Dibatalkan','legacy-complete':'Selesai'};
export const requestBadgeVariant=r=>r?.publicOnly?WORKFLOW_VARIANT[r.stage]||'secondary':r?.pricingVersion?WORKFLOW_VARIANT[workflowStage(r).key]||'secondary':'secondary';
export const publicRequestStatus=(id,r)=>({requestId:id,trackingCode:r.trackingCode,stage:requestFilterStage(r)});

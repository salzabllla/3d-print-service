import { jsPDF } from 'jspdf';
import { autoTable } from 'jspdf-autotable';
import { sponsorApproved, hasQuote } from './sponsorship';
import { lecturerName } from './lecturerNames';
import { invoiceName, rupiah, toDate, isExternal, needLabel, filamentLabel, costLines, paymentSettled, amountReceived, outstandingAmount, paymentMethodLabel } from './billing';
export function invoicePdf(r) {
 if(['dibatalkan','ditolak'].includes(r.status))throw new Error('Pengajuan sudah dibatalkan; invoice tidak berlaku.');
 if(!r.pricingVersion||!hasQuote(r))throw new Error('Invoice belum tersedia; operator perlu menetapkan biaya terlebih dahulu.');
 const paid=paymentSettled(r),waived=r.paymentStatus==='waived',sponsored=sponsorApproved(r); const pdf=new jsPDF();
 const text=(value,x,y,size=10)=>{pdf.setFontSize(size);pdf.text(String(value||'-'),x,y);};
 pdf.setTextColor(0,91,172);text('3D Print Service',16,22,19);pdf.setTextColor(33,37,41);text('Layanan Cetak 3D - Dikelola oleh Badan Usaha HMTE',16,30);
 text(paid?'INVOICE':'TAGIHAN',145,22,20);text(`#${r.trackingCode}`,145,30,12);text(waived?'TANPA BIAYA':paid?'LUNAS':amountReceived(r)>0?'DIBAYAR SEBAGIAN':sponsored?'TAGIHAN PEMBIMBING':'BELUM BAYAR',145,39,9);
 pdf.setDrawColor(0,91,172);pdf.line(16,45,194,45);
 text('DITAGIHKAN KEPADA',16,56);const identity=pdf.splitTextToSize([r.nama,r.prodi,`Kebutuhan: ${needLabel(r)}`,...(isExternal(r)?[]:[`Pembimbing: ${lecturerName(r)}`])].join('\n'),85);pdf.setFontSize(10);pdf.text(identity,16,64);
 text(`Kode: ${r.trackingCode}`,114,56);text(`Tanggal: ${toDate(r.createdAt)?.toLocaleDateString('id-ID')||'-'}`,114,64);text(`Metode: ${paymentMethodLabel(r)}`,114,72);if(paid)text(`Dibayar: ${toDate(r.paidAt)?.toLocaleDateString('id-ID')||'-'}`,114,80);
 const startY=Math.max(96,64+identity.length*5+10);
 text(`${r.beratGram} g | ${filamentLabel(r)} | Tarif awal ${rupiah(r.tarifPerGram)}/g`,16,startY-5,9);
 autoTable(pdf,{startY,head:[['No.','Deskripsi','Jumlah']],body:costLines(r).map(([label,value],i)=>[String(i+1),label,rupiah(value)]),styles:{fontSize:10,cellPadding:4},headStyles:{fillColor:[0,91,172]},columnStyles:{0:{cellWidth:17},2:{cellWidth:42,halign:'right'}},margin:{left:16,right:16,bottom:38}});
 let line=pdf.lastAutoTable.finalY+13;
 if(line>204){pdf.addPage();line=24;}
 for(const [label,value] of [['Biaya awal setelah subsidi',r.biayaAwal??r.totalBiaya],['TOTAL',r.totalBiaya],['Dibayar',amountReceived(r)],['Sisa pembayaran',outstandingAmount(r)]]){text(label,90,line,9);pdf.text(rupiah(value),194,line,{align:'right'});line+=8;}
 const note=waived?'Diskon penuh. Tidak ada pembayaran.':sponsored&&!paid?'Form pembimbing sudah diverifikasi. Biaya ditagihkan kepada pembimbing; invoice belum lunas sampai pembayaran diverifikasi.':'Pembayaran saat pengambilan hasil cetak.';
 pdf.setFontSize(9);const notes=pdf.splitTextToSize(note,178);pdf.text(notes,16,line+7);line+=notes.length*5+7;
 if(r.paymentStatus==='paid'){for(const value of ['Pembayar terakhir: '+(r.pembayar||r.nama),`Diverifikasi operator: ${r.verifiedBy||'-'}`]){const parts=pdf.splitTextToSize(value,178);pdf.text(parts,16,line+7);line+=parts.length*5+7;}}
 text('Terima kasih telah menggunakan layanan cetak 3D Print Service.',16,266,10);if(!isExternal(r))text('Nota lunas dapat diajukan kepada dosen pembimbing/pengampu.',16,273,9);
 return pdf;
}
export function downloadInvoice(r){invoicePdf(r).save(invoiceName(r));}
export async function shareInvoice(r){const file=new File([invoicePdf(r).output('blob')],invoiceName(r),{type:'application/pdf'});if(navigator.canShare?.({files:[file]})){await navigator.share({files:[file],title:`Invoice #${r.trackingCode}`});return true;}downloadInvoice(r);return false;}

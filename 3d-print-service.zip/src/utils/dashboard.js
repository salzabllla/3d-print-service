import { readyForQueue } from './workflow.js';
import { toDate } from './billing.js';
import { RECAPS, recapGroups } from './recaps.js';

export function requestMonth(value) {
  const d = toDate(value);
  if (!d || Number.isNaN(d.getTime())) return '';
  const parts = new Intl.DateTimeFormat('en-US', {timeZone:'Asia/Jakarta',year:'numeric',month:'2-digit'}).formatToParts(d);
  return `${parts.find(p=>p.type==='year').value}-${parts.find(p=>p.type==='month').value}`;
}
export const currentMonth = () => requestMonth(new Date());
export function validMonth(value) { return /^\d{4}-(0[1-9]|1[0-2])$/.test(value || ''); }
export function monthLabel(month) {
  if (!validMonth(month)) return '';
  return new Date(`${month}-01T00:00:00+07:00`).toLocaleDateString('id-ID',{timeZone:'Asia/Jakarta',month:'long',year:'numeric'});
}
export function dashboardSummary(requests, month) {
  if (!validMonth(month)) throw new Error('Pilih bulan yang valid.');
  const monthly=requests.filter(r=>requestMonth(r.createdAt)===month);
  const completed=monthly.filter(r=>r.status==='selesai');
  const states=[['selesai','Selesai','#1D9E75'],['sedang_print','Sedang dicetak','#005BAC'],['acc','Antrean cetak','#7F77DD'],['menunggu','Menunggu','#E9B44C'],['ditolak','Ditolak','#C8626E']].map(([key,label,color])=>({key,label,color,count:monthly.filter(r=>(key==='acc'?r.status==='acc'||r.status==='menunggu'&&readyForQueue(r):key==='menunggu'?r.status==='menunggu'&&!readyForQueue(r):r.status===key)).length}));
  states.push({key:'dibatalkan',label:'Dibatalkan',color:'#6C757D',count:monthly.filter(r=>r.status==='dibatalkan').length});
  const unknown=monthly.length-states.reduce((n,s)=>n+s.count,0);
  if(unknown)states.push({key:'unknown',label:'Status belum tercatat',color:'#9AA3AB',count:unknown});
  const [year,m]=month.split('-').map(Number);
  const trend=Array.from({length:6},(_,i)=>{
    const date=new Date(Date.UTC(year,m-6+i,1));
    const key=`${date.getUTCFullYear()}-${String(date.getUTCMonth()+1).padStart(2,'0')}`;
    return {key,label:monthLabel(key),count:requests.filter(r=>requestMonth(r.createdAt)===key).length};
  });
  const recorded=completed.filter(r=>Number.isFinite(r.aktualGram??r.beratGram)&&(r.aktualGram??r.beratGram)>=0);
  const recaps=Object.fromEntries(Object.keys(RECAPS).map(category=>[category,recapGroups(requests,category)]));
  return {monthly,completed,states,trend,groups:recaps.dosen,recaps,processing:monthly.filter(r=>['menunggu','acc','sedang_print'].includes(r.status)).length,grams:recorded.reduce((n,r)=>n+(r.aktualGram??r.beratGram),0),missingGrams:completed.length-recorded.length,recent:[...monthly].sort((a,b)=>toDate(b.createdAt)-toDate(a.createdAt)).slice(0,5)};
}

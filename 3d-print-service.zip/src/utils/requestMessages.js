import { readyForQueue } from './workflow.js';
import { rupiah, isExternal, needLabel, filamentLabel, costLines, amountReceived, outstandingAmount } from './billing.js';
import { sponsorApproved } from './sponsorship.js';
import { lecturerName } from './lecturerNames.js';
export const statusUrl = r => `${window.location.origin}/cek-status?kode=${encodeURIComponent(r.trackingCode)}`;
export function requestMessage(r, stage, pickup = {}) {
  const code=r.trackingCode;
  const breakdown=costLines(r).map(([label,value])=>`${label}: ${rupiah(value)}`).join('\n');
  if(stage==='cancelled')return `Pengajuan ${code} sudah dibatalkan sesuai permintaan pemohon.\nAlasan: ${r.cancelReason||'Tidak dicantumkan'}\nTerima kasih.`;
  if (stage==='submit') return `Mengajukan cetak 3D.\nKode: ${code}\nNama: ${r.nama}\nKebutuhan: ${needLabel(r)}${isExternal(r)?'':`\nPembimbing/pengampu: ${lecturerName(r)}`}\nFilamen: ${filamentLabel(r)}\nPembayaran: ${r.metodePembayaran === 'qris' ? 'QRIS' : 'Tunai'}\nMohon diperiksa, terima kasih.`;
  if (stage==='quote') return `Halo, pengajuan ${code} sudah diperiksa.\nKebutuhan: ${needLabel(r)}\nFilamen: ${filamentLabel(r)}\nBerat: ${r.beratGram} gram\nTarif: ${rupiah(r.tarifPerGram)}/gram\n${r.rincianVersion===1?`Biaya awal: ${rupiah(r.biayaAwal)}\n${breakdown}\n`:``}Total akhir: ${rupiah(r.totalBiaya)}\nEstimasi cetak: ${r.estimasiMenit} menit\n${sponsorApproved(r)?'Form pembimbing sudah diverifikasi; biaya ditagihkan kepada pembimbing.':isExternal(r)?'Pembayaran saat pengambilan.':'Pembayaran saat pengambilan. Jika keberatan biaya, ajukan form bertanda tangan pembimbing. Setelah diverifikasi operator, cetak dilanjutkan dan biaya ditagihkan ke pembimbing.'}\nBuka tautan pribadi yang sudah disimpan untuk menyetujui biaya atau mengajukan form pembimbing.\n${statusUrl(r)}`;
  if (stage==='retry') return `Hasil cetak pengajuan ${code} sebelumnya belum berhasil. Pengajuan kembali ke antrean cetak ulang. Total biaya tetap ${rupiah(r.totalBiaya)}, tanpa tambahan biaya cetak ulang. Kami kabari setelah hasil siap diambil.\n${statusUrl(r)}`;
  if (stage==='queue') return `Baik, pengajuan ${code} masuk antrean cetak. Kami kabari setelah hasilnya selesai.`;
  if (stage==='ready') return `Cetakan ${code} sudah selesai dan dapat diambil di ${pickup.lokasi || 'lokasi yang disepakati dengan operator'} pada ${pickup.waktu || 'waktu yang disepakati dengan operator'}.\n${sponsorApproved(r)?`Form pembimbing sudah diverifikasi. Hasil dapat diambil tanpa membayar di tempat; biaya ${rupiah(r.totalBiaya)} ditagihkan kepada pembimbing.`:r.paymentStatus==='waived'?'Total akhir Rp0. Tidak ada pembayaran yang perlu dilakukan.':`Total pembayaran ${rupiah(r.totalBiaya)} melalui ${r.metodePembayaran === 'qris' ? 'QRIS' : 'tunai'} saat pengambilan.`} Invoice lunas tersedia setelah pembayaran diverifikasi operator.\nMohon konfirmasi sebelum datang. Terima kasih.\n${statusUrl(r)}`;
  if (stage==='waived') return `Pengajuan ${code} mendapat diskon penuh. Total akhir Rp0, tidak ada pembayaran.\nRincian invoice dapat diunduh melalui Cek Status.\n${statusUrl(r)}`;
  if (stage==='partial') return `Pembayaran pengajuan ${code} sudah dicatat.\nTotal tagihan: ${rupiah(r.totalBiaya)}\nSudah diterima: ${rupiah(amountReceived(r))}\nSisa pembayaran: ${rupiah(outstandingAmount(r))}\nInvoice lunas tersedia setelah pelunasan diverifikasi operator.\n${statusUrl(r)}`;
  if (stage==='paid') return `Pembayaran ${code} sudah diterima. Terima kasih.\nNota lunas dapat diunduh melalui tautan pribadi Cek Status.\n${statusUrl(r)}`;
  if (stage==='rejected') return `Pengajuan ${code} belum dapat diproses.\n${r.alasanPenolakan || 'Silakan hubungi operator.'}`;
  return `Progres pengajuan ${code}: sedang dicetak.\n${statusUrl(r)}`;
}
export function nextMessageStage(r) {
  if(r.status==='dibatalkan')return ['cancelled','Konfirmasi Pembatalan via WA'];
  if(r.paymentStatus==='waived'&&r.status==='selesai')return ['waived','Kirim Rincian via WA'];
  if(r.paymentStatus==='paid') return ['paid','Kirim Nota via WA'];
  if(r.status==='ditolak') return ['rejected','Kabari Penolakan via WA'];
  if(r.status==='selesai'&&amountReceived(r)>0) return ['partial','Kabari Sisa Pembayaran via WA'];
  if(r.status==='selesai') return ['ready','Kabari Pengambilan via WA'];
  if(r.status==='sedang_print') return ['printing','Kabari Progres via WA'];
  if(readyForQueue(r)&&r.failedPrints>0) return ['retry','Kabari Cetak Ulang via WA'];
  if(readyForQueue(r)) return ['queue','Kabari Antrean via WA'];
  if(r.quoteStatus==='quoted') return ['quote','Konfirmasi Biaya via WA'];
  return [null,'Isi berat dan biaya dahulu'];
}

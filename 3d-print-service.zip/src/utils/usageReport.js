export const LEGACY_HOURLY_RATE = 1000;
export function reportMinutes(r) {
  return Number.isFinite(r.estimasiMenit) && r.estimasiMenit > 0 ? r.estimasiMenit : null;
}
export function reportCost(r) {
  if(Number.isFinite(r.totalBiaya) && r.totalBiaya >= 0)return {amount:r.totalBiaya,basis:'Biaya tersimpan'};
  const minutes=reportMinutes(r);
  if(!r.pricingVersion && r.status==='selesai' && minutes!==null){
    return {amount:minutes<=60?0:Math.round(minutes*LEGACY_HOURLY_RATE/60),basis:'Perhitungan lama per jam'};
  }
  return {amount:null,basis:'Belum tercatat'};
}

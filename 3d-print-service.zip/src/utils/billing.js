import { hasFilamentPrice } from './filamentPricing.js';
import { lecturerIdentity } from './lecturerNames.js';
import { reportMinutes, reportCost } from './usageReport.js';
import { historicalSupervisorApprovals } from '../data/historicalSupervisorApprovals.js';
export const RATE_VERSION = '2026-10-v2';
export const RATES = { elektro: { prodi: 300, sendiri: 200 }, luar: { pengelola: 500, sendiri: 300 } };
export const RATE_ROWS = [['Elektro','Prodi',RATES.elektro.prodi],['Elektro','Bawa sendiri',RATES.elektro.sendiri],['Luar Elektro','Pengelola',RATES.luar.pengelola],['Luar Elektro','Bawa sendiri',RATES.luar.sendiri]];
export const rupiah = value => new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(value || 0);
export const isExternal = r => r.kebutuhan ? r.kebutuhan === 'luar' : /luar/i.test(r.asalPengguna || '');
export const needLabel = r => isExternal(r) ? 'Luar Elektro' : r.kebutuhan === 'elektro' || r.asalPengguna ? 'Internal Elektro' : 'Belum tercatat';
export const filamentLabel = r => ({prodi:'Filamen prodi',pengelola:'Filamen pengelola',sendiri:'Bawa sendiri'}[r.sumberFilamen] || 'Belum tercatat');
export const getRate = r => r.kebutuhan && !['elektro','luar'].includes(r.kebutuhan) ? null : RATES[isExternal(r) ? 'luar' : 'elektro'][r.sumberFilamen] ?? null;
export function changeNeed(form, kebutuhan) {
  return {...form,kebutuhan,asalPengguna:kebutuhan==='luar'?'Luar Prodi Teknik Elektro (UKM/Organisasi/Lomba/dll)':'Mahasiswa Prodi Teknik Elektro',sumberFilamen:form.sumberFilamen==='sendiri'?'sendiri':kebutuhan==='luar'?'pengelola':'prodi',dosenId:'',dosenPembimbing:''};
}
export function calculateQuote(r, grams, options={}) {
  const rate = getRate(r);
  if (!Number.isFinite(grams) || grams <= 0 || grams > 100000 || rate === null) throw new Error('Berat atau sumber filamen tidak valid.');
  const biayaAwal=Math.round(grams*rate),biayaBahan=Number(options.biayaBahan??0),diskon=Number(options.diskon??0),alasanDiskon=String(options.alasanDiskon||'').trim();
  if(!Number.isSafeInteger(biayaBahan)||biayaBahan<0||biayaBahan>1e9||(r.sumberFilamen==='sendiri'&&biayaBahan!==0)||(isExternal(r)&&biayaBahan>biayaAwal))throw new Error('Estimasi bahan harus berupa rupiah yang valid. Bawa sendiri tidak dikenai bahan; bahan Luar Elektro termasuk dalam biaya awal.');
  if(!Number.isSafeInteger(diskon)||diskon<0||diskon>biayaAwal||(diskon>0&&!alasanDiskon)||alasanDiskon.length>500)throw new Error('Diskon harus antara 0 dan biaya awal, dengan keterangan (maksimal 500 karakter).');
  const subsidiProdi=!isExternal(r)&&r.sumberFilamen==='prodi'?biayaBahan:0;
  const biayaJasa=isExternal(r)?biayaAwal-biayaBahan:biayaAwal;
  return { beratGram: grams, tarifPerGram: rate, totalBiaya: biayaAwal-diskon, versiTarif: RATE_VERSION,rincianVersion:1,biayaJasa,biayaBahan,subsidiProdi,biayaAwal,diskon,alasanDiskon:diskon?alasanDiskon:'' };
}

export function calculateAutomaticQuote(r, grams, lot, options={}) {
  if(r.sumberFilamen==='sendiri')return {...calculateQuote(r,grams,{...options,biayaBahan:0}),biayaBahanOtomatis:true,acuanFilamenId:'',beratAcuanGulungan:0,hargaAcuanGulungan:0};
  if(!hasFilamentPrice(lot)||lot.pemilik!==r.sumberFilamen)throw new Error('Lengkapi harga acuan dan berat awal gulungan di halaman Filamen.');
  const raw=Math.round(grams*lot.hargaGulungan/lot.beratAwalGram);
  const biayaBahan=raw;
  if(isExternal(r)&&raw>Math.round(grams*getRate(r)))throw new Error('Harga acuan bahan melebihi biaya dari tarif layanan. Periksa harga dan berat gulungan terlebih dahulu.');
  return {...calculateQuote(r,grams,{...options,biayaBahan}),biayaBahanOtomatis:true,acuanFilamenId:lot.id,beratAcuanGulungan:lot.beratAwalGram,hargaAcuanGulungan:lot.hargaGulungan};
}

export function costLines(r) {
  if(r.rincianVersion!==1)return [['Jasa cetak 3D',r.totalBiaya]];
  return [['Jasa cetak 3D',r.biayaJasa],...(r.sumberFilamen==='sendiri'?[]:[['Estimasi bahan filamen',r.biayaBahan]]),...(r.subsidiProdi>0?[['Subsidi Prodi bahan filamen',-r.subsidiProdi]]:[]),...(r.diskon>0?[[`Diskon: ${r.alasanDiskon}`, -r.diskon]]:[])];
}
export const paymentSettled = r => ['paid','waived'].includes(r.paymentStatus);
export const amountReceived = r => Number.isSafeInteger(r.paidAmount)&&r.paidAmount>0?r.paidAmount:0;
export const outstandingAmount = r => r.paymentStatus==='waived'?0:Math.max(0,(r.totalBiaya||0)-amountReceived(r));
export const paymentMethodLabel = r => r.paymentMethods?.length>1?'Tunai + QRIS':r.metodePembayaran==='qris'?'QRIS':'Tunai';
export function validateSubmission(r, lecturers) {
  if (!r.nama?.trim() || !r.prodi?.trim() || !r.email?.trim() || !/^(?:0|62|\+62)\d{8,14}$/.test(r.whatsapp?.replace(/[\s-]/g, '') || '')) throw new Error('Lengkapi identitas dan nomor WhatsApp Indonesia yang valid.');
  if (!['mahasiswa', 'dosen'].includes(r.jenisPemohon) || !['elektro', 'luar'].includes(r.kebutuhan)) throw new Error('Pilih jenis pemohon dan kebutuhan.');
  if (r.jenisPemohon === 'mahasiswa' && !r.nim?.trim()) throw new Error('NIM wajib untuk mahasiswa.');
  if (!isExternal(r) && !r.dosenId) throw new Error('Kebutuhan Elektro wajib memilih dosen pembimbing/pengampu.');
  if (isExternal(r) && (r.dosenId || r.dosenPembimbing)) throw new Error('Pengajuan Luar Elektro tidak memakai dosen pembimbing. Pilih ulang kategori kebutuhan.');
  if (!isExternal(r) && !lecturers.some(d => d.id === r.dosenId && d.name === r.dosenPembimbing)) throw new Error('Pilih dosen dari daftar yang tersedia.');
  if (!['tunai', 'qris'].includes(r.metodePembayaran) || getRate(r) === null) throw new Error('Pilih sumber filamen dan metode pembayaran.');
}
export function includeInSupervisorReport(r) {
  if (isExternal(r)) return false;
  const { name } = lecturerIdentity(r);
  if (!name || name.toLowerCase() === 'belum tercatat') return false;
  return historicalSupervisorApprovals[r.id] === name || (r.formPembimbingStatus === 'verified' && r.penanggungBiaya === 'pembimbing');
}
export function groupSupervisors(requests, {byApplicant=false}={}) {
  const groups = new Map();
  for (const r of requests) {
    const external = isExternal(r);
    const lecturer = lecturerIdentity(r);
    const hasLecturer = !external && !!lecturer.name;
    const identity=r.nim?.trim()?`nim:${r.nim.trim().toLowerCase()}`:r.email?.trim()?`email:${r.email.trim().toLowerCase()}`:`nama:${String(r.nama||r.id||'tanpa-identitas').trim().toLowerCase()}`;
    const name = byApplicant ? r.nama||'Pemohon tanpa nama' : external ? 'Luar Elektro' : hasLecturer ? lecturer.name : 'Belum tercatat';
    const key = byApplicant ? `pemohon:${identity}` : external ? 'luar-elektro' : hasLecturer ? `dosen:${lecturer.id}` : 'unknown';
    const jenis=byApplicant?(external?'Luar Elektro':r.jenisPemohon==='dosen'?'Dosen (bayar sendiri)':'Mahasiswa'):external?'Luar Elektro':hasLecturer?'Dosen Pembimbing':'Belum tercatat';
    if (!groups.has(key)) groups.set(key, { key, nama: name, jenis, mahasiswa: 0, dosen: 0, jumlah: 0, prodi: 0, pengelola: 0, sendiri: 0, gram: 0, tanpaGram: 0,menit:0,tanpaDurasi:0,nilaiRekap:0,biayaHistoris:0,biayaTersimpan:0,tanpaBiaya:0 });
    const g = groups.get(key); g.jumlah++; g[r.jenisPemohon === 'dosen' ? 'dosen' : 'mahasiswa']++;
    const weight = r.aktualGram ?? r.beratGram;
    if (Number.isFinite(weight)) { g.gram += weight; if (['prodi','pengelola','sendiri'].includes(r.sumberFilamen)) g[r.sumberFilamen] += weight; } else g.tanpaGram++;
    const minutes=reportMinutes(r),cost=reportCost(r);
    if(minutes!==null)g.menit+=minutes;else g.tanpaDurasi++;
    if(cost.amount!==null){g.nilaiRekap+=cost.amount;if(cost.basis==='Perhitungan lama per jam')g.biayaHistoris+=cost.amount;else g.biayaTersimpan+=cost.amount;}else g.tanpaBiaya++;
  }
  return [...groups.values()].sort((a,b) => b.jumlah-a.jumlah);
}
// Filename sanitation intentionally removes control characters.
// oxlint-disable-next-line no-control-regex
export function invoiceName(r) { return `Invoice #${String(r.trackingCode || 'pengajuan').replace(/[<>:"/\\|?*\x00-\x1f]/g, '-')}.pdf`; }
export const toDate = value => value?.toDate?.() || (value ? new Date(value) : null);
export function inMonth(date, month) { const d=toDate(date); return !month || (d && !Number.isNaN(d.getTime()) && `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}` === month); }

import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { REQUEST_STATUS_LABEL } from './constants';

function toRows(requests, printers) {
  return requests.map((r) => ({
    Tanggal: r.createdAt?.toDate?.().toLocaleDateString('id-ID') || '-',
    Nama: r.nama,
    NIM: r.nim,
    Printer: printers.find((p) => p.id === r.printerId)?.name || '-',
    Estimasi: r.estimasiStatus === 'belum diketahui' ? 'Belum diketahui' : `${r.estimasiMenit || '-'} menit`,
    Status: REQUEST_STATUS_LABEL[r.status] || r.status,
  }));
}

export function exportRiwayatToExcel(requests, printers) {
  const rows = toRows(requests, printers);
  const ws = XLSX.utils.json_to_sheet(rows);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Riwayat');
  XLSX.writeFile(wb, `riwayat-print-3d-${Date.now()}.xlsx`);
}

export function exportRiwayatToPdf(requests, printers) {
  const rows = toRows(requests, printers);
  const doc = new jsPDF();
  doc.setFontSize(14);
  doc.text('Laporan Penggunaan 3D Print Service', 14, 15);
  autoTable(doc, {
    startY: 22,
    head: [['Tanggal', 'Nama', 'NIM', 'Printer', 'Estimasi', 'Status']],
    body: rows.map((r) => [r.Tanggal, r.Nama, r.NIM, r.Printer, r.Estimasi, r.Status]),
    styles: { fontSize: 8 },
    headStyles: { fillColor: [0, 91, 172] },
  });
  doc.save(`riwayat-print-3d-${Date.now()}.pdf`);
}

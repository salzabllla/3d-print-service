export function filamentPricing(beratAwalGram, hargaGulungan) {
  if(String(beratAwalGram??'').trim()===''||String(hargaGulungan??'').trim()==='')throw new Error('Isi berat awal dan harga acuan gulungan.');
  const weight = Number(beratAwalGram), price = Number(hargaGulungan);
  if (!Number.isFinite(weight) || weight <= 0 || weight > 100000 || !Number.isSafeInteger(price) || price < 0 || price > 1e9) {
    throw new Error('Isi berat bersih gulungan saat baru dan harga acuan yang valid.');
  }
  return { beratAwalGram: weight, hargaGulungan: price };
}
export const hasFilamentPrice = lot => !!lot && Number.isFinite(lot.beratAwalGram) && lot.beratAwalGram > 0 && Number.isSafeInteger(lot.hargaGulungan) && lot.hargaGulungan >= 0;
export const filamentUnitPrice = lot => hasFilamentPrice(lot) ? lot.hargaGulungan / lot.beratAwalGram : null;

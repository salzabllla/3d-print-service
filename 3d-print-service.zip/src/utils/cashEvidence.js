import { prepareSignedForm } from './signedForm.js';
export const cashEvidenceLink = r => r.proofVersion?`https://demo.example.invalid/admin/arus-kas?bukti=${encodeURIComponent(r.id)}`:r.bukti||'';
export function safeEvidenceUrl(value) {
 try{const url=new URL(value);return url.protocol==='https:'&&!url.username&&!url.password&&url.href.length<=1500?url.href:'';}catch{return '';}
}
export async function prepareCashEvidence({kind,file,link='',note=''}) {
 if(!['file','link'].includes(kind)||typeof note!=='string'||note.trim().length>500)throw new Error('Pilih jenis bukti dan isi keterangan maksimal 500 karakter.');
 let prepared;
 if(kind==='file')prepared=await prepareSignedForm(file,{label:'bukti transaksi',defaultName:'Bukti Transaksi'});
 else {
  link=safeEvidenceUrl(link.trim());
  if(!link)throw new Error('Isi tautan bukti HTTPS yang valid.');
 }
 const bytes=prepared?.bytes||new TextEncoder().encode(link);
 const hash=new Uint8Array(await crypto.subtle.digest('SHA-256',bytes));
 return {kind,name:prepared?.name||'Tautan bukti',type:prepared?.type||'',size:prepared?.size||0,link:kind==='link'?link:'',note:note.trim(),contentHash:Array.from(hash,x=>x.toString(16).padStart(2,'0')).join(''),...(prepared?{bytes:prepared.bytes}:{})};
}

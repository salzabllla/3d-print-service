export const REQUEST_STATUS = {
  MENUNGGU: 'menunggu',
  ACC: 'acc',
  DITOLAK: 'ditolak',
  DIBATALKAN: 'dibatalkan',
  SEDANG_PRINT: 'sedang_print',
  SELESAI: 'selesai',
};

export const REQUEST_STATUS_LABEL = {
  [REQUEST_STATUS.MENUNGGU]: 'Menunggu',
  [REQUEST_STATUS.ACC]: 'Diterima',
  [REQUEST_STATUS.DITOLAK]: 'Ditolak',
  [REQUEST_STATUS.DIBATALKAN]: 'Dibatalkan',
  [REQUEST_STATUS.SEDANG_PRINT]: 'Sedang print',
  [REQUEST_STATUS.SELESAI]: 'Selesai',
};

export const REQUEST_STATUS_BADGE_VARIANT = {
  [REQUEST_STATUS.MENUNGGU]: 'warning',
  [REQUEST_STATUS.ACC]: 'success',
  [REQUEST_STATUS.DITOLAK]: 'danger',
  [REQUEST_STATUS.DIBATALKAN]: 'secondary',
  [REQUEST_STATUS.SEDANG_PRINT]: 'primary',
  [REQUEST_STATUS.SELESAI]: 'secondary',
};

export const PRINTER_STATUS = {
  AVAILABLE: 'available',
  IN_USE: 'in_use',
};

export const KEPERLUAN_OPTIONS = [
  'Tugas Kuliah',
  'Skripsi',
  'Tugas Akhir',
  'Capstone',
  'PKM',
  'PKE',
  'MBKM',
  'Lomba',
  'Penelitian',
  'Proyek Dosen',
  'Lainnya',
];

export const ESTIMASI_QUICK_OPTIONS = [
  { label: '30 menit', value: 30 },
  { label: '1 jam', value: 60 },
  { label: '2 jam', value: 120 },
  { label: '4 jam', value: 240 },
];

export const ESTIMASI_STATUS = {
  DIKETAHUI: 'diketahui',
  BELUM_DIKETAHUI: 'belum diketahui',
};

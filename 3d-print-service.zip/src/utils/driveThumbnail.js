// Google Drive mendukung endpoint thumbnail publik untuk file yang di-share
// dengan akses "Anyone with the link can view":
// https://drive.google.com/thumbnail?id=FILE_ID
export function getDriveThumbnail(driveUrl) {
  if (!driveUrl) return null;
  const match = driveUrl.match(/[-\w]{25,}/);
  if (!match) return null;
  return `https://drive.google.com/thumbnail?id=${match[0]}&sz=w200`;
}

// Menghasilkan kode pengajuan unik, contoh: 3DE-20260716-4F2A
export function generateTrackingCode() {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  const random = Math.random().toString(36).substring(2, 6).toUpperCase();
  return `3DE-${y}${m}${d}-${random}`;
}

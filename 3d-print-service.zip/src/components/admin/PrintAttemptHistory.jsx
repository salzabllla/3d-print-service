import { useEffect, useState } from 'react';
import { subscribePrintAttempts } from '../../services/printAttemptService';
import { toDate } from '../../utils/billing';

export default function PrintAttemptHistory({requestId}) {
 const [items,setItems]=useState(null),[error,setError]=useState('');
 useEffect(()=>subscribePrintAttempts(requestId,setItems,e=>setError(e.message)),[requestId]);
 return <details className="workflow-detail card border-0 shadow-sm p-3 mt-3"><summary>Riwayat percobaan cetak</summary><div className="pt-3">
  {error?<p role="alert" className="small text-danger">Riwayat gagal dimuat. {error}</p>:items===null?<p role="status" className="small text-secondary">Memuat riwayat...</p>:!items.length?<p className="small text-secondary mb-0">Belum ada percobaan yang diselesaikan.</p>:<>
   <ol className="small ps-3 mb-0">{items.map(item=><li className="mb-2" key={item.id}><strong>Percobaan {item.attempt}: {item.outcome==='failed'?'Gagal':'Berhasil'}</strong><span className="d-block text-secondary">{toDate(item.finishedAt)?.toLocaleString('id-ID')} · {item.usedGram} g terpakai</span>{item.reason&&<span className="d-block text-break">{item.reason}</span>}</li>)}</ol>
   {items.length===20&&<p className="small text-secondary mb-0">Menampilkan 20 percobaan terakhir.</p>}
  </>}
 </div></details>;
}

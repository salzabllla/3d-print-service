import WhatsAppButton from '../common/WhatsAppButton';
import { getManagementKeyForOperator } from '../../services/requestManagementService';
import { managementUrl } from '../../utils/requestManagement';
import { statusUrl } from '../../utils/requestMessages';
export default function AdminWhatsAppButton({request:r,message,...props}){
 return <WhatsAppButton {...props} phone={r.whatsapp} message={message} prepareMessage={async()=>{const key=await getManagementKeyForOperator(r.id);const privateUrl=managementUrl(r,key);return `${message.replaceAll(statusUrl(r),privateUrl)}${message.includes(statusUrl(r))?'':`\n${privateUrl}`}\nTautan pribadi untuk rincian dan invoice. Jangan dibagikan kepada orang lain.`;}}/>;
}

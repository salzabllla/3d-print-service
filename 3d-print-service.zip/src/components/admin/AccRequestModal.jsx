import { useEffect, useState } from 'react';
import { ESTIMASI_STATUS } from '../../utils/constants';

function toLocalDatetimeInputValue(date) {
  const pad = (n) => String(n).padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

export default function AccRequestModal({ request, printers, onCancel, onConfirm }) {
  const [printerId, setPrinterId] = useState(printers[0]?.id || '');
  const [jamMulai, setJamMulai] = useState(toLocalDatetimeInputValue(new Date()));
  const [estimasiMenit, setEstimasiMenit] = useState(request.estimasiMenit || '');

  const mahasiswaBelumTahu = request.estimasiStatus === ESTIMASI_STATUS.BELUM_DIKETAHUI;

  useEffect(() => {
    if (!mahasiswaBelumTahu && request.estimasiMenit) {
      setEstimasiMenit(request.estimasiMenit);
    }
  }, [request, mahasiswaBelumTahu]);

  const handleSubmit = () => {
    if (!printerId || !jamMulai || !estimasiMenit) return;
    onConfirm({ printerId, jamMulai, estimasiMenit: Number(estimasiMenit) });
  };

  return (
    <div className="modal d-block" style={{ background: 'rgba(0,0,0,0.5)' }} tabIndex="-1">
      <div className="modal-dialog">
        <div className="modal-content">
          <div className="modal-header">
            <h6 className="modal-title fw-bold">ACC Pengajuan {request.nama}</h6>
            <button type="button" className="btn-close" onClick={onCancel} />
          </div>
          <div className="modal-body">
            <div className="mb-3">
              <label className="form-label small">Pilih Printer</label>
              <select className="form-select" value={printerId} onChange={(e) => setPrinterId(e.target.value)}>
                {printers.map((p) => (
                  <option key={p.id} value={p.id}>{p.name}</option>
                ))}
              </select>
            </div>
            <div className="mb-3">
              <label className="form-label small">Jam Mulai</label>
              <input
                type="datetime-local"
                className="form-control"
                value={jamMulai}
                onChange={(e) => setJamMulai(e.target.value)}
              />
            </div>
            <div className="mb-1">
              <label className="form-label small">
                Estimasi waktu print (menit)
                {mahasiswaBelumTahu ? (
                  <span className="text-danger"> mahasiswa belum tahu, wajib kamu isi</span>
                ) : (
                  <span className="text-secondary"> diisi mahasiswa, bisa kamu ubah</span>
                )}
              </label>
              <input
                type="number"
                min="1"
                className="form-control"
                value={estimasiMenit}
                onChange={(e) => setEstimasiMenit(e.target.value)}
                placeholder="Contoh: 120"
              />
            </div>
          </div>
          <div className="modal-footer">
            <button className="btn btn-outline-secondary" onClick={onCancel}>Batal</button>
            <button className="btn text-white" style={{ background: '#005BAC' }} onClick={handleSubmit}>ACC</button>
          </div>
        </div>
      </div>
    </div>
  );
}

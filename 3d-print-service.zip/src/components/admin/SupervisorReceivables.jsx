import { useEffect, useState } from 'react';
import * as XLSX from 'xlsx';
import { subscribeToAllRequests } from '../../services/requestService';
import { rupiah, paymentSettled, outstandingAmount } from '../../utils/billing';
import { sponsorApproved } from '../../utils/sponsorship';
import { lecturerName } from '../../utils/lecturerNames';
import RequestWorkflow from './RequestWorkflow';

export default function SupervisorReceivables() {
  const [requests,setRequests]=useState(null),[error,setError]=useState(''),[selected,setSelected]=useState(null);
  useEffect(()=>subscribeToAllRequests(setRequests,e=>setError(e.message)),[]);
  const rows=(requests||[]).filter(r=>r.status==='selesai'&&sponsorApproved(r)&&!paymentSettled(r));
  const exportExcel=()=>{
    const wb=XLSX.utils.book_new(),ws=XLSX.utils.aoa_to_sheet([['Dosen Pembimbing','Kode Pengajuan','Nama Pemohon','Biaya Awal','Diskon','Total Belum Dibayar'],...rows.map(r=>[lecturerName(r),r.trackingCode,r.nama,r.biayaAwal??r.totalBiaya,r.diskon||0,outstandingAmount(r)])]);
    ws['!cols']=[32,30,32,18,18,22].map(wch=>({wch}));
    XLSX.utils.book_append_sheet(wb,ws,'Tagihan Pembimbing');XLSX.writeFile(wb,'Tagihan Pembimbing 3D Print Service.xlsx');
  };
  return <section className="card border-0 shadow-sm mt-3"><div className="card-body">
    <div className="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-2"><h6 className="fw-bold mb-0">Tagihan Pembimbing Belum Dibayar</h6><button className="btn btn-sm btn-outline-primary" disabled={!rows.length} onClick={exportExcel}>Unduh Tagihan Excel</button></div>
    <p className="small text-secondary">Cetak sudah selesai dan form pembimbing sudah diverifikasi. Sisa tagihan {rupiah(rows.reduce((n,r)=>n+outstandingAmount(r),0))} ini belum masuk saldo kas. Daftar ini mencakup semua periode.</p>
    {error&&<p role="alert" className="text-danger small">{error}</p>}
    <div className="table-responsive"><table className="table table-sm admin-data-table mb-0"><thead className="table-light"><tr><th>Dosen Pembimbing</th><th>Kode</th><th>Pemohon</th><th>Total</th><th>Aksi</th></tr></thead><tbody>{requests===null?<tr><td colSpan={5}>Memuat tagihan...</td></tr>:!rows.length?<tr><td colSpan={5} className="text-secondary">Belum ada tagihan pembimbing yang belum dibayar.</td></tr>:rows.map(r=><tr key={r.id}><td>{lecturerName(r)}</td><td>{r.trackingCode}</td><td>{r.nama}</td><td className="text-nowrap">{rupiah(outstandingAmount(r))}</td><td><button className="btn btn-sm btn-outline-primary" onClick={()=>setSelected(r)}>Periksa Pembayaran</button></td></tr>)}</tbody></table></div>
  </div>{selected&&<RequestWorkflow request={selected} onClose={()=>setSelected(null)}/>}</section>;
}

import { useState } from 'react';
import { finishRequest } from '../../services/requestService';
import { currentPrintAttempt, failPrintRequest } from '../../services/printAttemptService';

export default function PrintRunControls({request:r, printerName, busy, onAction}) {
 const [actual,setActual]=useState(''),[quality,setQuality]=useState(false),[failedGram,setFailedGram]=useState(''),[reason,setReason]=useState('');
 return <>
  <h6 className="fw-bold">Selesaikan dan periksa hasil</h6>
  <p className="small text-secondary">Printer: {printerName}. Biaya tetap mengikuti penawaran yang disetujui.</p>
  {r.failedPrints>0&&<p className="small text-secondary">Percobaan ke-{currentPrintAttempt(r)}. Pemakaian gagal sebelumnya {r.failedGram} g sudah tercatat; isi gram untuk percobaan ini saja.</p>}
  <form onSubmit={e=>{e.preventDefault();onAction(()=>finishRequest(r.id,r.printerId,Number(actual),currentPrintAttempt(r)),'Cetakan selesai dan hasil sudah diperiksa?');}}>
   <fieldset disabled={busy}>
    <label className="form-label small" htmlFor="workflow-actual">Filamen terpakai pada percobaan ini (g)</label>
    <input id="workflow-actual" className="form-control form-control-sm mb-3" type="number" min="0.01" max="100000" step="0.01" required value={actual} placeholder={String(r.beratGram)} onChange={e=>setActual(e.target.value)}/>
    <label className="d-flex align-items-start gap-2 small mb-3"><input type="checkbox" className="form-check-input flex-shrink-0" required checked={quality} onChange={e=>setQuality(e.target.checked)}/>Hasil cetak sudah diperiksa dan siap diserahkan.</label>
    <button className="btn btn-sm btn-primary" disabled={!quality||!(Number(actual)>0)}>Tandai Siap Diambil</button>
   </fieldset>
  </form>
  <details className="workflow-detail mt-3"><summary>Cetakan gagal atau harus dihentikan?</summary>
   <p className="small text-secondary mt-2">Catat pemakaian sebelum mengulang. Stok berkurang sesuai gram ini, sisa alokasi dilepas, dan pengajuan kembali ke antrean. Total biaya tetap.</p>
   <form onSubmit={e=>{e.preventDefault();onAction(()=>failPrintRequest(r,{usedGram:Number(failedGram),reason}),'Catat cetak gagal dan kembalikan ke antrean cetak ulang?');}}>
    <fieldset disabled={busy}>
     <label className="form-label small" htmlFor="failed-grams">Filamen terpakai sebelum gagal (g)</label><input id="failed-grams" className="form-control form-control-sm mb-2" type="number" min="0" max="100000" step="0.01" required value={failedGram} onChange={e=>setFailedGram(e.target.value)}/>
     <p className="small text-secondary">Isi 0 jika belum ada filamen yang terpakai. Jangan isi seluruh berat rencana cetak.</p>
     <label className="form-label small" htmlFor="failed-reason">Alasan gagal / dihentikan</label><textarea id="failed-reason" className="form-control form-control-sm mb-3" required maxLength={500} value={reason} onChange={e=>setReason(e.target.value)}/>
     <button className="btn btn-sm btn-outline-danger">Catat Gagal, Kembali ke Antrean</button>
    </fieldset>
   </form>
  </details>
 </>;
}

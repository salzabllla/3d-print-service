import { useState } from 'react';

export default function RejectRequestModal({ request, onCancel, onConfirm }) {
  const [alasan, setAlasan] = useState('');

  return (
    <div className="modal d-block" style={{ background: 'rgba(0,0,0,0.5)' }} tabIndex="-1">
      <div className="modal-dialog">
        <div className="modal-content">
          <div className="modal-header">
            <h6 className="modal-title fw-bold">Tolak Pengajuan</h6>
            <button type="button" className="btn-close" onClick={onCancel} />
          </div>
          <div className="modal-body">
            <p className="small text-secondary mb-2">{request.nama} - {request.nim}</p>
            <label className="form-label small">Alasan penolakan</label>
            <textarea className="form-control" rows="3" value={alasan} onChange={(e) => setAlasan(e.target.value)} />
          </div>
          <div className="modal-footer">
            <button className="btn btn-outline-secondary" onClick={onCancel}>Batal</button>
            <button
              className="btn btn-danger"
              disabled={!alasan.trim()}
              onClick={() => onConfirm(alasan)}
            >
              Tolak dan Kirim
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

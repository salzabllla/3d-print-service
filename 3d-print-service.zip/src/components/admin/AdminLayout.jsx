import { Fragment } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2';
import { useEffect, useState } from 'react';
import {
  FiGrid, FiInbox, FiPrinter, FiClock, FiBarChart2, FiSettings, FiLogOut, FiUserPlus, FiMenu, FiDollarSign, FiPackage, FiHelpCircle,
} from 'react-icons/fi';
import { logoutAdmin } from '../../services/authService';
import { subscribeToAdminRequestsByStatus } from '../../services/adminRequestService';
import NotificationBell from './NotificationBell';
import { disablePush } from '../../services/notificationService';
import { useAdminTour } from '../../context/AdminTourContext';

const menu = [
  { to: '/admin/dashboard', label: 'Dashboard', icon: FiGrid },
  { to: '/admin/panduan', label: 'Panduan', icon: FiHelpCircle },
  { to: '/admin/pengajuan', label: 'Pengajuan', icon: FiInbox, section: 'OPERASIONAL' },
  { to: '/admin/printer', label: 'Printer', icon: FiPrinter },
  { to: '/admin/filamen', label: 'Filamen', icon: FiPackage },
  { to: '/admin/riwayat', label: 'Riwayat', icon: FiClock, section: 'LAPORAN' },
  { to: '/admin/statistik', label: 'Statistik', icon: FiBarChart2 },
  { to: '/admin/arus-kas', label: 'Arus Kas', icon: FiDollarSign },
  { to: '/admin/permintaan-admin', label: 'Permintaan Admin', icon: FiUserPlus, badge: true, section: 'PENGELOLAAN' },
  { to: '/admin/pengaturan', label: 'Pengaturan', icon: FiSettings },
];

// Di layar sempit (<992px), sidebar defaultnya ramping (icon-only)
const isMobileScreen = () => typeof window !== 'undefined' && window.innerWidth < 992;

export default function AdminLayout({ children, feature = false }) {
  const navigate = useNavigate();
  const tour = useAdminTour();
  const [pendingAdminRequests, setPendingAdminRequests] = useState(0);
  const [collapsed, setCollapsed] = useState(isMobileScreen());

  useEffect(() => {
    const unsub = subscribeToAdminRequestsByStatus(['pending'], (items) => {
      setPendingAdminRequests(items.length);
    });
    return unsub;
  }, []);

  const toggleSidebar = () => setCollapsed((prev) => !prev);

  // Auto-collapse balik ke rail ikon di HP setelah pilih menu / klik konten
  const autoCollapse = () => {
    if (isMobileScreen()) setCollapsed(true);
  };

  const handleLogout = async () => {
    const confirm = await Swal.fire({
      title: 'Keluar dari dashboard?',
      icon: 'question',
      showCancelButton: true,
      confirmButtonText: 'Ya, logout',
      cancelButtonText: 'Batal',
      confirmButtonColor: '#005BAC',
    });
    if (confirm.isConfirmed) {
      try { await disablePush(); } catch (error) { await Swal.fire('Push belum dinonaktifkan', error.message, 'error'); return; }
      await logoutAdmin();
      navigate('/admin/login');
    }
  };

  return (
    <div className="d-flex" style={{ minHeight: '100vh' }}>
      <aside className={`admin-sidebar bg-white border-end d-flex flex-column ${collapsed ? 'collapsed' : ''}`}>
        <div className="p-3 border-bottom d-flex align-items-center justify-content-between">
          {!collapsed && (
            <h6 className="fw-bold mb-0 text-truncate" style={{ color: '#005BAC' }}>
              3D Print Service
            </h6>
          )}
          <button
            className="btn btn-sm border-0 flex-shrink-0"
            onClick={toggleSidebar}
            aria-label="Buka/tutup sidebar"
          >
            <FiMenu size={20} />
          </button>
        </div>

        <nav className="flex-grow-1 p-2">
          {menu.map((item) => {
            const Icon = item.icon;
            const showBadge = item.badge && pendingAdminRequests > 0;
            return (
              <Fragment key={item.to}>
              {item.section&&!collapsed&&<div className="text-secondary px-3 pt-3 pb-1" style={{fontSize:'.75rem',fontWeight:600}}>{item.section}</div>}
              <NavLink
                to={item.to}
                data-tour={`menu-${item.to.split('/').at(-1)}`}
                aria-label={item.label}
                onClick={autoCollapse}
                title={collapsed ? item.label : undefined}
                className={({ isActive }) =>
                  `d-flex align-items-center gap-2 px-3 py-2 rounded mb-1 text-decoration-none position-relative ${
                    collapsed ? 'justify-content-center' : ''
                  } ${isActive ? 'text-white' : 'text-secondary'}`
                }
                style={({ isActive }) => (isActive ? { background: '#005BAC' } : {})}
              >
                <span className="position-relative d-inline-flex">
                  <Icon />
                  {showBadge && collapsed && <span className="admin-badge-dot" />}
                </span>
                {!collapsed && (
                  <>
                    <span className="text-truncate">{item.label}</span>
                    {showBadge && (
                      <span className="badge rounded-pill bg-danger ms-auto">{pendingAdminRequests}</span>
                    )}
                  </>
                )}
              </NavLink>
              </Fragment>
            );
          })}
        </nav>

        <div className="p-2 border-top">
          <button
            className="btn btn-sm w-100 d-flex align-items-center gap-2 justify-content-center text-secondary"
            onClick={handleLogout}
            title={collapsed ? 'Logout' : undefined}
          >
            <FiLogOut /> {!collapsed && 'Logout'}
          </button>
        </div>
      </aside>

      <main
        className="admin-main flex-grow-1 bg-light"
        style={{ overflowY: 'auto' }}
        onClick={autoCollapse}
      >
        <div className={`p-4 ${feature ? 'elektro-feature' : ''}`}><div className="d-flex justify-content-end align-items-start gap-2">{tour&&<button type="button" data-tour-launch className="btn btn-sm btn-outline-primary" disabled={tour.active} onClick={tour.ask}><FiHelpCircle className="me-1"/>Tutorial</button>}<NotificationBell /></div>{children}</div>
      </main>
    </div>
  );
}

import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { saveQuote } from '../../services/requestService';
import { subscribeFilaments } from '../../services/filamentService';
import { calculateAutomaticQuote, rupiah } from '../../utils/billing';
import { hasFilamentPrice, filamentUnitPrice } from '../../utils/filamentPricing';
import CostBreakdown from '../common/CostBreakdown';

function quotePreview(r,form,lot){
 try{return Number(form.grams)>0?{preview:{...r,...calculateAutomaticQuote(r,Number(form.grams),lot,{autoMaterial:true,diskon:Number(form.diskon),alasanDiskon:form.alasanDiskon})}}:{};}catch(e){return {previewError:e.message};}
}
export default function QuoteEditor({request:r,onSaved,onPreview}) {
 const [form,setForm]=useState({grams:r.beratGram??'',minutes:r.estimasiMenit??'',lot:r.acuanFilamenId||r.filamentLotId||'',diskon:r.diskon||0,alasanDiskon:r.alasanDiskon||''});
 const [lots,setLots]=useState(null),[busy,setBusy]=useState(false),[error,setError]=useState('');
 useEffect(()=>subscribeFilaments(setLots,e=>setError(e.message)),[]);
 const candidates=(lots||[]).filter(l=>l.pemilik===r.sumberFilamen);
 const selected=form.lot||candidates.find(hasFilamentPrice)?.id||'';
 const lot=candidates.find(l=>l.id===selected);
 const options={autoMaterial:true,diskon:Number(form.diskon),alasanDiskon:form.alasanDiskon};
 const {preview,previewError}=quotePreview(r,form,lot);
 useEffect(()=>{onPreview?.(quotePreview(r,form,lot).preview);},[onPreview,r,form,lot]);
 const set=(key,value)=>setForm(prev=>({...prev,[key]:value}));
 return <form onSubmit={async e=>{e.preventDefault();setBusy(true);setError('');try{await saveQuote(r.id,Number(form.grams),Number(form.minutes),selected,options);onSaved?.();}catch(err){setError(err.message);}finally{setBusy(false);}}}>
  <h6 className="fw-bold">Periksa file dan tentukan biaya</h6>
  <p className="small text-secondary">Biaya awal mengikuti berat × tarif layanan. Harga acuan gulungan merinci bahan dan subsidi; total akhir dikurangi diskon.</p>
  {r.sumberFilamen!=='sendiri'&&lots!==null&&!candidates.some(hasFilamentPrice)&&<p className="small text-secondary bg-light rounded p-2" role="status">Harga acuan bahan belum diisi. <Link to="/admin/filamen">Isi harga dan berat awal di Filamen</Link> sebelum menyimpan penawaran.</p>}
  <fieldset disabled={busy}><div className="row g-3">
   <div className="col-sm-6"><label htmlFor="quote-grams" className="form-label small">Berat hasil slicing (g)</label><input id="quote-grams" className="form-control form-control-sm" type="number" min="0.01" max="100000" step="0.01" required value={form.grams} onChange={e=>set('grams',e.target.value)}/></div>
   <div className="col-sm-6"><label htmlFor="quote-minutes" className="form-label small">Estimasi cetak (menit)</label><input id="quote-minutes" className="form-control form-control-sm" type="number" min="1" required value={form.minutes} onChange={e=>set('minutes',e.target.value)}/></div>
  </div>
  {r.sumberFilamen!=='sendiri'&&<details className="workflow-detail mt-3"><summary>Acuan bahan: {lot?lot.nama:'Belum tersedia'}</summary><div className="pt-2"><label className="form-label small" htmlFor="quote-reference">Harga acuan gulungan</label><select id="quote-reference" className="form-select form-select-sm" value={selected} onChange={e=>set('lot',e.target.value)}><option value="">Pilih acuan</option>{candidates.map(l=><option key={l.id} value={l.id}>{l.nama}{hasFilamentPrice(l)?` · ${rupiah(filamentUnitPrice(l))}/g`:' · harga belum diisi'}</option>)}</select><p className="small text-secondary mt-2 mb-0">Gulungan fisik dipilih saat persiapan cetak. Harga acuan disimpan pada penawaran ini. <Link to="/admin/filamen">Kelola harga filamen</Link></p></div></details>}
  <details className="workflow-detail mt-3" open={Number(form.diskon)>0||undefined}><summary>Beri diskon (opsional)</summary><div className="row g-2 pt-2"><div className="col-sm-5"><label htmlFor="quote-discount" className="form-label small">Potongan (Rp)</label><input id="quote-discount" className="form-control form-control-sm" type="number" min="0" step="1" max={preview?.biayaAwal} value={form.diskon} onChange={e=>set('diskon',e.target.value)}/></div><div className="col-sm-7"><label htmlFor="quote-discount-reason" className="form-label small">Keterangan {Number(form.diskon)>0?'(wajib)':''}</label><input id="quote-discount-reason" className="form-control form-control-sm" required={Number(form.diskon)>0} maxLength={500} value={form.alasanDiskon} onChange={e=>set('alasanDiskon',e.target.value)}/></div></div></details>
  </fieldset>
  {preview&&!onPreview&&<div className="bg-light rounded p-3 mt-3"><small className="text-secondary">Pratinjau penawaran</small><CostBreakdown request={preview}/></div>}
  {previewError&&<p role="alert" className="small text-danger mt-2">{previewError} <Link to="/admin/filamen">Buka Filamen</Link></p>}
  {error&&<p role="alert" className="small text-danger mt-2">{error}</p>}
  <button className="btn btn-sm btn-primary mt-3" disabled={busy||!preview}>{busy?'Menyimpan...':'Simpan Penawaran'}</button>
 </form>;
}

import { isExternal, needLabel } from '../../utils/billing';
import { lecturerName } from '../../utils/lecturerNames';
import StatusBadge from '../common/StatusBadge';
import { ESTIMASI_STATUS } from '../../utils/constants';

export default function RequestDetailModal({ request, onClose }) {
  return (
    <div className="modal d-block" style={{ background: 'rgba(0,0,0,0.5)' }} tabIndex="-1">
      <div className="modal-dialog modal-lg">
        <div className="modal-content">
          <div className="modal-header">
            <h6 className="modal-title fw-bold">Detail Pengajuan {request.trackingCode}</h6>
            <button type="button" className="btn-close" onClick={onClose} />
          </div>
          <div className="modal-body">
            <div className="row g-3 small">
              <div className="col-md-6"><strong>Nama:</strong> {request.nama}</div>
              <div className="col-md-6"><strong>NIM:</strong> {request.nim}</div>
              <div className="col-md-6"><strong>Program Studi:</strong> {request.prodi}</div>
              <div className="col-md-6"><strong>WhatsApp:</strong> {request.whatsapp}</div>
              <div className="col-md-6"><strong>Email:</strong> {request.email}</div>
              <div className="col-md-6"><strong>Keperluan:</strong> {request.keperluan}</div>
              <div className="col-md-6"><strong>Kebutuhan cetak:</strong> {needLabel(request)}</div>{!isExternal(request)&&<div className="col-md-6"><strong>Dosen Pembimbing:</strong> {lecturerName(request)}</div>}
              <div className="col-md-6">
                <strong>Estimasi:</strong>{' '}
                {request.estimasiStatus === ESTIMASI_STATUS.BELUM_DIKETAHUI
                  ? 'Belum diketahui mahasiswa'
                  : `${request.estimasiMenit} menit`}
              </div>
              <div className="col-md-6">
                <strong>File STL:</strong>{' '}
                <a href={request.linkStl} target="_blank" rel="noreferrer">Buka link</a>
              </div>
              <div className="col-md-6">
                <strong>Screenshot:</strong>{' '}
                <a href={request.linkScreenshot} target="_blank" rel="noreferrer">Buka link</a>
              </div>
              <div className="col-12"><strong>Catatan:</strong> {request.catatan || '-'}</div>
              <div className="col-12"><strong>Status:</strong> <StatusBadge status={request.status} /></div>
              {request.status === 'ditolak' && (
                <div className="col-12"><strong>Alasan penolakan:</strong> {request.alasanPenolakan}</div>
              )}
            </div>
          </div>
          <div className="modal-footer">
            <button className="btn btn-outline-secondary" onClick={onClose}>Tutup</button>
          </div>
        </div>
      </div>
    </div>
  );
}

import { useState, useRef } from 'react';
import Swal from 'sweetalert2';
import { updatePrinterPhoto } from '../../services/printerService';

const MAX_SIZE_MB = 5;

export default function PrinterPhotoUploadModal({ printer, onClose }) {
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState(printer.photoUrl || null);
  const [isDragging, setIsDragging] = useState(false);
  const [uploading, setUploading] = useState(false);
  const inputRef = useRef(null);

  const handleFile = (selected) => {
    if (!selected) return;
    if (!selected.type.startsWith('image/')) {
      Swal.fire('Format salah', 'File harus berupa gambar (JPG/PNG/WebP).', 'warning');
      return;
    }
    if (selected.size > MAX_SIZE_MB * 1024 * 1024) {
      Swal.fire('Terlalu besar', `Ukuran file maksimal ${MAX_SIZE_MB}MB.`, 'warning');
      return;
    }
    setFile(selected);
    setPreview(URL.createObjectURL(selected));
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragging(false);
    const dropped = e.dataTransfer.files?.[0];
    handleFile(dropped);
  };

  const handleUpload = async () => {
    if (!file) {
      onClose();
      return;
    }
    setUploading(true);
    try {
      const apiKey = import.meta.env.VITE_IMGBB_API_KEY;
      if (!apiKey) {
        throw new Error('VITE_IMGBB_API_KEY belum diatur di file .env.');
      }

      const formData = new FormData();
      formData.append('image', file);

      const res = await fetch(`https://api.imgbb.com/1/upload?key=${apiKey}`, {
        method: 'POST',
        body: formData,
      });
      const data = await res.json();

      if (!data.success) {
        throw new Error(data.error?.message || 'Upload ke ImgBB gagal.');
      }

      const url = data.data.display_url || data.data.url;
      await updatePrinterPhoto(printer.id, url);

      Swal.fire('Berhasil', 'Foto printer diperbarui.', 'success');
      onClose();
    } catch (err) {
      Swal.fire('Gagal', err.message || 'Terjadi kesalahan saat upload.', 'error');
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="modal d-block" style={{ background: 'rgba(0,0,0,0.5)' }} tabIndex="-1">
      <div className="modal-dialog modal-dialog-centered">
        <div className="modal-content">
          <div className="modal-header">
            <h6 className="modal-title fw-bold">Ganti Foto {printer.name}</h6>
            <button type="button" className="btn-close" onClick={onClose} disabled={uploading}></button>
          </div>
          <div className="modal-body">
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setIsDragging(true);
              }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={handleDrop}
              onClick={() => inputRef.current?.click()}
              className="d-flex flex-column align-items-center justify-content-center text-center p-4 mb-2"
              style={{
                border: `2px dashed ${isDragging ? '#005BAC' : '#ccc'}`,
                borderRadius: 10,
                cursor: 'pointer',
                background: isDragging ? '#EAF3FB' : '#fafafa',
                minHeight: 200,
                transition: 'all 0.15s ease',
              }}
            >
              {preview ? (
                <img
                  src={preview}
                  alt="preview"
                  style={{ maxHeight: 160, maxWidth: '100%', objectFit: 'contain', borderRadius: 6 }}
                />
              ) : (
                <>
                  <div className="fw-semibold mb-1">Seret &amp; lepas gambar di sini</div>
                  <div className="small text-secondary">atau klik untuk pilih file (JPG/PNG, maks {MAX_SIZE_MB}MB)</div>
                </>
              )}
            </div>
            <input
              ref={inputRef}
              type="file"
              accept="image/*"
              className="d-none"
              onChange={(e) => handleFile(e.target.files?.[0])}
            />
            {file && <div className="small text-secondary text-center">{file.name}</div>}
          </div>
          <div className="modal-footer">
            <button className="btn btn-outline-secondary" onClick={onClose} disabled={uploading}>
              Batal
            </button>
            <button
              className="btn text-white"
              style={{ background: '#005BAC' }}
              onClick={handleUpload}
              disabled={!file || uploading}
            >
              {uploading ? 'Mengunggah...' : 'Simpan Foto'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

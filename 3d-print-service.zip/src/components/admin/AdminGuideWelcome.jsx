import { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useAdminTour } from '../../context/AdminTourContext';
import { readTourProgress, saveTourProgress } from '../../data/adminTour';
export default function AdminGuideWelcome(){
 const {currentUser}=useAuth();
 const tour=useAdminTour();
 const [hidden,setHidden]=useState(false);
 let progress;try{progress=readTourProgress(currentUser?.uid,localStorage);}catch{/* Optional preference. */}
 if(!currentUser||hidden||progress||!tour||tour.active)return null;
 const hide=()=>{try{saveTourProgress(currentUser.uid,{index:0,status:'later'},localStorage);}catch{/* Optional preference. */}setHidden(true);};
 return <section className="card border-0 shadow-sm p-3 mb-3 small" aria-label="Tutorial admin"><div className="d-flex flex-wrap align-items-center justify-content-between gap-2"><div><h6 className="fw-bold mb-1">Kenali cara memakai halaman admin</h6><p className="text-secondary mb-0">Ikuti sorotan dan klik menu satu per satu. Bisa diulang kapan saja.</p></div><div className="d-flex gap-2"><button type="button" className="btn btn-sm btn-primary" onClick={tour.ask}>Mulai Tutorial</button><button type="button" className="btn btn-sm btn-outline-secondary" onClick={hide}>Nanti</button></div></div></section>;
}

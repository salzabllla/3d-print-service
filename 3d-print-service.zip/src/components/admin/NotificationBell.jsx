import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { FiBell } from 'react-icons/fi';
import { useAuth } from '../../context/AuthContext';
import { enablePush, disablePush, refreshPush, subscribeNotifications, subscribeReads, markRead, markNotificationsRead, listenForeground } from '../../services/notificationService';
export default function NotificationBell(){
 const {currentUser}=useAuth();const [items,setItems]=useState([]),[reads,setReads]=useState(new Set()),[open,setOpen]=useState(false),[toast,setToast]=useState(null),[error,setError]=useState(''),[enabled,setEnabled]=useState(false),[busy,setBusy]=useState(false);const initialized=useRef(false),ids=useRef(new Set());
 useEffect(()=>{if(!currentUser)return;const fail=e=>setError(e.message);const a=subscribeNotifications(next=>{if(initialized.current){const fresh=next.find(n=>!ids.current.has(n.id));if(fresh)setToast(fresh);}ids.current=new Set(next.map(n=>n.id));initialized.current=true;setItems(next);},fail);const b=subscribeReads(currentUser.uid,setReads,fail);let c=()=>{};listenForeground(()=>{}).then(unsub=>{c=unsub;}).catch(fail);refreshPush().then(setEnabled).catch(fail);return()=>{a();b();c();};},[currentUser]);
 useEffect(()=>{if(!toast)return;const timer=setTimeout(()=>setToast(null),8000);return()=>clearTimeout(timer);},[toast]);
 const pushAvailable=import.meta.env.VITE_ENABLE_PUSH==='true'&&!!import.meta.env.VITE_FIREBASE_VAPID_KEY;
 const unread=items.filter(n=>!reads.has(n.id)).length;
 const viewNotifications=async()=>{
  if(open){setOpen(false);return;}
  setOpen(true);setToast(null);setError('');
  const visibleIds=items.filter(n=>!reads.has(n.id)).map(n=>n.id);
  if(!visibleIds.length)return;
  setReads(previous=>new Set([...previous,...visibleIds]));
  try{await markNotificationsRead(currentUser.uid,visibleIds);}
  catch(e){setReads(previous=>new Set([...previous].filter(id=>!visibleIds.includes(id))));setError(`Gagal menyimpan status dibaca: ${e.message}`);}
 };
 const toggle=async()=>{setBusy(true);setError('');try{if(enabled){await disablePush();setEnabled(false);}else{await enablePush();setEnabled(true);}}catch(e){setError(e.message);}finally{setBusy(false);}};
 return <div className="elektro-feature d-flex justify-content-end mb-2 position-relative"><button className="btn btn-sm btn-outline-secondary d-flex gap-2 align-items-center" aria-label={`Notifikasi, ${unread} belum dibaca`} aria-expanded={open} onClick={viewNotifications}><FiBell/>{unread>0&&<span className="badge bg-danger">{unread}</span>}</button>{open&&<div className="card shadow-sm position-absolute end-0 mt-5" style={{zIndex:1040,width:'min(380px, 85vw)'}}><div className="card-header d-flex justify-content-between align-items-center"><strong>Notifikasi</strong><button className="btn btn-sm btn-link" onClick={()=>setOpen(false)}>Tutup</button></div><div className="list-group list-group-flush" style={{maxHeight:320,overflowY:'auto'}}>{!items.length&&<p className="small text-secondary p-3 mb-0">Belum ada notifikasi.</p>}{items.map(n=><Link key={n.id} className={`list-group-item list-group-item-action small ${reads.has(n.id)?'':'fw-semibold'}`} to={`/admin/pengajuan?id=${encodeURIComponent(n.requestId)}`} onClick={()=>{markRead(currentUser.uid,n.id).catch(e=>setError(e.message));setOpen(false);}}>{n.title}<div className="text-secondary fw-normal">{n.body}</div></Link>)}</div><div className="card-footer">{pushAvailable&&<button className="btn btn-sm btn-outline-primary" disabled={busy} onClick={toggle}>{busy?'Memproses…':enabled?'Nonaktifkan push perangkat ini':'Aktifkan push perangkat ini'}</button>}{!pushAvailable&&<p className="small text-secondary mb-0">Notifikasi diperbarui saat website terbuka.</p>}{error&&<p className="text-danger small mt-2 mb-0" role="alert">{error}</p>}</div></div>}{toast&&<div className="position-fixed bottom-0 end-0 m-3 card shadow" style={{zIndex:1090,maxWidth:340}} role="status"><div className="card-body py-2"><strong>{toast.title}</strong><p className="small mb-1">{toast.body}</p><Link className="small" to={`/admin/pengajuan?id=${encodeURIComponent(toast.requestId)}`} onClick={()=>setToast(null)}>Lihat pengajuan</Link><button className="btn btn-sm btn-link" onClick={()=>setToast(null)}>Tutup</button></div></div>}</div>;
}

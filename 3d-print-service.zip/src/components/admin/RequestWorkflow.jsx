import { Navigate, useLocation } from 'react-router-dom';
export default function RequestWorkflow({request}) {
 const location=useLocation();
 return <Navigate to={`/admin/pengajuan/${encodeURIComponent(request.id)}`} state={{returnTo:location.pathname+location.search}} replace={false}/>;
}

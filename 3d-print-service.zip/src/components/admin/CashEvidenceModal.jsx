import { safeEvidenceUrl } from '../../utils/cashEvidence';
import { useEffect, useState } from 'react';
import Modal from '../common/Modal';
import { rupiah, toDate } from '../../utils/billing';
import { saveCashEvidence, getCashEvidence, getCashEvidenceHistory, downloadCashEvidence } from '../../services/cashEvidenceService';
export default function CashEvidenceModal({transaction:r,onClose,onSaved}) {
 const hasProof=!!(r.proofVersion||r.bukti);
 const [editing,setEditing]=useState(!hasProof),[kind,setKind]=useState('file'),[file,setFile]=useState(null),[link,setLink]=useState(''),[note,setNote]=useState('');
 const [evidence,setEvidence]=useState(null),[history,setHistory]=useState(null),[busy,setBusy]=useState(false),[error,setError]=useState('');
 const [operationId]=useState(()=>crypto.randomUUID()),[expectedVersion]=useState(r.proofVersion||'');
 useEffect(()=>{if(!r.proofVersion)return;let disposed=false;getCashEvidence(r.id,r.proofVersion).then(value=>{if(!disposed)setEvidence(value);}).catch(e=>{if(!disposed)setError(e.message);});return()=>{disposed=true;};},[r.id,r.proofVersion]);
 const openFile=value=>{setError('');try{downloadCashEvidence(value);}catch(e){setError(e.message);}};
 const proofButton=value=>value.kind==='file'?<button type="button" className="btn btn-sm btn-outline-primary" onClick={()=>openFile(value)}>Unduh Bukti</button>:<a className="btn btn-sm btn-outline-primary" href={safeEvidenceUrl(value.link)} target="_blank" rel="noopener noreferrer">Buka Bukti ↗</a>;
 return <Modal title="Bukti Transaksi" onClose={()=>{if(!busy)onClose();}}>
  <p className="small mb-1"><strong>{r.trackingCode||r.id.slice(0,8)}</strong> · {r.nama}</p><p className="small text-secondary mb-3">{r.uraian} · {rupiah(r.masuk||r.keluar)}</p>
  {error&&<p className="alert alert-danger small py-2" role="alert">{error}</p>}
  {hasProof&&!editing&&<div className="small">
   {r.proofVersion?evidence?<><p className="mb-2">{evidence.name}</p>{proofButton(evidence)}<p className="text-secondary mt-2 mb-1">Dicatat {toDate(evidence.uploadedAt)?.toLocaleString('id-ID')} oleh {evidence.uploadedBy}</p>{evidence.note&&<p>{evidence.note}</p>}</>:<p>Memuat bukti...</p>:<a href={safeEvidenceUrl(r.bukti)} target="_blank" rel="noopener noreferrer">Buka Bukti ↗</a>}
   <div className="d-flex flex-wrap gap-2 mt-3"><button type="button" className="btn btn-sm btn-outline-secondary" onClick={()=>setEditing(true)}>Ganti Bukti</button>{r.proofVersion&&<button type="button" className="btn btn-sm btn-outline-secondary" disabled={busy} onClick={async()=>{setBusy(true);setError('');try{setHistory(await getCashEvidenceHistory(r.id));}catch(e){setError(e.message);}finally{setBusy(false);}}}>Riwayat Bukti</button>}</div>
   {history&&<div className="mt-3 border-top pt-2"><h6 className="fw-bold small">10 bukti terbaru</h6>{history.map(value=><div key={value.id} className="border-bottom py-2"><p className="mb-1">{value.name} · {toDate(value.uploadedAt)?.toLocaleString('id-ID')}</p><p className="text-secondary mb-1">{value.uploadedBy}{value.note&&` · ${value.note}`}</p>{proofButton(value)}{safeEvidenceUrl(value.previousLink)&&<a className="small ms-2" href={safeEvidenceUrl(value.previousLink)} target="_blank" rel="noopener noreferrer">Tautan sebelumnya ↗</a>}</div>)}</div>}
  </div>}
  {editing&&<form onSubmit={async e=>{e.preventDefault();if(busy)return;setBusy(true);setError('');try{await saveCashEvidence(r.id,{operationId,expectedVersion,kind,file,link,note});onSaved();}catch(err){setError(err.message);}finally{setBusy(false);}}}><fieldset disabled={busy}>
   <label htmlFor="cash-proof-kind" className="form-label small">Jenis bukti</label><select id="cash-proof-kind" className="form-select form-select-sm mb-2" value={kind} onChange={e=>setKind(e.target.value)}><option value="file">Unggah file</option><option value="link">Tautan bukti</option></select>
   {kind==='file'?<><label htmlFor="cash-proof-file" className="form-label small">File bukti</label><input id="cash-proof-file" type="file" accept="application/pdf,image/png,image/jpeg" className="form-control form-control-sm" required onChange={e=>setFile(e.target.files?.[0]||null)}/><p className="form-text">PDF, JPG, atau PNG maksimal 600 KB. File lebih besar gunakan tautan bukti.</p></>:<><label htmlFor="cash-proof-link" className="form-label small">Tautan HTTPS</label><input id="cash-proof-link" type="url" className="form-control form-control-sm mb-2" required maxLength={1500} value={link} onChange={e=>setLink(e.target.value)}/></>}
   <label htmlFor="cash-proof-note" className="form-label small">{hasProof?'Alasan penggantian bukti':'Keterangan (opsional)'}</label><textarea id="cash-proof-note" className="form-control form-control-sm" required={hasProof} maxLength={500} rows="2" value={note} onChange={e=>setNote(e.target.value)}/>
   <p className="small text-secondary mt-2">Nominal dan saldo tidak berubah. Bukti hanya dapat dibuka admin.</p>
   <div className="d-flex justify-content-end gap-2"><button type="button" className="btn btn-sm btn-outline-secondary" onClick={()=>hasProof?setEditing(false):onClose()}>Batal</button><button className="btn btn-sm btn-primary">{busy?'Menyimpan...':'Simpan Bukti'}</button></div>
  </fieldset></form>}
 </Modal>;
}

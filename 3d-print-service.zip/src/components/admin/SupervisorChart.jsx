import { Chart as ChartJS, ArcElement, Tooltip } from 'chart.js';
import { Doughnut } from 'react-chartjs-2';

ChartJS.register(ArcElement, Tooltip);

const palette = ['#005BAC', '#1D9E75', '#7F77DD', '#3288BD', '#59A7A0', '#A98150', '#577590', '#8B6EAF', '#367C59', '#BC7182', '#69A3D0', '#9C9852'];
const percent = new Intl.NumberFormat('id-ID', { style: 'percent', maximumFractionDigits: 1 });

export default function SupervisorChart({ groups, visible, loading, onSelect, label='Dosen Pembimbing' }) {
  const total = visible.reduce((sum, group) => sum + group.jumlah, 0);
  const colors = new Map(groups.map((group, index) => [group.key, group.key === 'unknown' ? '#9AA3AB' : palette[index % palette.length]]));

  return (
    <section className="card border-0 shadow-sm mb-3" aria-labelledby="supervisor-chart-title">
      <div className="card-body">
        <h6 className="fw-bold mb-1" id="supervisor-chart-title">Proporsi cetak {label}</h6>
        <p className="small text-secondary mb-3">Jumlah cetak selesai sesuai filter. Pilih nama untuk melihat rekapnya.</p>
        {loading ? <p className="small text-secondary mb-0" role="status">Memuat grafik…</p> : !total ? <p className="small text-secondary mb-0">Belum ada data sesuai filter.</p> : (
          <div className="row g-3 align-items-center">
            <div className="col-md-4">
              <div className="position-relative mx-auto" style={{ width: 250, maxWidth: '100%', aspectRatio: '1' }}>
                <Doughnut
                  role="img"
                  aria-label={`Proporsi ${total} cetak selesai. Rincian jumlah dan persentase tersedia pada daftar nama di samping grafik.`}
                  data={{ labels: visible.map(group => group.nama), datasets: [{ data: visible.map(group => group.jumlah), backgroundColor: visible.map(group => colors.get(group.key)), borderColor: '#fff', borderWidth: 2, hoverOffset: 4 }] }}
                  options={{
                    maintainAspectRatio: false,
                    cutout: '70%',
                    layout: { padding: 5 },
                    plugins: {
                      legend: { display: false },
                      tooltip: {
                        titleFont: { family: "'Segoe UI', system-ui, sans-serif", size: 12 },
                        bodyFont: { family: "'Segoe UI', system-ui, sans-serif", size: 12 },
                        callbacks: { label: context => `${context.raw} cetak (${percent.format(context.raw / total)})` },
                      },
                    },
                  }}
                />
                <div className="position-absolute top-50 start-50 translate-middle text-center pe-none" aria-hidden="true">
                  <strong className="d-block fs-4">{total.toLocaleString('id-ID')}</strong>
                  <span className="small text-secondary text-nowrap">cetak selesai</span>
                </div>
              </div>
            </div>
            <div className="col-md-8">
              <ul className="row g-2 list-unstyled mb-0">
                {visible.map(group => (
                  <li className="col-12 col-lg-6" key={group.key}>
                    <button type="button" className="btn btn-sm btn-link text-decoration-none text-body text-start d-flex align-items-start gap-2 p-1 w-100" onClick={() => onSelect(group.key)}>
                      <span className="rounded-circle flex-shrink-0 mt-1" style={{ width: 10, height: 10, backgroundColor: colors.get(group.key) }} aria-hidden="true" />
                      <span className="flex-grow-1" style={{ minWidth: 0, overflowWrap: 'anywhere' }}>{group.nama}</span>
                      <span className="text-nowrap text-end flex-shrink-0"><strong className="fw-semibold">{group.jumlah}</strong><span className="text-secondary ms-1">({percent.format(group.jumlah / total)})</span></span>
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}

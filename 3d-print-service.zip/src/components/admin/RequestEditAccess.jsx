import { useState } from 'react';
import { getManagementKeyForOperator } from '../../services/requestManagementService';
import { managementUrl } from '../../utils/requestManagement';
import { PrivateEditLink } from '../common/RequestActions';
import WhatsAppButton from '../common/WhatsAppButton';

export default function RequestEditAccess({request:r}){
  const [key,setKey]=useState(''),[busy,setBusy]=useState(false),[error,setError]=useState('');
  if(!r.pricingVersion)return null;
  return <section className="border-top pt-3 mb-3"><h6 className="fw-bold">Tautan Pribadi Pemohon</h6><p className="small text-secondary mb-2">Periksa identitas pemohon sebelum memberikan tautan pribadi. Tautan memberi akses rincian dan invoice. Edit hanya tersedia sebelum biaya disetujui.</p>{!key?<button className="btn btn-sm btn-outline-secondary" disabled={busy} onClick={async()=>{setBusy(true);setError('');try{setKey(await getManagementKeyForOperator(r.id));}catch(e){setError(e.message);}finally{setBusy(false);}}}>{busy?'Menyiapkan…':'Siapkan Tautan Pribadi'}</button>:<><PrivateEditLink request={r} accessKey={key}/><div className="mt-2"><WhatsAppButton phone={r.whatsapp} label="Kirim Tautan Pribadi" message={`Halo ${r.nama}, berikut tautan pribadi pengajuan ${r.trackingCode}.\n${managementUrl(r,key)}\nSimpan dan jangan bagikan tautan ini kepada orang lain. Edit atau pembatalan tersedia sebelum biaya disetujui.`}/></div></>}{error&&<p className="small text-danger mt-2" role="alert">{error}</p>}</section>;
}

import { useEffect, useState } from 'react';
import Swal from 'sweetalert2';
import { isExternal, rupiah, paymentSettled, amountReceived, outstandingAmount } from '../../utils/billing';
import { SPONSOR_FORM_URL, hasQuote, sponsorApproved, sponsorshipMatches } from '../../utils/sponsorship';
import { subscribeSponsorship, reviewSponsorship, recordPaperSponsorship } from '../../services/sponsorshipService';
import SignedFormDownload from '../common/SignedFormDownload';

export default function SponsorshipReview({request:r,onVerified}) {
  const [form,setForm]=useState(null),[reference,setReference]=useState(''),[error,setError]=useState(''),[busy,setBusy]=useState(false);
  const [viewedVersion,setViewedVersion]=useState(null);
  useEffect(()=>subscribeSponsorship(r.id,setForm,e=>setError(e.message)),[r.id]);
  if(!r.pricingVersion||isExternal(r)||['dibatalkan','ditolak'].includes(r.status)||(paymentSettled(r)&&!sponsorApproved(r)))return null;
  const verified=sponsorApproved(r),valid=sponsorshipMatches(form,r);
  const act=async fn=>{setBusy(true);setError('');try{await fn();onVerified?.();}catch(e){setError(e.message);}finally{setBusy(false);}};
  return <section className="border-top pt-3 mb-3 small">
    <h6 className="fw-bold">Biaya Ditanggung Pembimbing</h6>
    {form?.fileVersion&&<><SignedFormDownload requestId={r.id} onDownloaded={setViewedVersion}/>{!verified&&<p className="text-secondary mb-2">Unduh dan periksa file terbaru sebelum memverifikasi.</p>}</>}
    {verified?<><p className="mb-1 text-primary">Form sudah diverifikasi. Biaya {rupiah(r.totalBiaya)} ditagihkan kepada pembimbing.</p><p className="text-secondary mb-0">{r.paymentStatus==='paid'?'Pembayaran telah diterima dan diverifikasi.':amountReceived(r)>0?`Pembayaran diterima ${rupiah(amountReceived(r))}. Sisa tagihan ${rupiah(outstandingAmount(r))} belum masuk kas.`:'Persetujuan biaya tercakup dalam form. Cetak dan pengambilan dapat dilanjutkan. Tagihan belum menjadi pemasukan kas.'}</p>{form?.link?<a href={form.link} target="_blank" rel="noopener noreferrer">Lihat arsip form ↗</a>:form?.paperReference&&<p className="mb-0 mt-1 text-secondary">Arsip form: {form.paperReference}</p>}</>:<>
      <p className="text-secondary mb-2">Periksa kode, nama, pembimbing, berat, biaya dan kedua tanda tangan. Form yang valid menjadi dasar pencetakan dan penagihan kepada pembimbing.</p>
      <a href={SPONSOR_FORM_URL} download className="d-inline-block mb-2">Unduh form kosong</a>
      {form?.link&&<div className="mb-2"><a href={form.link} target="_blank" rel="noopener noreferrer">Buka form pemohon ↗</a><span className="text-secondary ms-2">{form.status==='pending'?'Menunggu pemeriksaan':form.status==='revision'?'Perlu perbaikan':'Sudah diverifikasi'}</span></div>}
      {form&&!valid&&<p className="text-warning-emphasis">Data atau biaya berubah. Pemohon perlu mengirim ulang form sesuai rincian terbaru.</p>}
      {form?.status==='pending'&&valid&&<div className="d-flex flex-wrap gap-2 mb-3">
        <button className="btn btn-sm btn-outline-primary" disabled={busy||!!form.fileVersion&&viewedVersion!==form.fileVersion} onClick={async()=>{const result=await Swal.fire({title:'Form lengkap dan kedua tanda tangan sesuai?',text:`Biaya ${rupiah(r.totalBiaya)} akan ditagihkan kepada pembimbing.`,icon:'question',showCancelButton:true,confirmButtonText:'Verifikasi Form',cancelButtonText:'Kembali'});if(result.isConfirmed)await act(()=>reviewSponsorship(r.id,true,'',form));}}>Verifikasi Form</button>
        <button className="btn btn-sm btn-outline-secondary" disabled={busy} onClick={async()=>{const result=await Swal.fire({title:'Form perlu diperbaiki',input:'textarea',inputLabel:'Alasan perbaikan',inputAttributes:{maxlength:500},showCancelButton:true,confirmButtonText:'Kirim Alasan',cancelButtonText:'Kembali',inputValidator:v=>v?.trim()?undefined:'Isi alasan perbaikan.'});if(result.isConfirmed)await act(()=>reviewSponsorship(r.id,false,result.value,form));}}>Minta Perbaikan</button>
      </div>}
      {hasQuote(r)&&r.paymentStatus==='unpaid'&&<div className="bg-light rounded p-2">
        <label className="form-label" htmlFor={`paper-sponsor-${r.id}`}>Form diserahkan langsung kepada operator</label>
        <input id={`paper-sponsor-${r.id}`} className="form-control form-control-sm" maxLength={200} placeholder="Nomor / keterangan arsip form" value={reference} onChange={e=>setReference(e.target.value)}/>
        <button className="btn btn-sm btn-outline-primary mt-2" disabled={busy||!reference.trim()} onClick={async()=>{const result=await Swal.fire({title:'Form bertanda tangan sudah diterima?',text:'Pastikan rincian dan kedua tanda tangan telah diperiksa. Pembimbing akan ditagih setelahnya.',icon:'question',showCancelButton:true,confirmButtonText:'Catat Form Diterima',cancelButtonText:'Kembali'});if(result.isConfirmed)await act(()=>recordPaperSponsorship(r.id,reference));}}>Catat Form Diterima</button>
      </div>}
    </>}
    {error&&<p role="alert" className="text-danger mt-2 mb-0">{error}</p>}
  </section>;
}

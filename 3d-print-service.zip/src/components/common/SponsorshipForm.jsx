import { useEffect, useState } from 'react';
import { SPONSOR_FORM_URL, canApplySponsorship, sponsorApproved, sponsorshipMatches } from '../../utils/sponsorship';
import { isExternal } from '../../utils/billing';
import { savedManagementKey } from '../../utils/requestManagement';
import { subscribeOwnSponsorship, submitSponsorship, withdrawSponsorship } from '../../services/sponsorshipService';
import SignedFormDownload from './SignedFormDownload';

export default function SponsorshipForm({request:r,accessKey}) {
  const key=accessKey||savedManagementKey(r.trackingCode);
  const [form,setForm]=useState(null),[link,setLink]=useState(''),[error,setError]=useState(''),[busy,setBusy]=useState(false),[notice,setNotice]=useState('');
  const [method,setMethod]=useState('file'),[file,setFile]=useState(null);
  useEffect(()=>{
    if(!key)return;
    let disposed=false,stop;
    subscribeOwnSponsorship(r.id,key,value=>{if(!disposed)setForm(value);},e=>{if(!disposed)setError(e.message);}).then(unsubscribe=>{if(disposed)unsubscribe();else stop=unsubscribe;}).catch(e=>{if(!disposed)setError(e.message);});
    return()=>{disposed=true;stop?.();};
  },[key,r.id]);
  if(!r.pricingVersion||isExternal(r)||['ditolak','dibatalkan'].includes(r.status)||r.paymentStatus==='paid')return null;
  if(sponsorApproved(r))return <p className="small border-top pt-3 mt-3 mb-0">Form pembimbing sudah diverifikasi. Hasil cetak dapat diambil setelah selesai. Biaya akan ditagihkan kepada pembimbing. Invoice lunas terbit setelah pembayaran diterima dan diverifikasi.</p>;
  return <section className="border-top pt-3 mt-3 small">
    <h6 className="fw-bold">Jika keberatan biaya</h6>
    <p className="mb-2">Isi form dan minta tanda tangan pemohon serta pembimbing. Setelah diverifikasi operator, cetak dilanjutkan dan biaya ditagihkan ke pembimbing.</p>
    <a href={SPONSOR_FORM_URL} download className="btn btn-sm btn-outline-primary">Unduh Form Pembimbing</a>
    {!canApplySponsorship(r)?<p className="text-secondary mt-2 mb-0">Tunggu operator memeriksa file dan menetapkan biaya sebelum mengisi form.</p>:!key?<p className="text-secondary mt-2 mb-0">Buka tautan pribadi untuk mengirim form, atau serahkan form bertanda tangan kepada operator.</p>:<>
      <form className="mt-3" onSubmit={async e=>{e.preventDefault();const element=e.currentTarget;setBusy(true);setError('');setNotice('');try{await submitSponsorship(r.id,key,method==='file'?file:link.trim());setLink('');setFile(null);element.reset();setNotice('Form terkirim. Tunggu pemeriksaan operator.');}catch(err){setError(err.message);}finally{setBusy(false);}}}><fieldset disabled={busy}>
        {form?.status==='pending'&&sponsorshipMatches(form,r)&&<p className="text-primary">Form menunggu pemeriksaan operator.</p>}
        {form&&!sponsorshipMatches(form,r)&&<p className="text-warning-emphasis">Biaya atau data berubah. Isi dan kirim ulang form sesuai rincian terbaru.</p>}
        {form?.status==='revision'&&<p className="text-danger">Perbaiki form: {form.reason}</p>}
        {form?.fileVersion&&<SignedFormDownload requestId={r.id} accessKey={key}/>}
        <label htmlFor={`sponsor-method-${r.id}`} className="form-label">Kirim form bertanda tangan</label>
        <select id={`sponsor-method-${r.id}`} className="form-select form-select-sm mb-2" value={method} onChange={e=>setMethod(e.target.value)}><option value="file">Unggah file</option><option value="link">Tautan Google Drive</option></select>
        {method==='file'?<><label htmlFor={`sponsor-file-${r.id}`} className="form-label">File form</label><input id={`sponsor-file-${r.id}`} type="file" className="form-control form-control-sm" accept="application/pdf,image/jpeg,image/png" required onChange={e=>setFile(e.target.files?.[0]||null)}/><div className="form-text">PDF, JPG, atau PNG maksimal 600 KB. File lebih besar dapat dikirim melalui tautan Google Drive.</div></>:<><label htmlFor={`sponsor-link-${r.id}`} className="form-label">Tautan Google Drive form bertanda tangan</label>
        <input id={`sponsor-link-${r.id}`} className="form-control form-control-sm" type="url" required maxLength={1500} value={link} onChange={e=>setLink(e.target.value)} placeholder="https://drive.google.com/..."/>
        <div className="form-text">Berikan akses kepada operator.</div></>}
        <div className="form-text">Form hanya dapat dibuka pemilik pengajuan dan admin. Rekap pembimbing diperbarui setelah form diverifikasi dan cetak selesai.</div>
        <button className="btn btn-sm btn-primary mt-2" disabled={busy}>{busy?'Mengirim...':'Kirim Form'}</button>
        {['pending','revision'].includes(form?.status)&&<button type="button" className="btn btn-sm btn-outline-secondary mt-2 ms-2" disabled={busy} onClick={async()=>{setBusy(true);setError('');try{await withdrawSponsorship(r.id,key);setNotice('Permohonan biaya pembimbing ditarik. Pembayaran dilakukan sendiri saat pengambilan.');}catch(e){setError(e.message);}finally{setBusy(false);}}}>Bayar sendiri, tarik permohonan</button>}
      </fieldset></form>
    </>}
    {error&&<p role="alert" className="text-danger mt-2 mb-0">{error}</p>}{notice&&<p role="status" className="text-success mt-2 mb-0">{notice}</p>}
  </section>;
}

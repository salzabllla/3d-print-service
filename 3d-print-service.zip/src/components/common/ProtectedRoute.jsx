import { Navigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import Loading from './Loading';

export default function ProtectedRoute({ children }) {
  const { isAdmin, loading } = useAuth();

  if (loading) return <Loading label="Memeriksa sesi login..." />;
  if (!isAdmin) return <Navigate to="/admin/login" replace />;

  return children;
}

import { useState } from 'react';
import Modal from './Modal';
import { buildWhatsAppLink } from '../../utils/waLink';
export default function WhatsAppButton({phone,message,label='Konfirmasi via WhatsApp',disabled=false,prepareMessage}) {
 const [open,setOpen]=useState(false),[prepared,setPrepared]=useState(''),[preparing,setPreparing]=useState(false),[prepareError,setPrepareError]=useState('');const text=prepareMessage?prepared:message;let url,error;
 try{url=buildWhatsAppLink(phone,text);}catch(e){error=e.message;}
 return <><button className="btn btn-sm btn-outline-success" disabled={disabled} onClick={async()=>{setOpen(true);if(prepareMessage){setPrepared('');setPrepareError('');setPreparing(true);try{setPrepared(await prepareMessage());}catch(e){setPrepareError(e.message);}finally{setPreparing(false);}}}}>{label}</button>{open&&<Modal title="Pratinjau WhatsApp" onClose={()=>setOpen(false)}><p className="small">Tujuan: <strong>{phone||'Belum diisi'}</strong></p>{preparing?<p role="status" className="small text-secondary">Menyiapkan pesan dan tautan pribadi...</p>:prepareError?<p role="alert" className="small text-danger">{prepareError}</p>:error?<p className="text-danger">{error}</p>:<><pre className="bg-light border rounded p-3 small" style={{whiteSpace:'pre-wrap',fontFamily:'inherit'}}>{text}</pre><p className="small text-secondary">Pesan belum dikirim. Tekan Kirim di WhatsApp setelah memeriksa penerima.</p><a className="btn btn-success" href={url} target="_blank" rel="noopener noreferrer">Buka WhatsApp</a></>}</Modal>}</>;
}

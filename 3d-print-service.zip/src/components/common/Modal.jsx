import { useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
const stack=[];
let originalOverflow='';
export default function Modal({title,onClose,children,footer,wide=false,className=''}) {
 const ref=useRef(null), closeRef=useRef(onClose);
 useEffect(()=>{closeRef.current=onClose;},[onClose]);
 useEffect(()=>{
  const element=ref.current,before=document.activeElement;
  if(!stack.length){originalOverflow=document.body.style.overflow;document.body.style.overflow='hidden';}
  stack.push(element);element.style.zIndex=1055+stack.length*10;element.focus();
  const handler=e=>{
   if(stack.at(-1)!==element||document.querySelector('.swal2-container'))return;
   if(e.key==='Escape'){e.preventDefault();closeRef.current();}
   if(e.key==='Tab'){
    const nodes=[...element.querySelectorAll('button:not([disabled]),a[href],input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex="0"]')].filter(n=>n.getClientRects().length);
    const first=nodes[0],last=nodes.at(-1);
    if(!nodes.length){e.preventDefault();element.focus();}
    else if(e.shiftKey&&(document.activeElement===first||document.activeElement===element)){e.preventDefault();last.focus();}
    else if(!e.shiftKey&&(document.activeElement===last||document.activeElement===element)){e.preventDefault();first.focus();}
   }
  };
  document.addEventListener('keydown',handler);
  return()=>{document.removeEventListener('keydown',handler);stack.splice(stack.indexOf(element),1);if(!stack.length)document.body.style.overflow=originalOverflow;if(before?.isConnected)before.focus();};
 },[]);
 return createPortal(<div className={`modal d-block elektro-feature ${className}`} style={{background:'rgba(0,0,0,.5)'}} role="dialog" aria-modal="true" aria-label={title} tabIndex={-1} ref={ref}><div className={`modal-dialog modal-dialog-centered modal-dialog-scrollable ${wide?'modal-lg':''}`}><div className="modal-content"><div className="modal-header"><h5 className="modal-title fw-bold">{title}</h5><button type="button" className="btn-close" aria-label="Tutup" onClick={onClose}/></div><div className="modal-body">{children}</div>{footer&&<div className="modal-footer">{footer}</div>}</div></div></div>,document.body);
}

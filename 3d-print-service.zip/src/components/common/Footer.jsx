import { FiPhone, FiMapPin } from 'react-icons/fi';
import { Link } from 'react-router-dom';
import { useSettings } from '../../context/SettingsContext';

export default function Footer() {
  const settings = useSettings();

  return (
    <footer className="border-top bg-white mt-auto">
      <div className="container py-4">
        <div className="row gy-3">
          <div className="col-md-6">
            <h6 className="fw-bold mb-1" style={{ color: '#005BAC' }}>
              3D Print Service
            </h6>
            <p className="text-secondary small mb-1">Dikelola oleh Badan Usaha HMTE.</p>
            <p className="text-secondary small mb-0">
              Sistem pengajuan layanan Printer 3D Program Studi Teknik Elektro,
              Fakultas Teknik, Universitas Sebelas Maret.
            </p>
          </div>

          <div className="col-md-6 text-md-end">
            <p className="small text-secondary mb-2 d-flex align-items-center gap-2 justify-content-md-end">
              <FiMapPin />
              3D Print Service
            </p>

            {settings.pics?.map((pic, i) => {
              // Hilangkan semua karakter selain angka
              const waNumber = pic.whatsapp.replace(/\D/g, "");

              return (
                <p
                  key={i}
                  className="small mb-1 d-flex align-items-center gap-2 justify-content-md-end"
                >
                  <FiPhone />
                  <span>
                    PIC {i + 1}: <strong>{pic.name}</strong> ·{" "}
                    <a
                      href={`https://wa.me/${waNumber}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-decoration-none"
                    >
                      {pic.whatsapp}
                    </a>
                  </span>
                </p>
              );
            })}
          </div>
        </div>

        <hr />

        <p className="text-center small text-secondary mb-0">
          &copy; {new Date().getFullYear()} 3D Print Service. Seluruh hak cipta
          dilindungi. <span aria-hidden="true">· </span><Link className="footer-admin-link" to="/admin/login">Admin</Link>
        </p>
      </div>
    </footer>
  );
}

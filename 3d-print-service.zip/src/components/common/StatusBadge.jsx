import { workflowStage, requestBadgeVariant, PUBLIC_STAGE_LABEL } from '../../utils/workflow';
import { REQUEST_STATUS_LABEL, REQUEST_STATUS_BADGE_VARIANT } from '../../utils/constants';

export default function StatusBadge({ status, request }) {
  const label = request?.publicOnly ? PUBLIC_STAGE_LABEL[request.stage]||'Belum tersedia' : request?.pricingVersion ? workflowStage(request).label : REQUEST_STATUS_LABEL[status] || status;
  const variant = request?.pricingVersion||request?.publicOnly ? requestBadgeVariant(request) : REQUEST_STATUS_BADGE_VARIANT[status] || 'secondary';
  return <span className={`badge bg-${variant}-subtle text-${variant}-emphasis border border-${variant}-subtle`}>{label}</span>;
}

import { useState } from 'react';
import Swal from 'sweetalert2';
import Modal from './Modal';
import WhatsAppButton from './WhatsAppButton';
import { useSettings } from '../../context/SettingsContext';
import { claimRequestAccess, editOwnRequest, cancelOwnRequest } from '../../services/requestManagementService';
import { applicantMessage, canManageRequest, savedManagementKey, rememberManagementKey } from '../../utils/requestManagement';
import { changeNeed, getRate, rupiah } from '../../utils/billing';
import { defaultPicIndex } from '../../utils/waLink';
import RequestLinkPanel from './RequestLinkPanel';

export { default as PrivateEditLink } from './PrivateEditLink';

function EditRequest({request:r,accessKey,onClose,onSaved}){
  const settings=useSettings(),lecturers=settings.lecturers||[];
  const [form,setForm]=useState({...r}),[busy,setBusy]=useState(false),[error,setError]=useState('');
  const change=e=>{const {name,value}=e.target;setForm(prev=>{
    if(name==='kebutuhan')return changeNeed(prev,value);
    return {...prev,[name]:value,...(name==='dosenId'?{dosenPembimbing:lecturers.find(d=>d.id===value)?.name||''}:{})};
  });};
  const field=(name,label,{type='text',required=true,maxLength=200}={})=><div className="col-sm-6"><label className="form-label small" htmlFor={`edit-${name}`}>{label}</label><input id={`edit-${name}`} className="form-control form-control-sm" name={name} type={type} required={required} maxLength={maxLength} value={form[name]||''} onChange={change}/></div>;
  return <Modal title={`Edit Pengajuan ${r.trackingCode}`} wide onClose={()=>{if(!busy)onClose();}} footer={<><button className="btn btn-sm btn-outline-secondary" disabled={busy} onClick={onClose}>Kembali</button><button form={`edit-request-${r.id}`} type="submit" className="btn btn-sm btn-primary" disabled={busy}>{busy?'Menyimpan…':'Simpan Perubahan'}</button></>}>
    <p className="small text-secondary">Setelah disimpan, operator memeriksa ulang file dan biaya. Kode tetap sama. Jika sudah mengirim form pembimbing, kirim ulang sesuai rincian terbaru.</p>
    {error&&<div className="alert alert-danger small py-2" role="alert">{error}</div>}
    <form id={`edit-request-${r.id}`} onSubmit={async e=>{e.preventDefault();setBusy(true);setError('');try{await editOwnRequest(r,form,accessKey);onSaved('Perubahan tersimpan. Konfirmasikan revisi kepada Nabil atau Salza melalui WhatsApp.');}catch(err){setError(err.message);}finally{setBusy(false);}}}>
      <fieldset disabled={busy}>
        <h6 className="fw-bold">Data Pemohon</h6><div className="row g-2 mb-3">
          <div className="col-sm-6"><label className="form-label small" htmlFor="edit-jenis">Jenis pemohon</label><select id="edit-jenis" className="form-select form-select-sm" name="jenisPemohon" value={form.jenisPemohon} onChange={change}><option value="mahasiswa">Mahasiswa</option><option value="dosen">Dosen</option></select></div>
          {field('nama','Nama lengkap')}{field('nim',form.jenisPemohon==='dosen'?'NIP / identitas (opsional)':'NIM',{required:form.jenisPemohon!=='dosen',maxLength:100})}{field('prodi','Program Studi pemohon')}{field('whatsapp','Nomor WhatsApp',{type:'tel',maxLength:30})}{field('email','Email SSO',{type:'email',maxLength:250})}
        </div>
        <h6 className="fw-bold border-top pt-3">Detail Pengajuan</h6><div className="row g-2 mb-3">
          <div className="col-sm-6"><label className="form-label small" htmlFor="edit-kebutuhan">Kebutuhan cetak</label><select id="edit-kebutuhan" name="kebutuhan" className="form-select form-select-sm" value={form.kebutuhan} onChange={change}><option value="elektro">Elektro</option><option value="luar">Luar Elektro</option></select><small className="text-secondary">Internal Elektro: akademik, PKE, MBKM, riset dengan pembimbing PSTE. Kebutuhan umum atau pembimbing di luar PSTE: Luar Elektro.</small></div>
          {form.kebutuhan==='elektro'&&<div className="col-sm-6"><label className="form-label small" htmlFor="edit-dosen">Dosen Pembimbing / Pengampu</label><select id="edit-dosen" name="dosenId" className="form-select form-select-sm" value={form.dosenId||''} required onChange={change}><option value="">Pilih dosen</option>{lecturers.map(d=><option key={d.id} value={d.id}>{d.name}</option>)}</select></div>}
          {field('keperluan','Keperluan cetak',{maxLength:500})}
          <div className="col-sm-6"><label className="form-label small" htmlFor="edit-filamen">Sumber filamen</label><select id="edit-filamen" name="sumberFilamen" className="form-select form-select-sm" value={form.sumberFilamen} onChange={change}><option value={form.kebutuhan==='luar'?'pengelola':'prodi'}>{form.kebutuhan==='luar'?'Filamen pengelola':'Filamen prodi'}</option><option value="sendiri">Bawa sendiri</option></select><small className="text-secondary">Tarif {rupiah(getRate(form))}/gram. Total diperiksa ulang operator.</small></div>
          <div className="col-sm-6"><label className="form-label small" htmlFor="edit-pembayaran">Metode pembayaran</label><select id="edit-pembayaran" name="metodePembayaran" className="form-select form-select-sm" value={form.metodePembayaran} onChange={change}><option value="tunai">Bayar langsung (tunai)</option><option value="qris">QRIS</option></select></div>
        </div>
        <h6 className="fw-bold border-top pt-3">File dan Catatan</h6><div className="row g-2">
          {field('linkStl','Link Google Drive file STL',{type:'url',maxLength:1500})}{field('linkScreenshot','Link Google Drive screenshot desain',{type:'url',maxLength:1500})}
          <div className="col-12"><small className="text-secondary">Pastikan tautan dapat dibuka operator tanpa meminta akses.</small></div>
          <div className="col-12"><label className="form-label small" htmlFor="edit-catatan">Catatan (opsional)</label><textarea id="edit-catatan" name="catatan" className="form-control form-control-sm" rows="2" maxLength={2000} value={form.catatan||''} onChange={change}/></div>
        </div>
      </fieldset>
    </form>
  </Modal>;
}

export default function RequestActions({request:r,accessKey:providedKey}){
  const settings=useSettings(),pics=settings.pics||[];
  const [pic,setPic]=useState(null),[editing,setEditing]=useState(null),[busy,setBusy]=useState(false),[error,setError]=useState(''),[notice,setNotice]=useState(''),[needsAccess,setNeedsAccess]=useState(false);
  const key=providedKey||savedManagementKey(r.trackingCode),eligible=canManageRequest(r),selected=pic!==null&&pics[pic]?pic:defaultPicIndex(pics);
  const unlock=async()=>{setError('');if(!key){setNeedsAccess(true);setError('Buka tautan edit pribadi. Jika belum punya atau pengajuan dibuat sebelumnya, minta tautan kepada Nabil atau Salza melalui WhatsApp di bawah.');return false;}setBusy(true);try{await claimRequestAccess(r.id,key);rememberManagementKey(r.trackingCode,key);return true;}catch(e){setError(e.message);return false;}finally{setBusy(false);}};
  return <section className="elektro-feature border-top pt-3 mt-3">
    <h6 className="fw-bold">Kelola Pengajuan</h6>
    {r.status==='dibatalkan'?<p className="small text-secondary">Dibatalkan oleh pemohon. Alasan: {r.cancelReason}</p>:eligible?<><p className="small text-secondary mb-2">Data dan file bisa diubah atau dibatalkan sebelum biaya disetujui.</p><div className="d-flex flex-wrap gap-2"><button className="btn btn-sm btn-outline-primary" disabled={busy} onClick={async()=>{if(await unlock())setEditing({...r});}}>Edit Pengajuan</button><button className="btn btn-sm btn-outline-danger" disabled={busy} onClick={async()=>{if(!await unlock())return;const result=await Swal.fire({title:'Batalkan pengajuan?',text:'Pengajuan tidak akan diteruskan ke proses cetak.',input:'textarea',inputLabel:'Alasan pembatalan',inputAttributes:{maxlength:500},showCancelButton:true,confirmButtonText:'Ya, batalkan pengajuan',cancelButtonText:'Kembali',inputValidator:v=>v?.trim()?undefined:'Isi alasan pembatalan.'});if(!result.isConfirmed)return;setBusy(true);setError('');try{await cancelOwnRequest(r.id,key,result.value);setNotice('Pengajuan berhasil dibatalkan.');}catch(e){setError(e.message);}finally{setBusy(false);}}}>Batalkan Pengajuan</button></div>{key&&<div className="mt-3"><RequestLinkPanel request={r} accessKey={key}/></div>}</>:<p className="small text-secondary mb-2">{r.status==='ditolak'?'Pengajuan sudah ditolak. Hubungi operator untuk pengajuan berikutnya.':'Perubahan atau pembatalan melalui operator karena pengajuan sudah diproses atau biaya sudah disetujui.'}</p>}
    {error&&<p className="small text-danger mt-2 mb-0" role="alert">{error}</p>}{notice&&<p className="small text-success mt-2 mb-0" role="status">{notice}</p>}
    <div className="mt-3"><label className="form-label small fw-semibold" htmlFor={`confirm-pic-${r.id}`}>Konfirmasi WhatsApp</label>{pics.length?<><div className="d-flex flex-wrap align-items-center gap-2"><select id={`confirm-pic-${r.id}`} className="form-select form-select-sm" style={{width:'auto',maxWidth:'100%'}} value={selected} onChange={e=>setPic(Number(e.target.value))}>{pics.map((p,i)=><option key={i} value={i}>{p.name}</option>)}</select><WhatsAppButton phone={pics[selected]?.whatsapp} label={`Konfirmasi ke ${pics[selected]?.name}`} message={needsAccess&&!key&&eligible?`Halo, saya ${r.nama}, pemohon ${r.trackingCode}.\nSaya ingin mengubah atau membatalkan pengajuan. Mohon bantu verifikasi identitas saya dan berikan tautan edit pribadi. Terima kasih.`:applicantMessage(r)}/></div><p className="small text-secondary mt-2 mb-0">Periksa pesan sebelum mengirim di WhatsApp.</p></>:<p className="small text-secondary">Kontak operator belum tersedia. Silakan coba kembali.</p>}</div>
    {editing&&<EditRequest request={editing} accessKey={key} onClose={()=>setEditing(null)} onSaved={message=>{setEditing(null);setNotice(message);}}/>}
  </section>;
}

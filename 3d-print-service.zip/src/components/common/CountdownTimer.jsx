import { useEffect, useState } from 'react';

function formatDiff(ms) {
  if (ms <= 0) return '00:00:00';
  const totalSeconds = Math.floor(ms / 1000);
  const h = String(Math.floor(totalSeconds / 3600)).padStart(2, '0');
  const m = String(Math.floor((totalSeconds % 3600) / 60)).padStart(2, '0');
  const s = String(totalSeconds % 60).padStart(2, '0');
  return `${h}:${m}:${s}`;
}

export default function CountdownTimer({ targetTime }) {
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
    const interval = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(interval);
  }, []);

  if (!targetTime) return <span className="text-secondary">-</span>;

  const diff = new Date(targetTime).getTime() - now;
  const isDone = diff <= 0;

  return (
    <span className={isDone ? 'text-danger fw-semibold' : 'fw-semibold'}>
      {isDone ? 'Waktu habis' : formatDiff(diff)}
    </span>
  );
}

import { useState } from 'react';
import { managementUrl } from '../../utils/requestManagement';

export default function PrivateEditLink({request:r,accessKey,label='Salin Tautan Edit',buttonClassName='btn btn-sm btn-outline-secondary',description='Simpan tautan ini untuk edit dari HP atau browser lain. Jangan bagikan kepada orang lain.',children}){
  const [copied,setCopied]=useState(false),[fallback,setFallback]=useState(false);
  const url=managementUrl(r,accessKey);
  return <div className="small"><div className="private-edit-actions d-flex flex-wrap align-items-center gap-2"><button type="button" className={buttonClassName} onClick={async()=>{try{await navigator.clipboard.writeText(url);setCopied(true);}catch{setFallback(true);}}}>{label}</button>{children}{copied&&<span className="text-success" role="status">Tautan tersalin.</span>}</div>{fallback&&<><label className="form-label d-block mt-2" htmlFor={`private-link-${r.id}`}>Salin tautan pribadi berikut</label><input id={`private-link-${r.id}`} className="form-control form-control-sm" readOnly value={url} onFocus={e=>e.target.select()}/></>}<p className="private-edit-description text-secondary mt-2 mb-0">{description}</p></div>;
}

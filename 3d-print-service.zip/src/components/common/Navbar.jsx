import { Link, NavLink } from 'react-router-dom';

export default function Navbar({ navOpen, setNavOpen }) {
  const closeNav = () => setNavOpen(false);

  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-white border-bottom sticky-top">
      <div className="container">
        <Link className="navbar-brand fw-bold" to="/" style={{ color: '#005BAC' }} onClick={closeNav}>
          3D Print Service
        </Link>
        <button
          className="navbar-toggler"
          type="button"
          onClick={() => setNavOpen((prev) => !prev)}
          aria-controls="mainNav"
          aria-expanded={navOpen}
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon" />
        </button>
        <div className={`collapse navbar-collapse ${navOpen ? 'show' : ''}`} id="mainNav">
          <ul className="navbar-nav ms-auto align-items-lg-center gap-lg-2">
            <li className="nav-item">
              <NavLink className="nav-link" to="/" onClick={closeNav}>
                Beranda
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink className="nav-link" to="/status-printer" onClick={closeNav}>
                Status Printer
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink className="nav-link" to="/cek-status" onClick={closeNav}>
                Cek Status
              </NavLink>
            </li>
            <li className="nav-item">
              <Link
                className="btn btn-sm text-white px-3"
                style={{ background: '#005BAC' }}
                to="/ajukan-print"
                onClick={closeNav}
              >
                Ajukan Print
              </Link>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
}
export default function Loading({ label = 'Memuat data...' }) {
  return (
    <div className="d-flex flex-column align-items-center justify-content-center py-5 text-secondary">
      <div className="spinner-border mb-2" style={{ color: '#005BAC' }} role="status" />
      <span className="small">{label}</span>
    </div>
  );
}

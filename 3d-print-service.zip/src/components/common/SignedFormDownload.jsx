import { useState } from 'react';
import { downloadSignedForm } from '../../services/sponsorshipService';
export default function SignedFormDownload({requestId,accessKey,onDownloaded}) {
 const [busy,setBusy]=useState(false),[error,setError]=useState('');
 return <div className="small my-2"><button type="button" className="btn btn-sm btn-outline-primary" disabled={busy} onClick={async()=>{setBusy(true);setError('');try{const version=await downloadSignedForm(requestId,accessKey);onDownloaded?.(version);}catch(e){setError(e.message);}finally{setBusy(false);}}}>{busy?'Menyiapkan file...':'Unduh Form Bertanda Tangan'}</button>{error&&<p role="alert" className="text-danger mt-1 mb-0">{error}</p>}</div>;
}

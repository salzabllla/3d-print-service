import { useState } from 'react';
import Swal from 'sweetalert2';
import { acceptOwnQuote } from '../../services/requestManagementService';
import { savedManagementKey } from '../../utils/requestManagement';
import { workflowStage } from '../../utils/workflow';
import { isExternal, rupiah, RATE_VERSION } from '../../utils/billing';
import SponsorshipForm from './SponsorshipForm';
export default function QuoteDecision({request:r,accessKey}) {
 const [busy,setBusy]=useState(false),[error,setError]=useState(''),[sponsor,setSponsor]=useState(false);
 const flow=workflowStage(r),key=accessKey||savedManagementKey(r.trackingCode);
 if(!['decision','sponsor'].includes(flow.key))return null;
 const canDecide=flow.key==='decision'&&r.versiTarif===RATE_VERSION;
 return <section className="border-top pt-3 mt-3 small">
  {canDecide&&<><h6 className="fw-bold">Setujui biaya untuk melanjutkan</h6><p className="text-secondary">Total akhir {rupiah(r.totalBiaya)}. Setelah disetujui, operator menyiapkan cetak. {r.totalBiaya>0?'Bayar saat mengambil hasil.':'Tidak ada pembayaran.'}</p>
  <button className="btn btn-sm btn-primary" disabled={busy} onClick={async()=>{if(!key){setError('Buka tautan pribadi yang disimpan setelah mengajukan. Jika hilang, minta bantuan Nabil melalui WhatsApp di bawah.');return;}const result=await Swal.fire({title:`Setujui biaya ${rupiah(r.totalBiaya)}?`,text:'Setelah disetujui, perubahan atau pembatalan melalui operator.',icon:'question',showCancelButton:true,confirmButtonText:'Setujui Biaya',cancelButtonText:'Periksa Lagi'});if(!result.isConfirmed)return;setBusy(true);setError('');try{await acceptOwnQuote(r,key);}catch(e){setError(e.message);}finally{setBusy(false);}}}>{busy?'Menyimpan...':r.totalBiaya>0?'Setujui dan Bayar saat Pengambilan':'Setujui Cetak Tanpa Biaya'}</button>
  {!isExternal(r)&&r.totalBiaya>0&&<p className="text-secondary mt-3 mb-2">Jika keberatan biaya, ajukan form bertanda tangan pembimbing. Setelah diverifikasi operator, cetak dilanjutkan dan biaya ditagihkan ke pembimbing.</p>}
  {!isExternal(r)&&r.totalBiaya>0&&<button className="btn btn-sm btn-outline-primary ms-sm-2 mt-2 mt-sm-0" onClick={()=>setSponsor(!sponsor)}>Ajukan Biaya ke Pembimbing</button>}
  <p className="text-secondary mt-2 mb-0">Jika rincian belum sesuai, ubah pengajuan atau hubungi operator sebelum menyetujui.</p></>}
  {!canDecide&&flow.key==='decision'&&<p className="text-secondary">Tarif perlu diperbarui operator. Tunggu penawaran terbaru sebelum menyetujui.</p>}
  {(sponsor||flow.key==='sponsor')&&<SponsorshipForm request={r} accessKey={key}/>}
  {error&&<p role="alert" className="text-danger mt-2 mb-0">{error}</p>}
 </section>;
}

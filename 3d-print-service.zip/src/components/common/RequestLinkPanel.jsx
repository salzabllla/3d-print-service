import { FiCopy, FiLink, FiLock } from 'react-icons/fi';
import PrivateEditLink from './PrivateEditLink';

export default function RequestLinkPanel({request,accessKey,children}){
  const titleId=`request-link-title-${request.id}`;
  return <section className="request-link-panel border rounded bg-light p-3" aria-labelledby={titleId}>
    <h2 id={titleId} className="h6 fw-semibold d-flex align-items-center gap-2 mb-2"><FiLink className="text-primary" aria-hidden="true"/>Tautan pengajuan</h2>
    <p className="mb-3">Wajib salin dan simpan tautan ini untuk cek status, edit, atau membatalkan pengajuan.<span className="request-link-note d-block">Tanpa tautan ini, kamu tidak bisa mengedit atau membatalkan pengajuan dari HP atau browser lain.</span></p>
    <PrivateEditLink request={request} accessKey={accessKey}
      label={<><FiCopy className="me-2" aria-hidden="true"/>Salin Tautan</>}
      buttonClassName="btn btn-sm btn-primary"
      description={<><FiLock className="me-1" aria-hidden="true"/>Tautan pribadi untuk rincian dan invoice. Jangan dibagikan.</>}>
      {children}
    </PrivateEditLink>
  </section>;
}

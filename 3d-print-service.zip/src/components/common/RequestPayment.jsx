import { savedManagementKey } from '../../utils/requestManagement';
import { useState } from 'react';
import CostBreakdown from './CostBreakdown';
import { hasQuote, sponsorApproved } from '../../utils/sponsorship';
import Invoice from './Invoice';
import PaymentHistory from './PaymentHistory';
import QrisPayment from './QrisPayment';
import { submitPaymentProof } from '../../services/requestService';
import { readyForQueue } from '../../utils/workflow';
import { paymentSettled, amountReceived, outstandingAmount, rupiah } from '../../utils/billing';
export default function RequestPayment({request:r,byCode,accessKey}){
 const [proof,setProof]=useState(''),[busy,setBusy]=useState(false),[error,setError]=useState('');
 if(r.status==='dibatalkan')return <p className="small text-secondary border-top pt-3 mt-3 mb-0">Pengajuan dibatalkan. Tidak ada pembayaran yang perlu dilakukan.</p>;
 if(!r.pricingVersion)return <p className="small text-secondary mt-2 mb-0">Data lama; tidak ada tagihan baru untuk pengajuan ini.</p>;
 const paid=paymentSettled(r),sponsored=sponsorApproved(r);
 return <section className="elektro-feature border-top mt-3 pt-3">
  <h6 className="fw-bold">Rincian Pembayaran</h6>
  {hasQuote(r)?<><CostBreakdown request={r}/><p className="small text-secondary mt-2 mb-2">Persetujuan biaya: {readyForQueue(r)?'Sudah disetujui':r.formPembimbingStatus==='pending'?'Menunggu pemeriksaan form':'Belum disetujui'}</p></>:<p className="small text-secondary">Menunggu operator memeriksa file dan mengonfirmasi biaya.</p>}
  <p className="small mb-2">Metode: {(r.preferredPaymentMethod||r.metodePembayaran)==='qris'?'QRIS':'Tunai'} · Status: <strong>{r.paymentStatus==='waived'?'Tanpa biaya':paid?'Lunas':amountReceived(r)>0?'Dibayar sebagian':sponsored?'Ditagihkan ke pembimbing':r.paymentStatus==='pending'?'Bukti menunggu verifikasi':'Belum bayar'}</strong></p>
  {amountReceived(r)>0&&<p className="small mb-2">Sudah dibayar: <strong>{rupiah(amountReceived(r))}</strong> · Sisa: <strong>{rupiah(outstandingAmount(r))}</strong>{r.paymentStatus==='pending'&&<span className="d-block text-secondary">Bukti pembayaran baru menunggu verifikasi operator.</span>}</p>}
  {!paid&&r.status!=='ditolak'&&<p className="request-payment-note text-secondary mb-2">Invoice lunas tersedia setelah pembayaran diverifikasi operator dan bisa diunduh melalui Cek Status.</p>}
  {r.status==='selesai'&&!paid&&!sponsored&&<p className="small">Bayar saat mengambil hasil cetak. Operator memverifikasi pembayaran sebelum menyerahkan hasil dan nota lunas.</p>}
  {byCode&&(r.preferredPaymentMethod||r.metodePembayaran)==='qris'&&!paid&&!sponsored&&r.totalBiaya>0&&r.status!=='ditolak'&&<QrisPayment total={outstandingAmount(r)} ready={r.status==='selesai'}/>}
  {byCode&&(paid||sponsored||r.status==='selesai')&&<div className="mt-2"><Invoice request={r}/></div>}
  {byCode&&r.status==='selesai'&&(r.preferredPaymentMethod||r.metodePembayaran)==='qris'&&!paid&&!sponsored&&<form className="mt-3" onSubmit={async e=>{e.preventDefault();setBusy(true);setError('');try{await submitPaymentProof(r.id,proof,accessKey||savedManagementKey(r.trackingCode));setProof('');}catch(err){setError(err.message);}finally{setBusy(false);}}}><label htmlFor={`proof-${r.id}`} className="form-label small">Link Google Drive bukti pembayaran</label><input id={`proof-${r.id}`} type="url" className="form-control form-control-sm" required placeholder="https://drive.google.com/…" value={proof} onChange={e=>setProof(e.target.value)}/><div className="form-text">Pastikan operator dapat membuka tautan. Bukti diperiksa terhadap transaksi merchant.</div><button className="btn btn-sm btn-outline-primary mt-2" disabled={busy}>{busy?'Mengirim…':'Kirim Bukti ke Operator'}</button>{error&&<p className="small text-danger mt-2" role="alert">{error}</p>}</form>}
  {r.paymentSequence>0&&<PaymentHistory request={r}/>}
  {!byCode&&<p className="small text-secondary mt-2 mb-0">Gunakan kode pengajuan untuk membuka invoice dan rincian QRIS.</p>}
  <p className="small mt-2 mb-0">Pengambilan: {r.pickedUp?'Sudah diambil':'Belum diambil'}</p>
 </section>;
}

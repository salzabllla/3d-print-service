import { useEffect, useState } from 'react';
import { subscribePayments } from '../../services/paymentService';
import { rupiah, toDate } from '../../utils/billing';

export default function PaymentHistory({request:r}) {
 const {id,ownerView}=r;
 const [items,setItems]=useState(null),[error,setError]=useState('');
 useEffect(()=>subscribePayments({id,ownerView},setItems,e=>setError(e.message)),[id,ownerView]);
 return <details className="workflow-detail mt-3"><summary>Riwayat pembayaran</summary><div className="pt-2">
  {error?<p className="small text-danger" role="alert">Riwayat pembayaran gagal dimuat. Muat ulang halaman.</p>:items===null?<p className="small text-secondary" role="status">Memuat pembayaran...</p>:!items.length?<p className="small text-secondary">Pembayaran lama tercatat pada ringkasan invoice.</p>:<ol className="small ps-3 mb-0">{items.map(p=><li key={p.id} className="mb-2"><strong>{rupiah(p.nominal)} · {p.metode==='qris'?'QRIS':'Tunai'}</strong><span className="d-block">Pembayar: {p.pembayar}</span><span className="d-block text-secondary">{toDate(p.createdAt)?.toLocaleString('id-ID')}{p.refBayar?` · ${p.refBayar}`:''}</span></li>)}</ol>}
  {items?.length===30&&<p className="small text-secondary">Menampilkan 30 transaksi terakhir.</p>}
 </div></details>;
}

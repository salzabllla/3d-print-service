import { workflowStage } from '../../utils/workflow';
export default function WorkflowProgress({request}) {
 const flow=workflowStage(request);
 if(flow.step<0)return null;
 return <><ol className="workflow-progress" aria-label="Tahap pengajuan">{['Pemeriksaan','Persetujuan','Antrean','Pencetakan','Pengambilan'].map((label,index)=><li key={label} className={flow.step>index?'done':flow.step===index?'current':''} aria-label={`${index+1}. ${label}`} aria-current={flow.step===index?'step':undefined}><span>{flow.step>index?'✓':index+1}</span><small>{label}</small></li>)}</ol><p className="workflow-progress-mobile small text-secondary">{flow.step>=5?'Semua tahap selesai':`${flow.step+1} dari 5 · ${flow.label}`}</p></>;
}

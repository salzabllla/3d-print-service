import { useSettings } from '../../context/SettingsContext';
import { defaultPicIndex } from '../../utils/waLink';
import { PUBLIC_STAGE_LABEL } from '../../utils/workflow';
import StatusBadge from './StatusBadge';
import WhatsAppButton from './WhatsAppButton';
export default function PublicRequestStatus({request:r}){
 const {pics=[]}=useSettings(),pic=pics[defaultPicIndex(pics)];
 return <div className="card border-0 shadow-sm mb-3"><div className="card-body"><div className="d-flex flex-wrap justify-content-between gap-2 mb-3"><h6 className="fw-bold mb-0 text-break">{r.trackingCode}</h6><StatusBadge request={r}/></div><p className="small">Progres: <strong>{PUBLIC_STAGE_LABEL[r.stage]||'Belum tersedia'}</strong></p><p className="small text-secondary">Buka tautan pribadi yang disimpan setelah mengajukan untuk melihat rincian, mengelola pengajuan, dan mengunduh invoice.</p>{pic&&<WhatsAppButton phone={pic.whatsapp} label={`Tautan hilang? Hubungi ${pic.name}`} message={`Halo, saya ingin membuka rincian pengajuan ${r.trackingCode}, tetapi tautan pribadi saya tidak tersedia. Mohon bantu verifikasi identitas saya dan berikan tautan pribadi. Terima kasih.`}/>}</div></div>;
}

import { costLines, rupiah } from '../../utils/billing';
export default function CostBreakdown({request:r}) {
  return <div className="small mt-2" style={{maxWidth:440}}>
    <div className="text-secondary mb-2">{r.beratGram} g × {rupiah(r.tarifPerGram)}/g</div>
    {costLines(r).map(([label,amount])=><div key={label} className="d-flex justify-content-between gap-3 py-1"><span className="text-break">{label}</span><span className="text-nowrap">{rupiah(amount)}</span></div>)}
    {r.rincianVersion===1&&r.diskon>0&&<div className="d-flex justify-content-between gap-3 py-1 text-secondary"><span>Biaya awal setelah subsidi</span><span className="text-nowrap">{rupiah(r.biayaAwal)}</span></div>}
    <div className="d-flex justify-content-between gap-3 border-top pt-2 mt-1 fw-bold"><span>Total akhir</span><span className="text-nowrap">{rupiah(r.totalBiaya)}</span></div>
  </div>;
}

export default function QrisPayment() { return null; }

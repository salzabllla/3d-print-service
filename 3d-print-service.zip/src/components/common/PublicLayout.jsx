import { useState } from 'react';
import Navbar from './Navbar';
import Footer from './Footer';

export default function PublicLayout({ children }) {
  const [navOpen, setNavOpen] = useState(false);

  return (
    <div className="d-flex flex-column" style={{ minHeight: '100vh' }}>
      <Navbar navOpen={navOpen} setNavOpen={setNavOpen} />
      <div className="flex-grow-1" onClick={() => navOpen && setNavOpen(false)}>
        {children}
      </div>
      <Footer />
    </div>
  );
}
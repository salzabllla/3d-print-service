import CountdownTimer from '../common/CountdownTimer';
import { PRINTER_STATUS } from '../../utils/constants';

export default function PrinterCard({ printer, queuePosition, showDetailLink = true, onSelect, selectable = false }) {
  const isAvailable = printer.status === PRINTER_STATUS.AVAILABLE;

  return (
    <div className="card border-0 shadow-sm h-100">
      <img
        src={printer.photoUrl || 'https://placehold.co/400x220?text=Printer+3D'}
        alt={printer.name}
        className="printer-image"
        style={{ height: 180, objectFit: 'cover', borderRadius: '0.5rem 0.5rem 0 0' }}
      />
      <div className="card-body">
        <div className="d-flex justify-content-between align-items-start mb-2">
          <h5 className="card-title mb-0">{printer.name}</h5>
          <span className={`badge ${isAvailable ? 'bg-success-subtle text-success-emphasis' : 'bg-danger-subtle text-danger-emphasis'} border`}>
            {isAvailable ? 'Available' : 'In Use'}
          </span>
        </div>
        <p className="text-secondary small mb-2">{printer.model}</p>

        {!isAvailable && (
          <div className="bg-light rounded p-2 mb-2 small">
            <div>Selesai estimasi: <strong>{printer.jamSelesai ? new Date(printer.jamSelesai).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }) : '-'}</strong></div>
            <div>
              Sisa waktu: <CountdownTimer targetTime={printer.jamSelesai} />
            </div>
          </div>
        )}

        {typeof queuePosition === 'number' && queuePosition > 0 && (
          <p className="small text-secondary mb-2">{queuePosition} lagi menunggu di printer ini</p>
        )}

        {selectable && (
          <button
            className="btn btn-sm w-100 text-white"
            style={{ background: '#005BAC' }}
            onClick={() => onSelect(printer)}
          >
            Pilih Printer Ini
          </button>
        )}

        {showDetailLink && !selectable && (
          <p className="text-secondary small mb-0 mt-2">
            Spesifikasi: {printer.specs}
          </p>
        )}
      </div>
    </div>
  );
}

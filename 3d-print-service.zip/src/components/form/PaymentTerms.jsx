import { useState } from 'react';
import Modal from '../common/Modal';
import { RATE_ROWS } from '../../utils/billing';
export default function PaymentTerms({onAccept,onClose,readOnly=false}) {
 const [checked,setChecked]=useState(false);
 const actions=<div className="terms-actions w-100">
   {!readOnly&&<label className="form-check mb-0"><input type="checkbox" className="form-check-input" checked={checked} onChange={e=>setChecked(e.target.checked)}/>Saya memahami ketentuan.</label>}
   <div className="d-flex justify-content-end gap-2"><button type="button" className="btn btn-sm btn-outline-secondary" onClick={onClose}>{readOnly?'Tutup':'Kembali'}</button>{!readOnly&&<button type="button" className="btn btn-sm btn-primary" disabled={!checked} onClick={onAccept}>Lanjut ke Form</button>}</div>
  </div>;
 return <Modal title="Ketentuan pembayaran" onClose={onClose} className="payment-terms-modal" footer={actions}>
  <p className="terms-intro text-secondary">Dikelola Badan Usaha HMTE. Tarif per gram:</p>
  <div className="terms-columns">
   <div>
    <table className="table table-sm terms-rates"><thead className="table-light"><tr><th>Kebutuhan</th><th>Filamen</th><th>Tarif</th></tr></thead><tbody>
     {RATE_ROWS.map(([a,b,c])=><tr key={a+b}><td>{a}</td><td>{b}</td><td className="text-nowrap">Rp{c}/g</td></tr>)}
    </tbody></table>
    <div className="terms-calculation bg-light rounded">Total = berat × tarif, dikurangi diskon.</div>
   </div>
   <div><ul className="terms-list">
    <li>Berat dan biaya dikonfirmasi operator setelah pemeriksaan file.</li>
    <li>Internal Elektro wajib pembimbing PSTE.<br/>Luar Elektro tanpa dosen.</li>
    <li>Setujui biaya di tautan pribadi Cek Status untuk masuk antrean.</li>
    <li>Bayar tunai/QRIS saat pengambilan. Invoice lunas setelah pembayaran diverifikasi.</li>
    <li>Jika untuk kebutuhan Internal Elektro dan Keberatan Biaya, maka kirim form bertanda tangan pembimbing. Setelah diverifikasi, cetak 3D dilanjutkan dan biaya akan ditagihkan ke pembimbing.</li>
   </ul></div>
  </div>
  <details className="small text-secondary mt-2"><summary>Rincian kategori dan subsidi</summary><p className="mt-2 mb-1">Pilih berdasarkan kebutuhan kegiatan, bukan prodi pemohon. Akademik, PKE, MBKM, atau riset dengan pembimbing PSTE masuk Internal Elektro. Kebutuhan umum atau pembimbing luar PSTE masuk Luar Elektro.</p><p className="mb-0">Bahan prodi disubsidi penuh. Bahan Luar Elektro termasuk tarif. Bawa sendiri tanpa biaya bahan pengelola. Jasa mencakup operator, maintenance, dan kontribusi HMTE.</p></details>
 </Modal>;
}

const KETENTUAN_LIST = [
  'Pastikan file .STL dan screenshot desain dapat diakses melalui Google Drive.',
  'Pastikan data pengajuan yang diisi sudah benar.',
  'Pengajuan akan diproses setelah diverifikasi oleh admin.',
  'Pantau status pengajuan melalui menu Cek Status.',
  'Printer 3D hanya boleh dioperasikan oleh operator atau atas izin operator.',
];

export default function KetentuanCard({ checked, onChange, berbayar = false, tarifPerJam = 1000 }) {
  return (
    <div className="card border-0 shadow-sm mb-3">
      <div className="card-body">
        <h6 className="fw-bold mb-3">Ketentuan Pengajuan Print 3D</h6>
        <ul className="small text-secondary mb-3">
          {KETENTUAN_LIST.map((item, idx) => (
            <li key={idx}>{item}</li>
          ))}
          {berbayar && (
            <li className="text-warning-emphasis fw-semibold">
              Pengajuan untuk kebutuhan dari luar Prodi Teknik Elektro (UKM/organisasi/lomba di luar Prodi
              Elektro) dikenakan biaya sewa printer mulai{' '}
              <strong>Rp{tarifPerJam.toLocaleString('id-ID')}/jam</strong> untuk pemakaian di
              atas 1 jam, guna keperluan maintenance printer 3D dan lainnya.
            </li>
          )}
        </ul>

        {berbayar && (
          <div className="alert alert-warning py-2 px-3 small mb-3" role="alert">
            <strong>Catatan:</strong> Pengajuan ini termasuk kategori <strong>berbayar</strong>{' '}
            guna keperluan maintenance dan lainnya.
          </div>
        )}

        <div className="form-check">
          <input
            className="form-check-input"
            type="checkbox"
            id="ketentuanCheck"
            checked={checked}
            onChange={(e) => onChange(e.target.checked)}
          />
          <label className="form-check-label fw-semibold" htmlFor="ketentuanCheck">
            Saya telah membaca seluruh ketentuan.
          </label>
        </div>
      </div>
    </div>
  );
}
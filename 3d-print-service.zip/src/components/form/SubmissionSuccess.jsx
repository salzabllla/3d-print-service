import { Link } from 'react-router-dom';
import { FiCheck, FiFileText, FiSearch } from 'react-icons/fi';
import { isExternal } from '../../utils/billing';
import { SPONSOR_FORM_URL } from '../../utils/sponsorship';
import RequestLinkPanel from '../common/RequestLinkPanel';
import WhatsAppButton from '../common/WhatsAppButton';
import { managementUrl } from '../../utils/requestManagement';
import { requestMessage } from '../../utils/requestMessages';

export default function SubmissionSuccess({request,pics=[],selectedPic,onSelectPic}) {
  const url=new URL(managementUrl(request,request.managementKey));
  const statusPath=url.pathname+url.search+url.hash;
  return <main className="container elektro-feature submission-success">
    <div className="d-flex align-items-center gap-3 mb-2">
      <span className="submission-success-check" aria-hidden="true"><FiCheck/></span>
      <h1 className="fw-bold mb-0">Pengajuan berhasil dikirim</h1>
    </div>
    <div className="d-flex flex-column flex-sm-row align-items-start align-items-sm-center justify-content-between gap-2 mb-4">
      <div><span className="d-block small text-secondary mb-1">Simpan kode pengajuan untuk mengecek perkembangan</span><strong className="submission-success-code">{request.trackingCode}</strong></div>
      <span className="badge text-warning-emphasis bg-warning-subtle border border-warning-subtle fw-normal">Menunggu</span>
    </div>
    <RequestLinkPanel request={request} accessKey={request.managementKey}>
      <Link to={statusPath} className="btn btn-sm btn-outline-primary"><FiSearch className="me-2" aria-hidden="true"/>Cek Status / Edit</Link>
    </RequestLinkPanel>
    <section className="mt-3 small" aria-labelledby="submission-next-title">
      <h2 id="submission-next-title" className="h6 fw-semibold">Langkah selanjutnya</h2>
      <ol className="ps-3 mb-2"><li>Operator memeriksa file, menentukan berat dan biaya.</li><li>Setujui biaya melalui tautan pribadi sebelum masuk antrean cetak.</li><li>Pantau perkembangan melalui tautan pribadi Cek Status.</li></ol>
      {!isExternal(request)&&<p className="text-secondary mb-0">Jika keberatan biaya, <a href={SPONSOR_FORM_URL} download>unduh form</a> dan minta tanda tangan pembimbing. Setelah diverifikasi operator, cetak dilanjutkan dan biaya ditagihkan ke pembimbing.</p>}
    </section>
    <section className="mt-4" aria-labelledby="submission-contact-title">
      <h2 id="submission-contact-title" className="h6 fw-semibold mb-3">Konfirmasi pengajuan via WhatsApp</h2>
      <div className="submission-success-contact d-flex flex-wrap align-items-end gap-2">
        <div className="submission-success-operator">
          <label className="form-label small text-secondary mb-1" htmlFor="submission-operator">Operator</label>
          <select id="submission-operator" className="form-select form-select-sm" value={selectedPic} onChange={event=>onSelectPic(Number(event.target.value))}>
            {pics.map((pic,index)=><option key={index} value={index}>{pic.name}</option>)}
          </select>
        </div>
        <WhatsAppButton phone={pics[selectedPic]?.whatsapp} message={requestMessage(request,'submit')} label="Hubungi via WhatsApp"/>
      </div>
    </section>
    <section className="d-flex align-items-start gap-2 border-top pt-3 mt-4" aria-labelledby="submission-invoice-title">
      <FiFileText className="submission-success-invoice-icon text-primary" aria-hidden="true"/>
      <div><h2 id="submission-invoice-title" className="submission-success-invoice-title fw-semibold mb-1">Invoice setelah pembayaran</h2><p className="submission-success-note mb-0">Invoice lunas tersedia setelah pembayaran diverifikasi operator dan bisa diunduh melalui <strong>tautan pribadi Cek Status</strong>.</p></div>
    </section>
  </main>;
}

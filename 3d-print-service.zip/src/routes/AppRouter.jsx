import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import PublicLayout from '../components/common/PublicLayout';
import ProtectedRoute from '../components/common/ProtectedRoute';

import LandingPage from '../pages/public/LandingPage';
import StatusPrinterPage from '../pages/public/StatusPrinterPage';
import FormPengajuanPage from '../pages/public/FormPengajuanPage';
import CekStatusPage from '../pages/public/CekStatusPage';

import LoginPage from '../pages/admin/LoginPage';
import DashboardPage from '../pages/admin/DashboardPage';
import AdminGuidePage from '../pages/admin/AdminGuidePage';
import RequestDetailPage from '../pages/admin/RequestDetailPage';
import PengajuanPage from '../pages/admin/PengajuanPage';
import PrinterPage from '../pages/admin/PrinterPage';
import RiwayatPage from '../pages/admin/RiwayatPage';
import StatistikPage from '../pages/admin/StatistikPage';
import PengaturanPage from '../pages/admin/PengaturanPage';
import ProfilPage from '../pages/admin/ProfilPage';
import ArusKasPage from '../pages/admin/ArusKasPage';
import FilamenPage from '../pages/admin/FilamenPage';
import PermintaanAdminPage from '../pages/admin/PermintaanAdminPage';
import { AdminTourProvider } from '../context/AdminTourContext';

import AjukanAdminPage from '../pages/public/AjukanAdminPage';
import BuatAkunAdminPage from '../pages/public/BuatAkunAdminPage';

export default function AppRouter() {
  return (
    <BrowserRouter>
      <AdminTourProvider>
      <Routes>
        {/* Publik */}
        <Route path="/" element={<PublicLayout><LandingPage /></PublicLayout>} />
        <Route path="/status-printer" element={<PublicLayout><StatusPrinterPage /></PublicLayout>} />
        <Route path="/ajukan-print" element={<PublicLayout><FormPengajuanPage /></PublicLayout>} />
        <Route path="/cek-status" element={<PublicLayout><CekStatusPage /></PublicLayout>} />

        {/* Publik tapi tidak ditaruh di navbar hanya diakses via link langsung */}
        <Route path="/admin/ajukan-jadi-admin" element={<AjukanAdminPage />} />
        <Route path="/admin/buat-akun-admin" element={<BuatAkunAdminPage />} />

        {/* Admin */}
        <Route path="/admin" element={<Navigate to="/admin/login" replace />} />
        <Route path="/admin/login" element={<LoginPage />} />
        <Route path="/admin/dashboard" element={<ProtectedRoute><DashboardPage /></ProtectedRoute>} />
        <Route path="/admin/panduan" element={<ProtectedRoute><AdminGuidePage /></ProtectedRoute>} />
        <Route path="/admin/pengajuan" element={<ProtectedRoute><PengajuanPage /></ProtectedRoute>} />
        <Route path="/admin/pengajuan/:id" element={<ProtectedRoute><RequestDetailPage /></ProtectedRoute>} />
        <Route path="/admin/printer" element={<ProtectedRoute><PrinterPage /></ProtectedRoute>} />
        <Route path="/admin/riwayat" element={<ProtectedRoute><RiwayatPage /></ProtectedRoute>} />
        <Route path="/admin/statistik" element={<ProtectedRoute><StatistikPage /></ProtectedRoute>} />
        <Route path="/admin/arus-kas" element={<ProtectedRoute><ArusKasPage /></ProtectedRoute>} />
        <Route path="/admin/filamen" element={<ProtectedRoute><FilamenPage /></ProtectedRoute>} />
        <Route path="/admin/permintaan-admin" element={<ProtectedRoute><PermintaanAdminPage /></ProtectedRoute>} />
        <Route path="/admin/pengaturan" element={<ProtectedRoute><PengaturanPage /></ProtectedRoute>} />
        <Route path="/admin/profil" element={<ProtectedRoute><ProfilPage /></ProtectedRoute>} />
      </Routes>
      </AdminTourProvider>
    </BrowserRouter>
  );
}

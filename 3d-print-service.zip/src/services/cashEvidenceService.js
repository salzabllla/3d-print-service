import { collection, doc, getDoc, getDocs, query, orderBy, limit, runTransaction, serverTimestamp, Bytes } from 'firebase/firestore';
import { db, auth } from './firebase';
import { prepareCashEvidence } from '../utils/cashEvidence';
import { MAX_SIGNED_FORM_BYTES, signedFormType } from '../utils/signedForm';
export async function saveCashEvidence(id,{operationId,expectedVersion='',...input}) {
 if(!auth.currentUser)throw new Error('Masuk kembali sebagai pengelola.');
 if(!/^[a-zA-Z0-9-]{8,80}$/.test(operationId||''))throw new Error('Buka ulang form bukti transaksi.');
 const {bytes,...prepared}=await prepareCashEvidence(input);
 const sameEvidence=value=>['kind','name','link','note','contentHash'].every(key=>value[key]===prepared[key]);
 try{return await runTransaction(db,async tx=>{
  const ref=doc(db,'cashTransactions',id),evidenceRef=doc(db,'cashEvidence',id,'items',operationId);
  const current=(await tx.get(ref)).data(),existing=(await tx.get(evidenceRef)).data();
  if(!current)throw new Error('Transaksi tidak ditemukan.');
  if(existing){
   if(!sameEvidence(existing))throw new Error('Bukti ini sudah tersimpan dengan isi berbeda. Buka ulang form.');
   return;
  }
  if((current.proofVersion||'')!==expectedVersion)throw new Error('Bukti telah berubah. Tutup lalu buka kembali transaksi sebelum mengganti bukti.');
  if((current.proofVersion||current.bukti)&&!prepared.note)throw new Error('Isi alasan penggantian bukti.');
  tx.set(evidenceRef,{...prepared,...(bytes?{content:Bytes.fromUint8Array(bytes)}:{}),previousVersion:current.proofVersion||'',previousLink:current.proofVersion?(current.proofLink||''):(current.bukti||''),uploadedAt:serverTimestamp(),uploadedUid:auth.currentUser.uid,uploadedBy:auth.currentUser.email||auth.currentUser.uid});
  tx.update(ref,{proofLink:prepared.link,proofVersion:operationId,proofKind:prepared.kind,proofName:prepared.name,proofNote:prepared.note,proofUpdatedAt:serverTimestamp(),proofUpdatedUid:auth.currentUser.uid,proofUpdatedBy:auth.currentUser.email||auth.currentUser.uid});
 });}catch(error){
  if(!['permission-denied','aborted','already-exists'].includes(error.code))throw error;
  let existing,current;
  try{[existing,current]=await Promise.all([getDoc(doc(db,'cashEvidence',id,'items',operationId)),getDoc(doc(db,'cashTransactions',id))]);}catch{throw error;}
  if(existing.exists()&&sameEvidence(existing.data()))return;
  if(current.exists()&&(current.data().proofVersion||'')!==expectedVersion)throw new Error('Bukti telah berubah. Tutup lalu buka kembali transaksi sebelum mengganti bukti.');
  throw error;
 }
}
export async function getCashEvidence(id,version) {
 const snapshot=await getDoc(doc(db,'cashEvidence',id,'items',version));
 if(!snapshot.exists())throw new Error('Bukti tidak ditemukan.');
 return {id:snapshot.id,...snapshot.data()};
}
export async function getCashEvidenceHistory(id) {
 const snapshot=await getDocs(query(collection(db,'cashEvidence',id,'items'),orderBy('uploadedAt','desc'),limit(10)));
 return snapshot.docs.map(d=>({id:d.id,...d.data()}));
}
export function downloadCashEvidence(evidence) {
 const bytes=evidence.content?.toUint8Array();
 if(!bytes||bytes.length!==evidence.size||bytes.length>MAX_SIGNED_FORM_BYTES||signedFormType(bytes)!==evidence.type)throw new Error('File bukti tidak valid. Unggah ulang bukti yang benar.');
 const url=URL.createObjectURL(new Blob([bytes],{type:evidence.type}));
 const anchor=document.createElement('a');anchor.href=url;anchor.download=evidence.name;anchor.click();
 setTimeout(()=>URL.revokeObjectURL(url),60000);
}

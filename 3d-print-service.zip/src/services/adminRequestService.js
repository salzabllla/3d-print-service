import {
  writeBatch,
  collection,
  addDoc,
  updateDoc,
  doc,
  getDocs,
  query,
  where,
  orderBy,
  onSnapshot,
  serverTimestamp,
} from 'firebase/firestore';
import { db } from './firebase';

const adminRequestsRef = collection(db, 'adminRequests');

export const ADMIN_REQUEST_STATUS = {
  PENDING: 'pending',
  APPROVED: 'approved',
  REJECTED: 'rejected',
};

export const ADMIN_ROLE_OPTIONS = ['Operator', 'Dosen Pembina'];

export async function createAdminRequest({ nama, email, peran }) {
  const payload = {
    nama,
    email: email.trim().toLowerCase(),
    peran,
    status: ADMIN_REQUEST_STATUS.PENDING,
    alasanPenolakan: null,
    accountCreated: false,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };
  const docRef = await addDoc(adminRequestsRef, payload);
  return { id: docRef.id, ...payload };
}

export function subscribeToAllAdminRequests(callback) {
  const q = query(adminRequestsRef, orderBy('createdAt', 'desc'));
  return onSnapshot(q, (snapshot) => {
    callback(snapshot.docs.map((d) => ({ id: d.id, ...d.data() })));
  });
}

export function subscribeToAdminRequestsByStatus(statusList, callback) {
  const q = query(adminRequestsRef, where('status', 'in', statusList));
  return onSnapshot(q, (snapshot) => {
    callback(snapshot.docs.map((d) => ({ id: d.id, ...d.data() })));
  });
}

export async function approveAdminRequest(id){
 const snap=await getDocs(query(adminRequestsRef,where('__name__','==',id)));
 const item=snap.docs[0]?.data();if(!item||item.status!=='pending')throw new Error('Permintaan sudah berubah. Muat ulang daftar.');
 const batch=writeBatch(db);
 batch.update(doc(db,'adminRequests',id),{status:'approved',updatedAt:serverTimestamp()});
 batch.set(doc(db,'adminApprovals',item.email.toLowerCase()),{email:item.email.toLowerCase(),requestId:id,peran:item.peran,uid:'',active:true,updatedAt:serverTimestamp()});
 await batch.commit();
}
export async function rejectAdminRequest(id,alasanPenolakan){
 const snap=await getDocs(query(adminRequestsRef,where('__name__','==',id)));
 const item=snap.docs[0]?.data();if(!item)throw new Error('Permintaan tidak ditemukan.');
 const existing=await getDocs(query(collection(db,'adminMembers'),where('requestId','==',id)));
 if(existing.docs.some(d=>d.data().bootstrapOwner))throw new Error('Akses pengelola utama perlu ditangani melalui pengelola proyek Firebase.');
 const batch=writeBatch(db);
 batch.update(doc(db,'adminRequests',id),{status:'rejected',alasanPenolakan,updatedAt:serverTimestamp()});
 batch.set(doc(db,'adminApprovals',item.email.toLowerCase()),{email:item.email.toLowerCase(),requestId:id,peran:item.peran,uid:existing.docs[0]?.id||'',active:false,updatedAt:serverTimestamp()});
 existing.docs.forEach(d=>batch.update(d.ref,{active:false,updatedAt:serverTimestamp()}));
 await batch.commit();
}

export async function markAdminRequestAccountCreated(id) {
  return updateDoc(doc(db, 'adminRequests', id), {
    accountCreated: true,
    updatedAt: serverTimestamp(),
  });
}


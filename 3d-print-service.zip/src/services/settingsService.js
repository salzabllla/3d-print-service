import { doc, getDoc, setDoc, onSnapshot } from 'firebase/firestore';
import { db } from './firebase';

const settingsDocRef = doc(db, 'settings', 'general');

export function subscribeToSettings(callback) {
  return onSnapshot(settingsDocRef, (snap) => {
    callback(snap.exists() ? snap.data() : null);
  });
}

export async function getSettings() {
  const snap = await getDoc(settingsDocRef);
  return snap.exists() ? snap.data() : null;
}

export async function updateSettings(data) {
  return setDoc(settingsDocRef, data, { merge: true });
}

import { collection, doc, setDoc, deleteDoc, onSnapshot, orderBy, query, where, limit, serverTimestamp, writeBatch } from 'firebase/firestore';
import { getMessaging, getToken, deleteToken, isSupported, onMessage } from 'firebase/messaging';
import app, { auth, db } from './firebase';
let tokenId=null;
const preferenceKey=()=>`elektro-push:${auth.currentUser?.uid || ''}`;
export function subscribeNotifications(callback,error){
 let events=[],requests=[],proofs=[],eventsReady=false,requestsReady=false,proofsReady=false,sponsors=[],sponsorsReady=false,decisions=[],decisionsReady=false;
 const emit=()=>{if(!eventsReady||!requestsReady||!proofsReady||!sponsorsReady||!decisionsReady)return;const map=new Map();for(const n of [...requests,...proofs,...sponsors,...decisions,...events])map.set(n.id,n);callback([...map.values()].sort((a,b)=>(b.createdAt?.toMillis?.()||0)-(a.createdAt?.toMillis?.()||0)).slice(0,50));};
 const a=onSnapshot(query(collection(db,'notifications'),orderBy('createdAt','desc'),limit(50)),s=>{events=s.docs.map(d=>({id:d.id,...d.data()}));eventsReady=true;emit();},error);
 const b=onSnapshot(query(collection(db,'requests'),orderBy('createdAt','desc'),limit(50)),s=>{requests=s.docs.filter(d=>d.data().pricingVersion).map(d=>{const r=d.data();return {id:`new-${d.id}`,requestId:d.id,title:'Pengajuan cetak baru',body:`${r.trackingCode} pengajuan perlu diperiksa.`,createdAt:r.createdAt};});requestsReady=true;emit();},error);
 // Payment proofs can arrive long after the request leaves the newest 50.
 const c=onSnapshot(query(collection(db,'requests'),where('paymentStatus','==','pending')),s=>{proofs=s.docs.filter(d=>d.data().pricingVersion).map(d=>{const r=d.data();return {id:`proof-${d.id}-${r.proofSubmittedAt?.toMillis?.()||''}`,requestId:d.id,title:'Konfirmasi pembayaran QRIS',body:`${r.trackingCode} bukti pembayaran perlu diperiksa.`,createdAt:r.proofSubmittedAt};});proofsReady=true;emit();},error);
 const d=onSnapshot(query(collection(db,'sponsorships'),where('status','==','pending')),s=>{sponsors=s.docs.map(d=>({id:`sponsor-${d.id}-${d.data().submittedAt?.toMillis?.()||''}`,requestId:d.id,title:'Form biaya pembimbing',body:'Form bertanda tangan perlu diperiksa.',createdAt:d.data().submittedAt}));sponsorsReady=true;emit();},error);
 const e=onSnapshot(query(collection(db,'requests'),orderBy('customerDecisionAt','desc'),limit(50)),s=>{decisions=s.docs.map(d=>{const r=d.data();return {id:`consent-${d.id}-${r.customerDecisionAt?.toMillis?.()||''}`,requestId:d.id,title:'Biaya sudah disetujui',body:`${r.trackingCode} siap disiapkan untuk cetak.`,createdAt:r.customerDecisionAt};});decisionsReady=true;emit();},error);
 return()=>{a();b();c();d();e();};
}
export function subscribeReads(uid,callback,error){return onSnapshot(collection(db,'notificationReads',uid,'items'),s=>callback(new Set(s.docs.map(d=>d.id))),error);}
export function markRead(uid,id){return setDoc(doc(db,'notificationReads',uid,'items',id),{readAt:serverTimestamp()});}
export async function markNotificationsRead(uid,ids){
 if(!uid || auth.currentUser?.uid!==uid)throw new Error('Sesi admin tidak sesuai.');
 const unique=[...new Set(ids)];
 for(let start=0;start<unique.length;start+=400){
  const batch=writeBatch(db);
  for(const id of unique.slice(start,start+400))batch.set(doc(db,'notificationReads',uid,'items',id),{readAt:serverTimestamp()});
  await batch.commit();
 }
}
export async function enablePush(){
 if(import.meta.env.VITE_ENABLE_PUSH!=='true')throw new Error('Push perangkat belum diaktifkan oleh pengelola.');
 if(!auth.currentUser)throw new Error('Login admin terlebih dahulu.');
 if(!window.isSecureContext||!await isSupported())throw new Error('Push belum didukung browser ini. Gunakan HTTPS dan browser yang mendukung notifikasi.');
 const vapidKey=import.meta.env.VITE_FIREBASE_VAPID_KEY;
 if(!vapidKey)throw new Error('Kunci Web Push Firebase belum dipasang. Hubungi pengelola.');
 const permission=await Notification.requestPermission();if(permission!=='granted')throw new Error('Izin notifikasi belum diberikan. Aktifkan melalui pengaturan situs di browser.');
 const config={apiKey:import.meta.env.VITE_FIREBASE_API_KEY,projectId:import.meta.env.VITE_FIREBASE_PROJECT_ID,messagingSenderId:import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,appId:import.meta.env.VITE_FIREBASE_APP_ID};
 const registration=await navigator.serviceWorker.register(`/firebase-messaging-sw.js?config=${encodeURIComponent(JSON.stringify(config))}`);
 await navigator.serviceWorker.ready;
 const messaging=getMessaging(app);const token=await getToken(messaging,{vapidKey,serviceWorkerRegistration:registration});
 if(!token)throw new Error('Browser belum menghasilkan token push. Coba lagi.');
 const hash=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(token));tokenId=[...new Uint8Array(hash)].map(n=>n.toString(16).padStart(2,'0')).join('');
 await setDoc(doc(db,'adminPushTokens',tokenId),{uid:auth.currentUser.uid,token,updatedAt:serverTimestamp()});
 localStorage.setItem(preferenceKey(),'enabled');
 localStorage.setItem(`${preferenceKey()}:token`,tokenId);
 return true;
}
export async function refreshPush(){if(import.meta.env.VITE_ENABLE_PUSH==='true'&&localStorage.getItem(preferenceKey())==='enabled'&&typeof Notification!=='undefined'&&Notification.permission==='granted'&&import.meta.env.VITE_FIREBASE_VAPID_KEY)return enablePush();return false;}
export async function disablePush(){
 if(!import.meta.env.VITE_FIREBASE_VAPID_KEY||!await isSupported())return;
 const id=tokenId||localStorage.getItem(`${preferenceKey()}:token`);
 if(id)await deleteDoc(doc(db,'adminPushTokens',id));
 await deleteToken(getMessaging(app));
 localStorage.removeItem(preferenceKey());localStorage.removeItem(`${preferenceKey()}:token`);tokenId=null;
}
export async function listenForeground(callback){if(!await isSupported())return()=>{};return onMessage(getMessaging(app),callback);}

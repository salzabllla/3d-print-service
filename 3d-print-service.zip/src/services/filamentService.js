import { collection, doc, onSnapshot, query, orderBy, runTransaction, serverTimestamp } from 'firebase/firestore';
import { auth,db } from './firebase';
import { filamentPricing } from '../utils/filamentPricing';
export function subscribeFilaments(callback,error){return onSnapshot(collection(db,'filaments'),s=>callback(s.docs.map(d=>({id:d.id,...d.data()})).sort((a,b)=>a.nama.localeCompare(b.nama))),error);}
export function subscribeMovements(callback,error){return onSnapshot(query(collection(db,'filamentMovements'),orderBy('createdAt','desc')),s=>callback(s.docs.map(d=>({id:d.id,...d.data()}))),error);}
export function createFilament(id,data){
 if(!data.nama?.trim()||!['prodi','pengelola'].includes(data.pemilik)||!Number.isFinite(data.gram)||data.gram<0)throw new Error('Lengkapi nama gulungan, pemilik, dan gram awal.');
 const pricing=data.beratAwalGram!==undefined?filamentPricing(data.beratAwalGram,data.hargaGulungan):{};
 const ref=doc(db,'filaments',id),move=doc(db,'filamentMovements',`initial-${id}`);
 return runTransaction(db,async tx=>{if((await tx.get(ref)).exists())return;tx.set(ref,{nama:data.nama,bahan:data.bahan||'PLA',warna:data.warna||'',pemilik:data.pemilik,...pricing,gram:data.gram,reserved:0,createdAt:serverTimestamp()});tx.set(move,{lotId:id,nama:data.nama,jenis:'Stok awal',delta:data.gram,reservedDelta:0,alasan:'Pencatatan stok awal',operator:auth.currentUser.email,createdAt:serverTimestamp()});});
}
export function adjustFilament(lotId,id,delta,alasan){
 if(!Number.isFinite(delta)||delta===0||!alasan.trim())throw new Error('Isi gram perubahan dan alasannya.');
 const ref=doc(db,'filaments',lotId),move=doc(db,'filamentMovements',id);
 return runTransaction(db,async tx=>{const existing=await tx.get(move),s=await tx.get(ref);if(existing.exists())return;if(!s.exists())throw new Error('Gulungan tidak ditemukan.');const lot=s.data();if(lot.gram+delta<(lot.reserved||0))throw new Error('Perubahan membuat stok kurang dari gram yang sudah dialokasikan untuk antrean.');tx.update(ref,{gram:lot.gram+delta,updatedAt:serverTimestamp()});tx.set(move,{lotId,nama:lot.nama,jenis:delta>0?'Tambah stok':'Kurangi stok',delta,reservedDelta:0,alasan,operator:auth.currentUser.email,createdAt:serverTimestamp()});});
}

export function updateFilamentPricing(id,data){
 const pricing=filamentPricing(data.beratAwalGram,data.hargaGulungan);
 return runTransaction(db,async tx=>{
  const ref=doc(db,'filaments',id),snap=await tx.get(ref);
  if(!snap.exists())throw new Error('Gulungan tidak ditemukan.');
  tx.update(ref,{...pricing,priceUpdatedAt:serverTimestamp()});
 });
}

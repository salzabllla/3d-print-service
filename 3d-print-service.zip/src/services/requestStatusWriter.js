import { doc, serverTimestamp } from 'firebase/firestore';
import { db } from './firebase';
import { publicRequestStatus } from '../utils/workflow';
// The request is authoritative. Its public projection contains only ID, code and stage.
export function writeRequestStatus(tx,requestRef,before,patch,database=db){
 tx.update(requestRef,patch);
 if(!before.trackingCode)return;
 tx.set(doc(database,'requestStatus',before.trackingCode),{...publicRequestStatus(requestRef.id,{...before,...patch}),updatedAt:serverTimestamp()});
}

import { writeRequestStatus } from './requestStatusWriter';
import { signInAnonymously } from 'firebase/auth';
import { doc, getDoc, setDoc, runTransaction, serverTimestamp, deleteField } from 'firebase/firestore';
import { db, managerAuth, managerDb } from './firebase';
import { canManageRequest, editPayload, quoteFields, newManagementKey, isManagementKey } from '../utils/requestManagement';

let managerSignIn;

export async function claimRequestAccess(id,key){
  if(!isManagementKey(key))throw new Error('Buka tautan edit pribadi yang diterima setelah mengajukan atau dari operator.');
  await managerAuth.authStateReady();
  try{if(!managerAuth.currentUser){managerSignIn ||= signInAnonymously(managerAuth).finally(()=>{managerSignIn=null;});await managerSignIn;}}catch(e){
    if(e.code==='auth/operation-not-allowed')throw new Error('Akses edit belum tersedia. Hubungi operator melalui WhatsApp.');
    throw new Error('Akses edit belum dapat dibuka. Periksa koneksi, lalu coba lagi.',{cause:e});
  }
  const ref=doc(managerDb,'requestManagement',id,'access',managerAuth.currentUser.uid);
  const existing=await getDoc(ref);
  if(!existing.exists()||existing.data().key!==key){
    try{await setDoc(ref,{key,createdAt:serverTimestamp()});}catch(e){throw new Error('Tautan pribadi tidak valid atau sudah diganti operator. Minta tautan terbaru.',{cause:e});}
  }
}

export async function editOwnRequest(original,form,key){
  await claimRequestAccess(original.id,key);
  const settings=await getDoc(doc(managerDb,'settings','general'));
  const data=editPayload(form,settings.data()?.lecturers||[]);
  return runTransaction(managerDb,async tx=>{
    const ref=doc(managerDb,'requests',original.id),snap=await tx.get(ref),r=snap.data();
    const sponsorRef=doc(managerDb,'sponsorships',original.id),sponsor=(await tx.get(sponsorRef)).data();
    if(!r||!canManageRequest(r))throw new Error('Pengajuan sudah diproses atau biaya sudah disetujui. Hubungi operator untuk perubahan.');
    if(r.updatedAt?.toMillis?.()!==original.updatedAt?.toMillis?.())throw new Error('Pengajuan baru saja berubah. Tutup form, periksa status terbaru, lalu edit kembali.');
    writeRequestStatus(tx,ref,r,{...data,...Object.fromEntries(quoteFields.map(k=>[k,deleteField()])),quoteStatus:'unreviewed',formPembimbingStatus:deleteField(),estimasiStatus:'belum diketahui',estimasiMenit:null,customerRevision:(r.customerRevision||0)+1,customerEditedAt:serverTimestamp(),updatedAt:serverTimestamp()},managerDb);
    if(['pending','revision'].includes(sponsor?.status))tx.update(sponsorRef,{status:'withdrawn',updatedAt:serverTimestamp()});
  });
}

export async function cancelOwnRequest(id,key,reason){
  if(!reason?.trim()||reason.trim().length>500)throw new Error('Isi alasan pembatalan (maksimal 500 karakter).');
  await claimRequestAccess(id,key);
  return runTransaction(managerDb,async tx=>{
    const ref=doc(managerDb,'requests',id),snap=await tx.get(ref),r=snap.data();
    const sponsorRef=doc(managerDb,'sponsorships',id),sponsor=(await tx.get(sponsorRef)).data();
    if(r?.status==='dibatalkan')return;
    if(!r||!canManageRequest(r))throw new Error('Pengajuan sudah diproses atau biaya sudah disetujui. Hubungi operator untuk pembatalan.');
    writeRequestStatus(tx,ref,r,{status:'dibatalkan',cancelReason:reason.trim(),cancelledAt:serverTimestamp(),updatedAt:serverTimestamp()},managerDb);
    if(['pending','revision'].includes(sponsor?.status))tx.update(sponsorRef,{status:'withdrawn',updatedAt:serverTimestamp()});
  });
}

// Only an authenticated operator can issue/recover the private link for an old request.
export async function getManagementKeyForOperator(id){
  const ref=doc(db,'requestManagement',id);
  return runTransaction(db,async tx=>{
    const request=await tx.get(doc(db,'requests',id));
    if(!request.exists())throw new Error('Pengajuan tidak ditemukan.');
    const snap=await tx.get(ref);
    if(snap.exists())return snap.data().key;
    const key=newManagementKey();tx.set(ref,{key,createdAt:serverTimestamp()});return key;
  });
}

export async function acceptOwnQuote(original,key){
 await claimRequestAccess(original.id,key);
 return runTransaction(managerDb,async tx=>{
  const ref=doc(managerDb,'requests',original.id),r=(await tx.get(ref)).data();
  const form=(await tx.get(doc(managerDb,'sponsorships',original.id))).data();
  if(r?.customerDecision==='accepted'&&r.customerQuoteTotal===original.totalBiaya)return;
  if(!r||!canManageRequest(r)||r.quoteStatus!=='quoted'||r.versiTarif!=='2026-10-v2'||r.totalBiaya!==original.totalBiaya||r.quoteUpdatedAt?.toMillis()!==original.quoteUpdatedAt?.toMillis())throw new Error('Penawaran berubah. Periksa rincian terbaru sebelum menyetujui.');
  if(['pending','revision','verified'].includes(form?.status))throw new Error('Tarik permohonan biaya pembimbing dahulu jika memilih membayar sendiri.');
  writeRequestStatus(tx,ref,r,{customerDecision:'accepted',customerQuoteTotal:r.totalBiaya,customerQuoteAt:r.quoteUpdatedAt,customerDecisionBy:managerAuth.currentUser.uid,customerDecisionAt:serverTimestamp(),updatedAt:serverTimestamp()},managerDb);
 });
}

import { writeRequestStatus } from './requestStatusWriter';
import { currentPrintAttempt, printAttemptRecord } from './printAttemptService';
import { publicRequestStatus } from '../utils/workflow';
import { lookupRequestByCode, lookupOwnRequestsByNim } from './requestStatusService';
import {
  collection,
  writeBatch,
  updateDoc,
  doc,
  getDocs,
  getDoc,
  query,
  where,
  orderBy,
  onSnapshot,
  serverTimestamp,
  runTransaction,
  deleteField,
} from 'firebase/firestore';
import { db, managerDb } from './firebase';
import { claimRequestAccess } from './requestManagementService';
import { generateTrackingCode } from '../utils/generateTrackingCode';
import { REQUEST_STATUS } from '../utils/constants';
import { auth } from './firebase';
import { calculateAutomaticQuote, calculateQuote, validateSubmission, RATE_VERSION, isExternal, paymentSettled } from '../utils/billing';
import { consentAccepted } from '../utils/workflow';
import { sponsorApproved } from '../utils/sponsorship';
import { newManagementKey, rememberManagementKey } from '../utils/requestManagement';

const requestsRef = collection(db, 'requests');

function stripUndefined(obj) {
  return Object.fromEntries(
    Object.entries(obj).filter(([, v]) => v !== undefined)
  );
}


export async function createRequest(data) {
  if(isExternal(data)) data={...data,dosenId:'',dosenPembimbing:''};
  const settings = await getDoc(doc(db, 'settings', 'general'));
  validateSubmission(data, settings.data()?.lecturers || []);

  const payload = stripUndefined({
    ...data,
    pricingVersion: RATE_VERSION,
    quoteStatus: 'unreviewed',
    paymentStatus: 'unpaid',
    pickedUp: false,
    trackingCode: generateTrackingCode(),
    status: REQUEST_STATUS.MENUNGGU,
    printerId: null,
    jamMulai: null,
    jamSelesai: null,
    alasanPenolakan: null,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });

  const docRef = doc(requestsRef), managementKey = newManagementKey();
  const batch = writeBatch(db);
  batch.set(docRef,payload);
  batch.set(doc(db,'requestStatus',payload.trackingCode),{...publicRequestStatus(docRef.id,payload),updatedAt:serverTimestamp()});
  batch.set(doc(db,'requestManagement',docRef.id),{key:managementKey,createdAt:serverTimestamp()});
  await batch.commit();
  rememberManagementKey(payload.trackingCode,managementKey);
  return { id: docRef.id, ...payload, managementKey };
}

export function subscribeToAllRequests(callback, onError) {
  const q = query(requestsRef, orderBy('createdAt', 'desc'));
  return onSnapshot(q, (snapshot) => {
    const items = snapshot.docs.map((d) => ({ id: d.id, ...d.data() }));
    callback(items);
  }, onError);
}

export function subscribeToRequestsByStatus(statusList, callback, onError) {
  const q = query(
    requestsRef,
    where('status', 'in', statusList),
    orderBy('createdAt', 'desc')
  );
  return onSnapshot(
    q,
    (snapshot) => {
      const items = snapshot.docs.map((d) => ({ id: d.id, ...d.data() }));
      callback(items);
    },
    onError
  );
}

export async function getRequestById(id) {
  const snap = await getDoc(doc(db, 'requests', id));
  if (!snap.exists()) return null;
  return { id: snap.id, ...snap.data() };
}

export async function findRequestsByNimOrCode({nim,trackingCode,accessKey}){
 if(trackingCode){const r=await lookupRequestByCode(trackingCode,accessKey);return r?[r]:[];}
 return lookupOwnRequestsByNim(nim);
}

export async function getQueuePosition(printerId, createdAt) {
  const q = query(
    requestsRef,
    where('printerId', '==', printerId),
    where('status', '==', REQUEST_STATUS.MENUNGGU)
  );
  const snap = await getDocs(q);
  const items = snap.docs
    .map((d) => ({ id: d.id, ...d.data() }))
    .filter((it) => (!it.pricingVersion || it.quoteStatus === 'approved') && it.createdAt && createdAt && it.createdAt.toMillis() < createdAt.toMillis());
  return items.length;
}

export async function acceptRequest(id, { printerId, jamMulai, estimasiMenit }) {
  if (!Number.isFinite(estimasiMenit) || estimasiMenit <= 0 || Number.isNaN(new Date(jamMulai).getTime())) throw new Error('Waktu cetak belum valid.');
  const jamMulaiDate = new Date(jamMulai);
  const jamSelesaiDate = new Date(jamMulaiDate.getTime() + estimasiMenit * 60000);
  const requestRef = doc(db, 'requests', id);
  const printerRef = doc(db, 'printers', printerId);

  return runTransaction(db, async (transaction) => {
    const requestSnap = await transaction.get(requestRef);
    const printerSnap = await transaction.get(printerRef);
    const r = requestSnap.data();
    const sponsor = (await transaction.get(doc(db,'sponsorships',id))).data();
    if (!r || ![REQUEST_STATUS.MENUNGGU, REQUEST_STATUS.ACC].includes(r.status)) throw new Error('Pengajuan tidak lagi menunggu cetak.');
    if (r.pricingVersion && r.quoteStatus !== 'approved') throw new Error('Catat persetujuan biaya dari pemohon sebelum memulai cetak.');
    if (r.printRetryPending) throw new Error('Pilih ulang gulungan untuk mengalokasikan cetak ulang terlebih dahulu.');
    if (['pending','revision'].includes(sponsor?.status)) throw new Error('Verifikasi form pembimbing sebelum mencetak, atau minta pemohon menarik permohonan jika memilih membayar sendiri.');
    if (!printerSnap.exists()) {
      throw new Error('Printer tidak ditemukan.');
    }
    if (printerSnap.data().status !== 'available') {
      throw new Error('Printer ini sedang digunakan, pilih printer lain atau tunggu selesai.');
    }

    writeRequestStatus(transaction,requestRef,r, {
      status: REQUEST_STATUS.SEDANG_PRINT,
      printerId,
      jamMulai: jamMulaiDate.toISOString(),
      jamSelesai: jamSelesaiDate.toISOString(),
      estimasiMenit,
      ...(r.pricingVersion?{printAttempt:(r.printAttempt||0)+1}:{}),
      updatedAt: serverTimestamp(),
    });

    transaction.update(printerRef, { status: 'in_use' });
  });
}

export async function rejectRequest(id, alasanPenolakan) {
  const ref=doc(db,'requests',id);
  return runTransaction(db, async tx => {
    const snap=await tx.get(ref);
    if (!snap.exists() || !['menunggu','acc'].includes(snap.data().status)) throw new Error('Hanya pengajuan yang belum dicetak dapat ditolak.');
    const r=snap.data();
    const formRef=doc(db,'sponsorships',id),form=(await tx.get(formRef)).data();
    if(r.filamentLotId&&r.quoteStatus==='approved'&&!r.printRetryPending){
      const lotRef=doc(db,'filaments',r.filamentLotId),lot=(await tx.get(lotRef)).data();
      if(!lot||(lot.reserved||0)<r.beratGram)throw new Error('Alokasi filamen perlu diperiksa sebelum penolakan.');
      tx.update(lotRef,{reserved:lot.reserved-r.beratGram});
      tx.set(doc(db,'filamentMovements',`release-${id}${r.failedPrints?`-${(r.printAttempt||0)+1}`:''}`),{lotId:r.filamentLotId,nama:lot.nama,jenis:'Lepas alokasi',delta:0,reservedDelta:-r.beratGram,trackingCode:r.trackingCode,alasan:alasanPenolakan,operator:auth.currentUser.email,createdAt:serverTimestamp()});
    }
    if(['pending','revision'].includes(form?.status))tx.update(formRef,{status:'withdrawn',updatedAt:serverTimestamp()});
    writeRequestStatus(tx,ref,r, {
    status: REQUEST_STATUS.DITOLAK,
    alasanPenolakan,
    ...(['pending','revision'].includes(form?.status)?{formPembimbingStatus:'withdrawn'}:{}),
    updatedAt: serverTimestamp(),
    });
  });
}

export async function finishRequest(id, printerId, aktualGram, expectedAttempt) {
  const requestRef = doc(db, 'requests', id);
  const printerRef = doc(db, 'printers', printerId);

  return runTransaction(db, async (transaction) => {
    const snap = await transaction.get(requestRef);
    if (!snap.exists() || snap.data().status !== REQUEST_STATUS.SEDANG_PRINT || snap.data().printerId !== printerId) throw new Error('Status cetak sudah berubah. Muat ulang data.');
    const r=snap.data();
    if(r.pricingVersion){
      if((expectedAttempt!==undefined&&expectedAttempt!==currentPrintAttempt(r))||(r.failedPrints>0&&expectedAttempt===undefined))throw new Error('Percobaan cetak sudah berubah. Muat ulang pengajuan.');
      if(!Number.isFinite(aktualGram)||aktualGram<=0)throw new Error('Isi gram aktual terpakai sebelum menyelesaikan cetak.');
      if(r.filamentLotId){
        const lotRef=doc(db,'filaments',r.filamentLotId),lot=(await transaction.get(lotRef)).data();
        if(!lot||(lot.reserved||0)<r.beratGram||lot.gram-aktualGram<(lot.reserved||0)-r.beratGram)throw new Error('Pemakaian aktual melebihi stok yang tersedia; periksa stok dan alokasi.');
        transaction.update(lotRef,{gram:lot.gram-aktualGram,reserved:lot.reserved-r.beratGram,updatedAt:serverTimestamp()});
        transaction.set(doc(db,'filamentMovements',`use-${id}${r.failedPrints?`-${currentPrintAttempt(r)}`:''}`),{lotId:r.filamentLotId,nama:lot.nama,jenis:'Pemakaian cetak',delta:-aktualGram,reservedDelta:-r.beratGram,trackingCode:r.trackingCode,alasan:'Cetak selesai; pemakaian aktual operator',operator:auth.currentUser.email,createdAt:serverTimestamp()});
      }
    }
    if(r.pricingVersion)transaction.set(doc(requestRef,'printAttempts',String(currentPrintAttempt(r))),printAttemptRecord(r,aktualGram,'succeeded'));
    writeRequestStatus(transaction,requestRef,r, {
      status: REQUEST_STATUS.SELESAI,
      ...(r.pricingVersion?{aktualGram:aktualGram+(r.failedGram||0),successfulGram:aktualGram,finishedAt:serverTimestamp()}:{}),
      updatedAt: serverTimestamp(),
    });
    transaction.update(printerRef, { status: 'available' });
  });
}

export async function deleteRequest(id) {
  const ref=doc(db,'requests',id);
  return runTransaction(db,async tx=>{const s=await tx.get(ref);if(!s.exists())return;if(s.data().failedPrints>0||s.data().paymentStatus==='paid'||s.data().status==='sedang_print'||(s.data().quoteStatus==='approved'&&s.data().status!=='ditolak'))throw new Error('Pengajuan dengan riwayat cetak gagal, pembayaran, alokasi filamen, atau sedang dicetak tidak boleh dihapus.');tx.delete(ref);if(s.data().trackingCode)tx.delete(doc(db,'requestStatus',s.data().trackingCode));});
}

export async function saveQuote(id, grams, minutes, filamentLotId='', options={}) {
  if(!Number.isFinite(minutes)||minutes<=0)throw new Error('Isi estimasi waktu cetak yang valid.');
  const ref=doc(db,'requests',id);
  return runTransaction(db,async tx=>{
    const snap=await tx.get(ref); const r=snap.data();
    if(!r?.pricingVersion||r.status!=='menunggu'||r.quoteStatus==='approved'||sponsorApproved(r)||consentAccepted(r))throw new Error('Biaya hanya dapat diubah sebelum disetujui.');
    let lot;
    if(r.sumberFilamen!=='sendiri'){
      if(!filamentLotId)throw new Error('Pilih gulungan filamen sebelum menetapkan biaya.');
      lot={id:filamentLotId,...(await tx.get(doc(db,'filaments',filamentLotId))).data()};
      if(!lot||lot.pemilik!==r.sumberFilamen)throw new Error('Pemilik gulungan tidak sesuai sumber filamen pada pengajuan.');
    }
    writeRequestStatus(tx,ref,r,{...(options.autoMaterial?calculateAutomaticQuote(r,grams,lot,options):calculateQuote(r,grams,options)),customerDecision:deleteField(),customerQuoteAt:deleteField(),customerQuoteTotal:deleteField(),customerDecisionAt:deleteField(),customerDecisionBy:deleteField(),quoteUpdatedAt:serverTimestamp(),filamentLotId:options.autoMaterial||r.sumberFilamen==='sendiri'?'':filamentLotId,estimasiMenit:minutes,estimasiStatus:'diketahui',quoteStatus:'quoted',updatedAt:serverTimestamp()});
  });
}
export async function approveQuote(id, {filamentLotId, consentViaWhatsApp=false}={}) {
  const ref=doc(db,'requests',id);
  return runTransaction(db,async tx=>{
   const snap=await tx.get(ref),r=snap.data(),retry=r?.printRetryPending===true&&r.quoteStatus==='approved';
   if(r?.quoteStatus==='approved'&&r.status==='menunggu'&&!retry)return;
   if(!r||r.status!=='menunggu'||(r.quoteStatus!=='quoted'&&!retry))throw new Error('Biaya belum siap untuk disetujui.');
   if(!retry&&r.biayaBahanOtomatis&&!consentAccepted(r)&&!sponsorApproved(r)&&!consentViaWhatsApp)throw new Error('Tunggu persetujuan pemohon atau verifikasi form pembimbing.');
   if(r.penanggungBiaya==='pembimbing'&&!sponsorApproved(r))throw new Error('Verifikasi form pembimbing sebelum melanjutkan.');
   if(!retry&&r.versiTarif!==RATE_VERSION)throw new Error('Tarif telah diperbarui. Simpan ulang biaya dan konfirmasikan nominal baru kepada pemohon.');
   if(r.sumberFilamen!=='sendiri'){
    if(retry&&!filamentLotId)throw new Error('Pilih ulang gulungan fisik untuk cetak ulang.');
    const chosenLot=filamentLotId||r.filamentLotId;
    if(!chosenLot)throw new Error('Pilih gulungan fisik yang akan dipakai mencetak.');
    const lotRef=doc(db,'filaments',chosenLot),lot=(await tx.get(lotRef)).data();
    if(!lot||lot.pemilik!==r.sumberFilamen||lot.gram-(lot.reserved||0)<r.beratGram)throw new Error('Stok tersedia tidak cukup. Tambahkan stok atau periksa gulungan.');
    tx.update(lotRef,{reserved:(lot.reserved||0)+r.beratGram});
    tx.set(doc(db,'filamentMovements',`reserve-${id}${retry?`-${currentPrintAttempt(r)+1}`:''}`),{lotId:chosenLot,nama:lot.nama,jenis:'Alokasi antrean',delta:0,reservedDelta:r.beratGram,trackingCode:r.trackingCode,alasan:retry?'Alokasi untuk cetak ulang; biaya tetap':'Biaya disetujui; alokasi untuk antrean cetak',operator:auth.currentUser.email,createdAt:serverTimestamp()});
   }
   writeRequestStatus(tx,ref,r,{quoteStatus:'approved',...(retry?{printRetryPending:false}:{}),...(filamentLotId?{filamentLotId}:{}),...(consentViaWhatsApp?{consentViaWhatsApp:true}:{}),...(r.totalBiaya===0?{paymentStatus:'waived'}:{}),approvedBy:auth.currentUser.uid,approvedAt:serverTimestamp(),updatedAt:serverTimestamp()});
  });
}
export { verifyPayment } from './paymentService';
export async function markPickedUp(id) {
  const ref=doc(db,'requests',id);
  return runTransaction(db,async tx=>{const r=(await tx.get(ref)).data();if(r?.status!=='selesai'||(r.pricingVersion&&!paymentSettled(r)&&!sponsorApproved(r)))throw new Error('Selesaikan cetak dan pembayaran sebelum penyerahan.');writeRequestStatus(tx,ref,r,{pickedUp:true,pickedUpAt:serverTimestamp(),updatedAt:serverTimestamp()});});
}
export async function submitPaymentProof(id,link,key){
 if(!/^https:\/\/(drive\.google\.com|docs\.google\.com)\//.test(link)||link.length>1500)throw new Error('Masukkan tautan bukti Google Drive yang dapat dibuka operator.');
 await claimRequestAccess(id,key);
 return updateDoc(doc(managerDb,'requests',id),{paymentProof:link,paymentStatus:'pending',proofSubmittedAt:serverTimestamp(),updatedAt:serverTimestamp()});
}

export async function recordWhatsAppConsent(original,evidence){
 if(!evidence?.trim()||evidence.length>500)throw new Error('Catat keterangan persetujuan WhatsApp (maksimal 500 karakter).');
 return runTransaction(db,async tx=>{
  const ref=doc(db,'requests',original.id),r=(await tx.get(ref)).data();
  const form=(await tx.get(doc(db,'sponsorships',original.id))).data();
  if(!r||r.status!=='menunggu'||r.quoteStatus!=='quoted'||r.versiTarif!==RATE_VERSION||r.totalBiaya!==original.totalBiaya||r.quoteUpdatedAt?.toMillis()!==original.quoteUpdatedAt?.toMillis())throw new Error('Penawaran berubah. Periksa nominal terbaru sebelum mencatat persetujuan.');
  if(['pending','revision'].includes(form?.status))throw new Error('Selesaikan pemeriksaan form atau tarik permohonan pembimbing dahulu.');
  writeRequestStatus(tx,ref,r,{customerDecision:'accepted',customerQuoteTotal:r.totalBiaya,customerQuoteAt:r.quoteUpdatedAt,customerDecisionBy:auth.currentUser.uid,customerDecisionAt:serverTimestamp(),consentViaWhatsApp:true,consentEvidence:evidence.trim(),updatedAt:serverTimestamp()});
 });
}

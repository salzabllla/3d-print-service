import { doc, getDoc, onSnapshot, runTransaction, serverTimestamp } from 'firebase/firestore';
import { db } from './firebase';
export async function hasAdminAccess(user){
 if(!user||user.isAnonymous||!user.email)return false;
 const registry=await getDoc(doc(db,'adminMembers',user.uid));
 return registry.exists()&&registry.data().active===true;
}
export function subscribeAdminAccess(user,callback,error){
 if(!user||user.isAnonymous||!user.email){callback(false);return()=>{};}
 return onSnapshot(doc(db,'adminMembers',user.uid),s=>callback(s.exists()&&s.data().active===true),e=>{callback(false);error?.(e);});
}
export async function activateApprovedAdmin(user){
 if(!user?.emailVerified||user.isAnonymous)return false;
 return runTransaction(db,async tx=>{
  const ref=doc(db,'adminApprovals',user.email.toLowerCase()),grant=(await tx.get(ref)).data();
  const profileRef=doc(db,'adminMembers',user.uid),profile=(await tx.get(profileRef)).data();
  if(profile?.active)return true;
  if(profile?.bootstrapOwner)return false;
  if(!grant?.active||grant.uid&&grant.uid!==user.uid)return false;
  const approved=(await tx.get(doc(db,'adminRequests',grant.requestId))).data();
  if(approved?.status!=='approved'||approved.email.toLowerCase()!==user.email.toLowerCase())return false;
  tx.update(ref,{uid:user.uid,updatedAt:serverTimestamp()});
  tx.set(profileRef,{email:user.email.toLowerCase(),peran:grant.peran,requestId:grant.requestId,bootstrapOwner:false,active:true,updatedAt:serverTimestamp()});
  return true;
 });
}

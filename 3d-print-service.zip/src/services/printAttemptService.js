import { collection, doc, getDoc, limit, onSnapshot, orderBy, query, runTransaction, serverTimestamp } from 'firebase/firestore';
import { auth, db } from './firebase';
import { writeRequestStatus } from './requestStatusWriter';

export const currentPrintAttempt = r => Number.isSafeInteger(r.printAttempt) && r.printAttempt > 0 ? r.printAttempt : 1;
export const needsPrintAllocation = r => r.sumberFilamen !== 'sendiri' && (r.quoteStatus !== 'approved' || r.printRetryPending === true);
export function printAttemptRecord(r, usedGram, outcome, reason = '') {
 return { attempt:currentPrintAttempt(r), outcome, usedGram, reason, printerId:r.printerId, filamentLotId:r.filamentLotId||'', startedAt:r.jamMulai, recordedBy:auth.currentUser.uid, finishedAt:serverTimestamp() };
}
export function subscribePrintAttempts(id, callback, error) {
 return onSnapshot(query(collection(db,'requests',id,'printAttempts'),orderBy('finishedAt','desc'),limit(20)),s=>callback(s.docs.map(d=>({id:d.id,...d.data()}))),error);
}
export async function failPrintRequest(r, {usedGram, reason}) {
 const note=String(reason||'').trim();
 if(!r.pricingVersion)throw new Error('Pengajuan lama tidak memiliki catatan gram. Hubungi pengelola untuk pemeriksaan manual.');
 if(!Number.isFinite(usedGram)||usedGram<0||usedGram>100000||!note||note.length>500)throw new Error('Isi gram terpakai (boleh 0) dan alasan gagal, maksimal 500 karakter.');
 const attempt=currentPrintAttempt(r),ref=doc(db,'requests',r.id),event=doc(ref,'printAttempts',String(attempt));
 try{return await runTransaction(db,async tx=>{
  const [snap,existing]=await Promise.all([tx.get(ref),tx.get(event)]);
  if(existing.exists()){
   const saved=existing.data();
   if(saved.outcome==='failed'&&saved.usedGram===usedGram&&saved.reason===note)return;
   throw new Error('Percobaan cetak ini sudah dicatat. Muat ulang pengajuan.');
  }
  const before=snap.data();
  if(!before?.pricingVersion||before.status!=='sedang_print'||before.printerId!==r.printerId||currentPrintAttempt(before)!==attempt)throw new Error('Percobaan cetak sudah berubah. Muat ulang pengajuan.');
  const printer=doc(db,'printers',before.printerId);
  if(!(await tx.get(printer)).exists())throw new Error('Printer tidak ditemukan. Periksa data printer.');
  if(before.sumberFilamen!=='sendiri'){
   if(!before.filamentLotId)throw new Error('Gulungan cetak belum tercatat. Periksa alokasi filamen.');
   const lotRef=doc(db,'filaments',before.filamentLotId),lot=(await tx.get(lotRef)).data();
   if(!lot||(lot.reserved||0)<before.beratGram||lot.gram-usedGram<(lot.reserved||0)-before.beratGram)throw new Error('Gram terpakai melebihi stok tersedia. Periksa stok dan alokasi pengajuan lain.');
   tx.update(lotRef,{gram:lot.gram-usedGram,reserved:lot.reserved-before.beratGram,updatedAt:serverTimestamp()});
   tx.set(doc(db,'filamentMovements',`failed-${r.id}-${attempt}`),{lotId:before.filamentLotId,nama:lot.nama,jenis:'Cetak gagal',delta:-usedGram,reservedDelta:-before.beratGram,trackingCode:before.trackingCode,alasan:note,operator:auth.currentUser.email,createdAt:serverTimestamp()});
  }
  tx.set(event,printAttemptRecord(before,usedGram,'failed',note));
  tx.update(printer,{status:'available'});
  writeRequestStatus(tx,ref,before,{status:'menunggu',printerId:null,jamMulai:null,jamSelesai:null,printAttempt:attempt,printRetryPending:true,failedPrints:(before.failedPrints||0)+1,failedGram:(before.failedGram||0)+usedGram,lastPrintFailureReason:note,updatedAt:serverTimestamp()});
 });}catch(error){
  // An immutable attempt may commit in another tab before this transaction's preconditions are checked.
  if(error.code==='permission-denied'){
   try{const saved=(await getDoc(event)).data();if(saved?.outcome==='failed'&&saved.usedGram===usedGram&&saved.reason===note)return;}catch{/* Preserve the original write error if the receipt cannot be read. */}
  }
  throw error;
 }
}

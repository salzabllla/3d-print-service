// Firebase v12 (modular SDK)
// Storage TIDAK digunakan (butuh Blaze Plan) file STL & screenshot memakai link Google Drive.
import { initializeApp } from 'firebase/app';
import { getAuth, connectAuthEmulator } from 'firebase/auth';
import { getFirestore, connectFirestoreEmulator } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app);
// Separate anonymous session: managing a print must never replace an admin login.
const managerApp = initializeApp(firebaseConfig, 'request-management');
export const managerAuth = getAuth(managerApp);
export const managerDb = getFirestore(managerApp);
if (import.meta.env.VITE_USE_EMULATORS === 'true') {
  if (!firebaseConfig.projectId.startsWith('demo-')) throw new Error('Pengujian emulator wajib memakai project demo.');
  connectAuthEmulator(auth, 'http://127.0.0.1:9099');
  connectFirestoreEmulator(db, '127.0.0.1', 8080);
  connectAuthEmulator(managerAuth, 'http://127.0.0.1:9099', {disableWarnings:true});
  connectFirestoreEmulator(managerDb, '127.0.0.1', 8080);
}
export default app;

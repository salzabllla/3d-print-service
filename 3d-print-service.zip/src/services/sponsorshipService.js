import { writeRequestStatus } from './requestStatusWriter';
import { doc, runTransaction, serverTimestamp, onSnapshot, getDoc, Bytes } from 'firebase/firestore';
import { db, managerDb, managerAuth, auth } from './firebase';
import { claimRequestAccess } from './requestManagementService';
import { canApplySponsorship, sponsorshipMatches } from '../utils/sponsorship';
import { prepareSignedForm, signedFormType, MAX_SIGNED_FORM_BYTES } from '../utils/signedForm';

export async function subscribeOwnSponsorship(id,key,callback,error) {
  await claimRequestAccess(id,key);
  return onSnapshot(doc(managerDb,'sponsorships',id),s=>callback(s.exists()?s.data():null),error);
}
export function subscribeSponsorship(id,callback,error) {
  return onSnapshot(doc(db,'sponsorships',id),s=>callback(s.exists()?s.data():null),error);
}
export async function submitSponsorship(id,key,source) {
  const link=typeof source==='string'?source:'';
  const file=typeof source==='string'?null:await prepareSignedForm(source);
  if(!file&&(!/^https:\/\/(drive\.google\.com|docs\.google\.com)\//.test(link)||link.length>1500))throw new Error('Gunakan tautan Google Drive untuk form yang sudah ditandatangani.');
  const fileVersion=file?crypto.randomUUID():'';
  await claimRequestAccess(id,key);
  return runTransaction(managerDb,async tx=>{
    const ref=doc(managerDb,'requests',id),r=(await tx.get(ref)).data();
    const formRef=doc(managerDb,'sponsorships',id),existing=(await tx.get(formRef)).data();
    if(!r||!canApplySponsorship(r))throw new Error('Pengajuan form tersedia untuk Internal Elektro setelah operator menetapkan biaya.');
    if(existing?.status==='verified')throw new Error('Form sudah diverifikasi operator. Hubungi operator untuk perubahan.');
    writeRequestStatus(tx,ref,r,{formPembimbingStatus:'pending',updatedAt:serverTimestamp()},managerDb);
    tx.set(formRef,{link,...(file?{fileVersion,fileName:file.name}:{}),status:'pending',totalBiaya:r.totalBiaya,dosenId:r.dosenId,customerRevision:r.customerRevision||0,quoteUpdatedAt:r.quoteUpdatedAt||null,submittedAt:serverTimestamp(),updatedAt:serverTimestamp()});
    if(file)tx.set(doc(managerDb,'sponsorshipFiles',id),{name:file.name,type:file.type,size:file.size,content:Bytes.fromUint8Array(file.bytes),fileVersion,uploadedBy:managerAuth.currentUser.uid,updatedAt:serverTimestamp()});
  });
}
export async function getSignedForm(id,key) {
  if(key)await claimRequestAccess(id,key);
  const database=key?managerDb:db;
  const [fileSnap,formSnap]=await Promise.all([getDoc(doc(database,'sponsorshipFiles',id)),getDoc(doc(database,'sponsorships',id))]);
  const file=fileSnap.data(),form=formSnap.data();
  if(!file||file.fileVersion!==form?.fileVersion)throw new Error('File form tidak tersedia.');
  const bytes=file.content.toUint8Array();
  if(bytes.length!==file.size||bytes.length>MAX_SIGNED_FORM_BYTES||signedFormType(bytes)!==file.type)throw new Error('File form tidak valid. Minta pemohon mengunggah ulang.');
  return {...file,bytes};
}
export async function downloadSignedForm(id,key) {
  const file=await getSignedForm(id,key);
  const url=URL.createObjectURL(new Blob([file.bytes],{type:file.type}));
  const anchor=document.createElement('a');anchor.href=url;anchor.download=file.name;anchor.click();
  setTimeout(()=>URL.revokeObjectURL(url),60000);
  return file.fileVersion;
}
export async function reviewSponsorship(id,accepted,reason='',expectedForm) {
  if(!accepted&&(!reason.trim()||reason.length>500))throw new Error('Isi alasan form perlu diperbaiki (maksimal 500 karakter).');
  return runTransaction(db,async tx=>{
    const ref=doc(db,'requests',id),formRef=doc(db,'sponsorships',id);
    const r=(await tx.get(ref)).data(),form=(await tx.get(formRef)).data();
    if(!r||!form||!canApplySponsorship(r)||form.status!=='pending')throw new Error('Form tidak lagi menunggu pemeriksaan.');
    if(expectedForm&&(form.fileVersion!==expectedForm.fileVersion||form.link!==expectedForm.link||form.submittedAt?.toMillis?.()!==expectedForm.submittedAt?.toMillis?.()))throw new Error('Form berubah setelah dibuka. Periksa ulang file terbaru sebelum memverifikasi.');
    if(!sponsorshipMatches(form,r))throw new Error('Data atau biaya berubah. Minta pemohon mengirim ulang form dengan rincian terbaru.');
    tx.update(formRef,{status:accepted?'verified':'revision',reason:accepted?'':reason.trim(),reviewedBy:auth.currentUser.email||auth.currentUser.uid,reviewedAt:serverTimestamp(),updatedAt:serverTimestamp()});
    writeRequestStatus(tx,ref,r,accepted?{penanggungBiaya:'pembimbing',formPembimbingStatus:'verified',formVerifiedAt:serverTimestamp(),updatedAt:serverTimestamp()}:{formPembimbingStatus:'revision',updatedAt:serverTimestamp()});
  });
}
export async function withdrawSponsorship(id,key) {
  await claimRequestAccess(id,key);
  return runTransaction(managerDb,async tx=>{
    const requestRef=doc(managerDb,'requests',id);const r=(await tx.get(requestRef)).data();
    const ref=doc(managerDb,'sponsorships',id),form=(await tx.get(ref)).data();
    if(!form||!['pending','revision'].includes(form.status))throw new Error('Permohonan tidak dapat ditarik karena sudah diverifikasi atau tidak tersedia.');
    tx.update(ref,{status:'withdrawn',updatedAt:serverTimestamp()});
    writeRequestStatus(tx,requestRef,r,{formPembimbingStatus:'withdrawn',updatedAt:serverTimestamp()},managerDb);
  });
}
export async function recordPaperSponsorship(id,reference) {
  if(!reference.trim()||reference.length>200)throw new Error('Isi nomor atau keterangan arsip form (maksimal 200 karakter).');
  return runTransaction(db,async tx=>{
    const ref=doc(db,'requests',id),r=(await tx.get(ref)).data();
    if(!r||!canApplySponsorship(r))throw new Error('Form belum dapat diterima untuk pengajuan ini.');
    tx.set(doc(db,'sponsorships',id),{link:'',paperReference:reference.trim(),status:'verified',totalBiaya:r.totalBiaya,dosenId:r.dosenId,customerRevision:r.customerRevision||0,quoteUpdatedAt:r.quoteUpdatedAt||null,reviewedBy:auth.currentUser.email||auth.currentUser.uid,reviewedAt:serverTimestamp(),updatedAt:serverTimestamp()});
    writeRequestStatus(tx,ref,r,{penanggungBiaya:'pembimbing',formPembimbingStatus:'verified',formVerifiedAt:serverTimestamp(),updatedAt:serverTimestamp()});
  });
}

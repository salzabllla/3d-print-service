import { collection, doc, getDoc, limit, onSnapshot, orderBy, query, runTransaction, serverTimestamp } from 'firebase/firestore';
import { auth, db, managerDb } from './firebase';
import { writeRequestStatus } from './requestStatusWriter';
import { amountReceived, outstandingAmount } from '../utils/billing';

export function subscribePayments(r, callback, error) {
 return onSnapshot(query(collection(r.ownerView?managerDb:db,'requestPayments',r.id,'items'),orderBy('createdAt','desc'),limit(30)),s=>callback(s.docs.map(d=>({id:d.id,...d.data()}))),error);
}
export async function verifyPayment(id, {pembayar, refBayar='', metode, nominal, operationId='full'}={}) {
 const payer=String(pembayar||'').trim(),reference=String(refBayar||'').trim();
 if(!payer||payer.length>200||reference.length>200)throw new Error('Isi nama pembayar (maksimal 200 karakter) dan referensi yang valid.');
 if(operationId!=='full'&&!/^[a-zA-Z0-9-]{8,80}$/.test(operationId))throw new Error('Buka ulang form pembayaran untuk mencoba lagi.');
 const ref=doc(db,'requests',id),receipt=doc(db,'requestPayments',id,'items',operationId),cashId=`payment-${id}${operationId==='full'?'':`-${operationId}`}`,ledger=doc(db,'cashTransactions',cashId);
 const sameReceipt=d=>d&&d.pembayar===payer&&d.refBayar===reference&&(metode===undefined||d.metode===metode)&&(nominal===undefined||d.nominal===nominal);
 try{return await runTransaction(db,async tx=>{
  const prior=await tx.get(receipt),cash=await tx.get(ledger),snap=await tx.get(ref),r=snap.data();
  if(prior.exists()){
   if(cash.exists()&&sameReceipt(prior.data()))return;
   throw new Error('Pembayaran ini sudah tercatat dengan rincian berbeda. Buka form baru untuk transaksi lain.');
  }
  if(!r?.pricingVersion||r.status!=='selesai'||!(r.totalBiaya>0))throw new Error('Pembayaran dicatat setelah cetakan selesai dan biaya tersedia.');
  if(cash.exists()){
   await tx.get(receipt);
   if(operationId==='full'&&r.paymentStatus==='paid'&&!r.paymentSequence)return;
   throw new Error('Transaksi kas sudah ada. Periksa rekonsiliasi.');
  }
  const remaining=outstandingAmount(r),actualMethod=metode??r.metodePembayaran,actualAmount=nominal??remaining;
  if(!(remaining>0)||r.paymentStatus==='waived')throw new Error('Tagihan sudah lunas atau tanpa biaya. Jangan mencatat uang yang sama lagi.');
  if(!['tunai','qris'].includes(actualMethod)||!Number.isSafeInteger(actualAmount)||actualAmount<=0||actualAmount>remaining)throw new Error('Periksa nominal: harus berupa rupiah utuh, lebih dari 0 dan tidak melebihi sisa tagihan.');
  if(operationId==='full'&&(actualAmount!==remaining||amountReceived(r)>0))throw new Error('Nominal sebagian memerlukan form pembayaran terbaru. Muat ulang halaman.');
  const totalReceived=amountReceived(r)+actualAmount,settled=totalReceived===r.totalBiaya,now=serverTimestamp(),methods=[...new Set([...(r.paymentMethods||[]),...(amountReceived(r)>0?[r.metodePembayaran]:[]),actualMethod])];
  tx.set(receipt,{requestId:id,operationId,cashId,nominal:actualAmount,metode:actualMethod,pembayar:payer,refBayar:reference,createdBy:auth.currentUser.uid,createdAt:now});
  tx.set(ledger,{requestId:id,paymentOperationId:operationId,trackingCode:r.trackingCode,nama:r.nama,pembayar:payer,refBayar:reference,kategori:'Cetak 3D',uraian:settled?'Pelunasan cetak 3D':'Pembayaran sebagian cetak 3D',...(r.rincianVersion===1?{biayaAwal:r.biayaAwal,diskon:r.diskon,alasanDiskon:r.alasanDiskon,biayaJasa:r.biayaJasa,biayaBahan:r.biayaBahan,subsidiProdi:r.subsidiProdi}:{}),metode:actualMethod,masuk:actualAmount,keluar:0,bukti:r.paymentProof||'',operator:auth.currentUser.email||auth.currentUser.uid,createdAt:now});
  writeRequestStatus(tx,ref,r,{paymentStatus:settled?'paid':'partial',paidAmount:totalReceived,paymentSequence:(r.paymentSequence||0)+1,lastPaymentId:operationId,paymentMethods:methods,preferredPaymentMethod:r.preferredPaymentMethod||r.metodePembayaran,metodePembayaran:actualMethod,pembayar:payer,refBayar:reference,verifiedUid:auth.currentUser.uid,verifiedBy:auth.currentUser.email||auth.currentUser.uid,invoiceNumber:r.trackingCode,...(settled?{paidAt:now}:{}),updatedAt:now});
 });}catch(error){
  if(error.code==='permission-denied'){
   try{const [saved,cash]=await Promise.all([getDoc(receipt),getDoc(ledger)]);if(cash.exists()&&sameReceipt(saved.data()))return;}catch{/* Keep the original failure when the committed receipt cannot be verified. */}
  }
  throw error;
 }
}

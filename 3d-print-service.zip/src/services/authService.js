import { hasAdminAccess, activateApprovedAdmin } from './adminAccessService';
import { doc, getDoc } from 'firebase/firestore';
import { db } from './firebase';
import {
  signInWithEmailAndPassword,
  signOut,
  onIdTokenChanged,
  EmailAuthProvider,
  reauthenticateWithCredential,
  updatePassword,
  verifyBeforeUpdateEmail,
} from 'firebase/auth';
import { auth } from './firebase';

export async function loginAdmin(email,password){
 const result=await signInWithEmailAndPassword(auth,email.trim().toLowerCase(),password);
 await result.user.reload();await result.user.getIdToken(true);
 if(await hasAdminAccess(result.user)||await activateApprovedAdmin(result.user))return result;
 const approval=await getDoc(doc(db,'adminApprovals',result.user.email.toLowerCase()));
 if(approval.exists()&&approval.data().active&&!result.user.emailVerified){const error=new Error('Verifikasi alamat email untuk mengaktifkan akses admin.');error.code='admin/email-unverified';throw error;}
 await signOut(auth);throw new Error('Akun ini belum memiliki akses admin yang disetujui. Hubungi pengelola.');
}

export function logoutAdmin() {
  return signOut(auth);
}

export function subscribeToAuthChanges(callback) {
  return onIdTokenChanged(auth, callback);
}

async function reauthenticate(currentPassword) {
  const user = auth.currentUser;
  if (!user || !user.email) {
    throw new Error('Tidak ada admin yang sedang login.');
  }

  const credential = EmailAuthProvider.credential(
    user.email,
    currentPassword
  );

  return reauthenticateWithCredential(user, credential);
}

export async function changePassword(currentPassword, newPassword) {
  await reauthenticate(currentPassword);
  return updatePassword(auth.currentUser, newPassword);
}

export async function changeEmail(currentPassword, newEmail) {
  await reauthenticate(currentPassword);
  return verifyBeforeUpdateEmail(
    auth.currentUser,
    newEmail.trim().toLowerCase()
  );
}
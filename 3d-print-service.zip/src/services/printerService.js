import {
  collection,
  doc,
  getDocs,
  updateDoc,
  onSnapshot,
  arrayUnion,
  serverTimestamp,
} from 'firebase/firestore';
import { db } from './firebase';

const printersRef = collection(db, 'printers');

export function subscribeToPrinters(callback, onError) {
  return onSnapshot(printersRef, (snapshot) => {
    const items = snapshot.docs.map((d) => ({ id: d.id, ...d.data() }));
    callback(items);
  }, onError);
}

export async function getAllPrinters() {
  const snap = await getDocs(printersRef);
  return snap.docs.map((d) => ({ id: d.id, ...d.data() }));
}

export async function updatePrinterPhoto(printerId, photoUrl) {
  return updateDoc(doc(db, 'printers', printerId), { photoUrl });
}

export async function updatePrinterStatus(printerId, status) {
  return updateDoc(doc(db, 'printers', printerId), { status });
}

export async function addMaintenanceLog(printerId, { catatan, oleh }) {
  return updateDoc(doc(db, 'printers', printerId), {
    maintenanceLog: arrayUnion({
      tanggal: new Date().toISOString(),
      catatan,
      oleh,
    }),
  });
}

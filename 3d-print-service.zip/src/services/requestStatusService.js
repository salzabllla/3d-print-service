import { doc, getDoc, onSnapshot } from 'firebase/firestore';
import { db, managerDb, auth } from './firebase';
import { savedManagementKey, savedManagementEntries } from '../utils/requestManagement';
import { claimRequestAccess } from './requestManagementService';

export async function lookupRequestByCode(code,providedKey){
 const trackingCode=code.trim().toUpperCase();
 if(!/^[A-Z0-9-]{3,80}$/.test(trackingCode))throw new Error('Periksa kode pengajuan.');
 const snap=await getDoc(doc(db,'requestStatus',trackingCode));
 if(!snap.exists())return null;
 const summary=snap.data(),key=providedKey||savedManagementKey(trackingCode);
 if(key){
  await claimRequestAccess(summary.requestId,key);
  const privateDoc=await getDoc(doc(managerDb,'requests',summary.requestId));
  return privateDoc.exists()?{id:privateDoc.id,...privateDoc.data(),ownerView:true}:null;
 }
 if(auth.currentUser&&!auth.currentUser.isAnonymous){
  try{const adminDoc=await getDoc(doc(db,'requests',summary.requestId));if(adminDoc.exists())return {id:adminDoc.id,...adminDoc.data(),adminView:true};}catch(e){if(e.code!=='permission-denied')throw e;}
 }
 return {id:summary.requestId,...summary,publicOnly:true};
}
export async function lookupOwnRequestsByNim(nim){
 const entries=savedManagementEntries();
 if(!entries.length)throw new Error('Gunakan kode untuk melihat progres. Untuk rincian melalui NIM, buka tautan pribadi pengajuan terlebih dahulu di perangkat ini.');
 const items=await Promise.all(entries.map(async({code,key})=>{try{return await lookupRequestByCode(code,key);}catch(e){if(['permission-denied','not-found'].includes(e.code)||/tidak valid|sudah diganti/.test(e.message))return null;throw e;}}));
 return items.filter(r=>r&&!r.publicOnly&&r.nim?.toUpperCase()===nim.trim().toUpperCase()).sort((a,b)=>(b.createdAt?.toMillis?.()||0)-(a.createdAt?.toMillis?.()||0));
}
export function subscribeVisibleRequest(r,callback,error){
 const database=r.publicOnly||r.adminView?db:managerDb,ref=doc(database,r.publicOnly?'requestStatus':'requests',r.publicOnly?r.trackingCode:r.id);
 return onSnapshot(ref,s=>callback(s.exists()?{...r,...s.data(),id:r.id}:null),error);
}

import { collection, doc, onSnapshot, query, orderBy, serverTimestamp, setDoc, runTransaction } from 'firebase/firestore';
import { db, auth } from './firebase';
import { manualCashPayload, validDate } from '../utils/cash';
export function subscribeCash(callback,error){return onSnapshot(query(collection(db,'cashTransactions'),orderBy('createdAt','asc')),s=>callback(s.docs.map(d=>({id:d.id,...d.data()}))),error);}
export function subscribeOpening(callback,error){return onSnapshot(doc(db,'cashSettings','opening'),s=>callback(s.exists()?s.data():null),error);}
export function saveOpening(amount,date){
  if(!Number.isSafeInteger(amount)||amount<0||amount>1e12||!validDate(date))throw new Error('Isi saldo awal dalam rupiah utuh dan tanggal awal pencatatan.');
  return setDoc(doc(db,'cashSettings','opening'),{amount,date,updatedAt:serverTimestamp()});
}
export async function addManualCash(kind,data,operationId){
  if(!auth.currentUser)throw new Error('Masuk kembali sebagai pengelola untuk mencatat transaksi.');
  if(!/^[a-zA-Z0-9-]{8,80}$/.test(operationId||''))throw new Error('Buka kembali form transaksi, lalu coba lagi.');
  const payload=manualCashPayload(kind,data);
  const ref=doc(db,'cashTransactions',`${kind}-${operationId}`);
  return runTransaction(db,async tx=>{
    const existing=await tx.get(ref);
    const opening=(await tx.get(doc(db,'cashSettings','opening'))).data();
    if(existing.exists()){
      if(Object.entries(payload).some(([key,value])=>existing.data()[key]!==value))throw new Error('Transaksi ini sudah disimpan. Tutup form sebelum mencatat transaksi lain.');
      return;
    }
    if(opening?.date&&payload.transactionDate<opening.date)throw new Error('Tanggal transaksi mendahului awal pencatatan. Uang yang sudah terkumpul sebelumnya dimasukkan ke saldo awal.');
    tx.set(ref,{...payload,createdBy:auth.currentUser.uid,operator:auth.currentUser.email||auth.currentUser.uid,createdAt:serverTimestamp()});
  });
}

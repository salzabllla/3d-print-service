import { createContext, useContext, useEffect, useState } from 'react';
import { subscribeToSettings } from '../services/settingsService';

const defaultSettings = {
  pics: [
    {
      name: import.meta.env.VITE_ADMIN_NAME_1 || 'Demo Admin',
      whatsapp: import.meta.env.VITE_ADMIN_WHATSAPP_1 || '0000000000',
    },
    {
      name: import.meta.env.VITE_ADMIN_NAME_2 || 'Demo Admin',
      whatsapp: import.meta.env.VITE_ADMIN_WHATSAPP_2 || '0000000000',
    },
  ],
};

const SettingsContext = createContext(defaultSettings);

export function SettingsProvider({ children }) {
  const [settings, setSettings] = useState(defaultSettings);

  useEffect(() => {
    const unsubscribe = subscribeToSettings((data) => {
      if (data) setSettings({ ...defaultSettings, ...data });
    });
    return unsubscribe;
  }, []);

  return (
    <SettingsContext.Provider value={settings}>
      {children}
    </SettingsContext.Provider>
  );
}

export function useSettings() {
  return useContext(SettingsContext);
}

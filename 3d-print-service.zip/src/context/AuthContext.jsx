import { createContext, useContext, useEffect, useState } from 'react';
import { subscribeAdminAccess } from '../services/adminAccessService';
import { subscribeToAuthChanges } from '../services/authService';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(null);
  const [isAdmin,setIsAdmin]=useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(()=>{
   let stopAccess=()=>{};
   const stopAuth=subscribeToAuthChanges(user=>{
    stopAccess();setCurrentUser(user);setIsAdmin(false);setLoading(true);
    stopAccess=subscribeAdminAccess(user,allowed=>{setIsAdmin(allowed);setLoading(false);},()=>setLoading(false));
   });
   return()=>{stopAuth();stopAccess();};
  },[]);

  const value = {
    currentUser,
    isAdmin,
    loading,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth harus dipakai di dalam AuthProvider');
  return ctx;
}

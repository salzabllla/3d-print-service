import { createContext, useContext, useEffect, useRef, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from './AuthContext';
import Modal from '../components/common/Modal';
import { ADMIN_TOUR_STEPS, readTourProgress, saveTourProgress } from '../data/adminTour';

const Context=createContext(null);
export const useAdminTour=()=>useContext(Context);
const storage=()=>{try{return window.localStorage;}catch{return null;}};

export function AdminTourProvider({children}) {
  const {currentUser,isAdmin}=useAuth(),uid=currentUser?.uid;
  const location=useLocation(),navigate=useNavigate();
  const [intro,setIntro]=useState(false),[index,setIndex]=useState(null),[factory,setFactory]=useState(null);
  const [busy,setBusy]=useState(false),[error,setError]=useState(''),[notice,setNotice]=useState('');
  const returnFocus=useRef(null),sessionUid=useRef(null),noticeTimer=useRef(null);
  const active=index!==null&&isAdmin&&uid===sessionUid.current;
  const progress=readTourProgress(uid,storage());
  const restoreFocus=()=>requestAnimationFrame(()=>{
    const target=returnFocus.current?.isConnected?returnFocus.current:document.querySelector('[data-tour-launch]');
    target?.focus();
  });
  const stop=(done=false)=>{
    saveTourProgress(uid,{index:index??0,status:done?'done':'paused'},storage());
    setIndex(null);
    setNotice(done?'Tutorial selesai. Panduan tetap tersedia di menu Panduan.':'Tutorial dijeda. Klik Tutorial untuk melanjutkan.');
    clearTimeout(noticeTimer.current);
    noticeTimer.current=setTimeout(()=>setNotice(''),7000);
    restoreFocus();
  };
  const ask=()=>{if(!isAdmin)return;returnFocus.current=document.activeElement;setError('');setIntro(true);};
  const begin=async start=>{
    setBusy(true);setError('');
    try {
      const [{driver}]=await Promise.all([import('driver.js'),import('driver.js/dist/driver.css'),import('../styles/admin-tour.css')]);
      setFactory(()=>driver);sessionUid.current=uid;setNotice('');setIntro(false);setIndex(start);
      saveTourProgress(uid,{index:start,status:'paused'},storage());
      navigate(ADMIN_TOUR_STEPS[start].route);
    } catch {setError('Tutorial belum berhasil dimuat. Coba lagi atau baca panduan di halaman ini.');}
    finally {setBusy(false);}
  };
  useEffect(()=>{
    if(!isAdmin||uid!==sessionUid.current){setIndex(null);setIntro(false);setNotice('');}
  },[uid,isAdmin]);
  useEffect(()=>()=>clearTimeout(noticeTimer.current),[]);

  useEffect(()=>{
    if(!active||!factory)return;
    const step=ADMIN_TOUR_STEPS[index];
    // A navigation target advances only after the expected route actually opens.
    if(location.pathname!==step.route){
      if(step.destination===location.pathname){setIndex(index+1);saveTourProgress(uid,{index:index+1,status:'paused'},storage());}
      else {setIndex(null);setNotice('Tutorial dijeda karena halaman berubah. Klik Tutorial untuk melanjutkan.');}
      return;
    }
    let disposed=false,instance,observer,timer,frame;
    const selector=`[data-tour="${step.target}"]`;
    const go=next=>{
      if(next>=ADMIN_TOUR_STEPS.length){stop(true);return;}
      setIndex(next);saveTourProgress(uid,{index:next,status:'paused'},storage());
      navigate(ADMIN_TOUR_STEPS[next].route);
    };
    const focusable=()=>{
      const pop=document.querySelector('.hmte-tour');
      const buttons=pop?[...pop.querySelectorAll('button:not([disabled])')].filter(el=>el.getClientRects().length):[];
      const target=step.destination&&document.querySelector(selector);
      return target?[target,...buttons]:buttons;
    };
    const keydown=e=>{
      if(e.key==='Escape'){e.preventDefault();e.stopImmediatePropagation();stop();}
      if(e.key==='Tab'){
        const nodes=focusable();if(!nodes.length)return;
        e.preventDefault();e.stopImmediatePropagation();
        const at=nodes.indexOf(document.activeElement);
        nodes[(at+(e.shiftKey?-1:1)+nodes.length)%nodes.length].focus();
      }
      if(e.key==='Enter'&&step.destination&&e.target===document.querySelector(selector)){
        e.preventDefault();navigate(step.destination);
      }
    };
    const focusin=e=>{
      const pop=document.querySelector('.hmte-tour');
      if(pop&&!pop.contains(e.target)&&!(step.destination&&e.target===document.querySelector(selector)))focusable()[0]?.focus();
    };
    const show=()=>{
      if(disposed)return;observer?.disconnect();clearTimeout(timer);
      const found=document.querySelector(selector);
      instance=factory({
        animate:false,smoothScroll:false,allowKeyboardControl:false,allowScroll:false,
        overlayClickBehavior:'none',overlayOpacity:.48,stagePadding:5,stageRadius:6,
        popoverClass:'hmte-tour',showProgress:true,progressText:'Langkah {{current}} dari {{total}}',
        nextBtnText:step.action||'Berikutnya',doneBtnText:'Selesai',prevBtnText:'Kembali',closeBtnLabel:'Jeda tutorial',
        disableActiveInteraction:!step.destination,
        onNextClick:()=>step.destination?navigate(step.destination):go(index+1),
        onPrevClick:()=>go(index-1),onDestroyStarted:()=>stop(),
        onPopoverRender:({wrapper,closeButton})=>{
          wrapper.setAttribute('aria-label',`Langkah ${index+1}: ${step.title}`);
          closeButton.setAttribute('title','Jeda tutorial');
          frame=requestAnimationFrame(()=>{(step.destination&&found?found:wrapper.querySelector('.driver-popover-next-btn'))?.focus();});
        },
        steps:ADMIN_TOUR_STEPS.map((item,i)=>({
          element:i===index&&found?found:undefined,
          popover:{title:item.title,description:item.text+(i===index&&!found?' Bagian ini belum tersedia. Kamu tetap bisa lanjut.':''),side:'bottom',align:'start'},
        })),
      });
      instance.drive(index);
      document.addEventListener('keydown',keydown,true);
      document.addEventListener('focusin',focusin,true);
    };
    // Content can arrive after a subscription or lazy route. Missing targets never strand the admin.
    if(document.querySelector(selector))show();
    else {observer=new MutationObserver(()=>{if(document.querySelector(selector))show();});observer.observe(document.body,{childList:true,subtree:true});timer=setTimeout(show,3500);}
    return()=>{disposed=true;observer?.disconnect();clearTimeout(timer);cancelAnimationFrame(frame);document.removeEventListener('keydown',keydown,true);document.removeEventListener('focusin',focusin,true);instance?.destroy();};
  },[active,index,factory,location.pathname,uid]);

  return <Context.Provider value={{ask,active,progress}}>{children}
    {intro&&isAdmin&&<Modal title="Tutorial Admin" onClose={()=>{if(!busy)setIntro(false);}} footer={<>
      <button type="button" className="btn btn-sm btn-outline-secondary" disabled={busy} onClick={()=>setIntro(false)}>Batal</button>
      {progress?.status==='paused'&&<button type="button" className="btn btn-sm btn-outline-primary" disabled={busy} onClick={()=>begin(progress.index)}>Lanjutkan</button>}
      <button type="button" className="btn btn-sm btn-primary" disabled={busy} onClick={()=>begin(0)}>{busy?'Memuat…':progress?'Ulang dari Awal':'Mulai Tutorial'}</button>
    </>}><p className="small mb-2">Ikuti sorotan, lalu klik menu yang ditunjukkan. Tutorial hanya membuka halaman dan menjelaskan tombol.</p><p className="small text-secondary mb-0">Simpan isian yang sedang dikerjakan sebelum mulai. Kamu bisa berhenti kapan saja dengan tombol tutup atau Esc.</p>{error&&<p role="alert" className="small text-danger mt-2 mb-0">{error}</p>}</Modal>}
    {notice&&isAdmin&&<div className="position-fixed bottom-0 end-0 m-3 alert alert-light border shadow-sm small" style={{zIndex:1080,maxWidth:'min(360px,90vw)'}} role="status">{notice}</div>}
  </Context.Provider>;
}

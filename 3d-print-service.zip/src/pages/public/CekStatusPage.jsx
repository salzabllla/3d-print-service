import { useState, useEffect, useRef } from 'react';
import PublicRequestStatus from '../../components/common/PublicRequestStatus';
import { subscribeVisibleRequest } from '../../services/requestStatusService';
import QuoteDecision from '../../components/common/QuoteDecision';
import WorkflowProgress from '../../components/common/WorkflowProgress';
import { workflowStage } from '../../utils/workflow';
import RequestPayment from '../../components/common/RequestPayment';
import { findRequestsByNimOrCode } from '../../services/requestService';
import { needLabel } from '../../utils/billing';
import StatusBadge from '../../components/common/StatusBadge';
import CountdownTimer from '../../components/common/CountdownTimer';
import { REQUEST_STATUS } from '../../utils/constants';
import RequestActions from '../../components/common/RequestActions';
import { isManagementKey, rememberManagementKey } from '../../utils/requestManagement';

export default function CekStatusPage() {
  const initialCode=new URLSearchParams(window.location.search).get('kode')||'';
  const [privateKey]=useState(()=>new URLSearchParams(window.location.hash.slice(1)).get('akses')||'');
  const [mode, setMode] = useState('code');
  const [inputValue, setInputValue] = useState(initialCode);
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [watchedItems,setWatchedItems]=useState([]);

  const initialSearch=useRef(false);
  const changeMode=value=>{setMode(value);setResults(null);setError('');setWatchedItems([]);};

  useEffect(()=>{const stops=watchedItems.map(item=>subscribeVisibleRequest(item,next=>setResults(prev=>(prev||[]).map(r=>r.id===item.id?next:r).filter(Boolean)),()=>setError('Akses berubah. Buka kembali tautan pribadi atau hubungi operator.')));return()=>stops.forEach(fn=>fn());},[watchedItems]);


  const handleSearch = async (e) => {
    e?.preventDefault();
    if (!inputValue.trim()) return;
    setLoading(true);
    setError('');
    setResults(null);
    setWatchedItems([]);
    try {
      const params = mode === 'nim' ? { nim: inputValue } : { trackingCode: inputValue,accessKey:inputValue.trim().toUpperCase()===initialCode.toUpperCase()?privateKey:undefined };
      const items = await findRequestsByNimOrCode(params);

      if (items.length === 0) {
        setError('Tidak ditemukan pengajuan dengan data tersebut. Periksa kembali NIM atau kode pengajuan.');
      } else {
        setResults(items);
        if(mode==='code'&&inputValue.trim().toUpperCase()===initialCode.toUpperCase()&&isManagementKey(privateKey)){
          if(rememberManagementKey(items[0].trackingCode,privateKey))window.history.replaceState(null,'',`${window.location.pathname}${window.location.search}`);
        }
        setWatchedItems(items);
      }
    } catch (e) {
      setError(e.code==='permission-denied'?'Rincian hanya tersedia melalui tautan pribadi. Hubungi operator jika tautan hilang.':e.message||'Data belum dapat dimuat. Coba lagi.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(()=>{if(!initialSearch.current){initialSearch.current=true;if(initialCode)void handleSearch();}},[]);

  return (
    <div className="container py-5" style={{ maxWidth: 640 }}>
      <h1 className="fw-bold mb-1">Cek Status Pengajuan</h1>
      <p className="text-secondary mb-4">
        Kode pengajuan untuk melihat progres. Buka tautan pribadi untuk rincian, edit, dan invoice.
      </p>

      <div className="btn-group mb-3" role="group">
        <button
          type="button"
          className={`btn btn-sm ${mode === 'nim' ? 'text-white' : 'btn-outline-secondary'}`}
          style={mode === 'nim' ? { background: '#005BAC' } : {}}
          onClick={() => changeMode('nim')}
        >
          NIM (perangkat ini)
        </button>
        <button
          type="button"
          className={`btn btn-sm ${mode === 'code' ? 'text-white' : 'btn-outline-secondary'}`}
          style={mode === 'code' ? { background: '#005BAC' } : {}}
          onClick={() => changeMode('code')}
        >
          Kode Pengajuan
        </button>
      </div>

      {mode==='nim'&&<p className="small text-secondary">Hanya pengajuan dengan tautan pribadi yang tersimpan di perangkat ini.</p>}
      <form onSubmit={handleSearch} className="d-flex gap-2 mb-4">
        <input
          className="form-control"
          placeholder={mode === 'nim' ? 'Masukkan NIM' : 'Contoh: 3DE-20260716-4F2A'}
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
        />
        <button type="submit" className="btn text-white px-4" style={{ background: '#005BAC' }} disabled={loading}>
          {loading ? '...' : 'Cek'}
        </button>
      </form>

      {error && <div className="alert alert-warning small">{error}</div>}

      {results &&
        results.map((item) => item.publicOnly?<PublicRequestStatus key={item.id} request={item}/>: (
          <div className="card border-0 shadow-sm mb-3" key={item.id}>
            <div className="card-body">
              <div className="d-flex justify-content-between align-items-start mb-2">
                <div>
                  <h6 className="fw-bold mb-0">{item.trackingCode}</h6>
                  <span className="small text-secondary">{item.nama} · {item.nim}</span>
                </div>
                <StatusBadge status={item.status} request={item} />
              </div>

              {item.pricingVersion&&<><WorkflowProgress request={item}/><p className="small text-secondary">{workflowStage(item).next}.</p></>}

              {item.failedPrints>0&&item.status==='menunggu'&&<p className="small text-secondary">Hasil cetak sebelumnya belum berhasil. Operator akan menjadwalkan cetak ulang; biaya yang disetujui tetap.</p>}

              {item.status === REQUEST_STATUS.DITOLAK && (
                <p className="small text-danger mb-0">Alasan penolakan: {item.alasanPenolakan}</p>
              )}

              {(item.status === REQUEST_STATUS.SEDANG_PRINT || item.status === REQUEST_STATUS.SELESAI) && (
                <div className="small text-secondary">
                  <div>Printer: <strong>{item.printerId || '-'}</strong></div>
                  <div>Mulai: {item.jamMulai ? new Date(item.jamMulai).toLocaleString('id-ID') : '-'}</div>
                  <div>
                    Estimasi selesai: {item.jamSelesai ? new Date(item.jamSelesai).toLocaleString('id-ID') : '-'}
                  </div>
                  {item.status === REQUEST_STATUS.SEDANG_PRINT && (
                    <div>Sisa waktu: <CountdownTimer targetTime={item.jamSelesai} /></div>
                  )}
                </div>
              )}
              <p className="small mt-2 mb-2">Kebutuhan cetak: <strong>{needLabel(item)}</strong></p><RequestPayment request={item} byCode accessKey={item.trackingCode===initialCode.toUpperCase()&&isManagementKey(privateKey)?privateKey:undefined}/>
              {<QuoteDecision request={item} accessKey={item.trackingCode===initialCode.toUpperCase()&&isManagementKey(privateKey)?privateKey:undefined}/>}
              <RequestActions request={item} accessKey={item.trackingCode===initialCode.toUpperCase()&&isManagementKey(privateKey)?privateKey:undefined}/>
            </div>
          </div>
        ))}
    </div>
  );
}

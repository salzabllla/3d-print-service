import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { FiCpu, FiClock, FiCheckCircle } from 'react-icons/fi';
import { useEffect, useState } from 'react';
import { subscribeToPrinters } from '../../services/printerService';
import PrinterCard from '../../components/printer/PrinterCard';
import Loading from '../../components/common/Loading';

export default function LandingPage() {
  const [printers, setPrinters] = useState(null);

  useEffect(() => {
    const unsub = subscribeToPrinters(setPrinters);
    return unsub;
  }, []);

  return (
    <div>
      {/* Hero */}
      <section className="py-5" style={{ background: 'linear-gradient(135deg,#005BAC 0%,#0077D6 100%)' }}>
        <div className="container py-5 text-white text-center">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="fw-bold display-6"
          >
            Layanan Print 3D Laboratorium Teknik 3D Print Service
          </motion.h1>
          <p className="lead mt-3 mb-4 opacity-75">
            Ajukan print 3D untuk skripsi, tugas akhir, PKM, lomba, ataupun proyek dosen.
          </p>
          <Link to="/ajukan-print" className="btn btn-light btn-lg fw-semibold px-4" style={{ color: '#005BAC' }}>
            Ajukan 3D Print Sekarang
          </Link>
        </div>
      </section>

      {/* Status Printer */}
      <section className="bg-light py-5">
        <div className="container">
          <div className="d-flex justify-content-between align-items-center mb-4">
            <h2 className="fw-bold mb-0">Status Printer Saat Ini</h2>
            <Link to="/status-printer" className="small">
              Lihat detail &rarr;
            </Link>
          </div>

          {!printers ? (
            <Loading label="Memuat status printer..." />
          ) : (
            <div className="row g-4">
              {printers.map((p) => (
                <div className="col-md-6" key={p.id}>
                  <PrinterCard printer={p} />
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Panduan Sistem */}
      <section className="container py-5">
        <h2 className="fw-bold text-center mb-4">Alur Pengajuan 3D Print</h2>
        <div className="row g-4">
          {[
            {
              title: '1. Isi Form Pengajuan',
              desc: 'Baca ketentuan, isi data, pilih pembimbing, sumber filamen, serta Tunai atau QRIS.',
            },
            {
              title: '2. Konfirmasi WhatsApp',
              desc: 'Kirim kode pengajuan kepada PIC melalui tombol WhatsApp setelah form tersimpan.',
            },
            {
              title: '3. Setujui Biaya',
              desc: 'Operator memeriksa file dan mengonfirmasi gram, tarif, serta total. Setelah disetujui, pengajuan masuk antrean.',
            },
            {
              title: '4. Pantau Cetak',
              desc: 'Pantau progres melalui Cek Status. Gunakan kode pengajuan untuk membuka invoice dan QRIS setelah biaya dikonfirmasi.',
            },
            {
              title: '5. Ambil Hasil dan Bayar',
              desc: 'Bayar tunai atau QRIS saat mengambil hasil. Nota lunas tersedia setelah pembayaran diverifikasi operator.',
            },
          ].map((item, idx) => (
            <div className="col-md-4" key={idx}>
              <div className="card border-0 shadow-sm h-100 p-4">
                <h5 className="fw-bold">{item.title}</h5>
                <p className="text-secondary small mb-0">{item.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="text-center py-5" style={{ background: '#EAF3FB' }}>
        <h3 className="fw-bold mb-3">Akan mengajukan print 3D?</h3>
        <Link to="/ajukan-print" className="btn text-white btn-lg px-4" style={{ background: '#005BAC' }}>
          Ajukan Print
        </Link>
      </section>
    </div>
  );
}

import { Link } from 'react-router-dom';
import { useSettings } from '../../context/SettingsContext';
import WhatsAppButton from '../../components/common/WhatsAppButton';
import { defaultPicIndex } from '../../utils/waLink';
export default function BuatAkunAdminPage(){
 const {pics=[]}=useSettings(),pic=pics[defaultPicIndex(pics)];
 return <div className="container py-5" style={{maxWidth:520}}><div className="card border-0 shadow-sm"><div className="card-body p-4"><h5 className="fw-bold text-primary">Aktivasi Akun Admin</h5><p className="small text-secondary">Akun dibuat oleh PIC setelah permintaan disetujui. Login menggunakan email yang sama. Untuk akun baru, verifikasi email sesuai petunjuk saat login.</p><div className="d-flex flex-wrap gap-2"><Link className="btn btn-sm btn-primary" to="/admin/login">Login Admin</Link>{pic&&<WhatsAppButton phone={pic.whatsapp} label={`Hubungi ${pic.name}`} message="Halo, saya ingin mengonfirmasi permintaan akses admin dan pembuatan akun 3D Print Service. Mohon bantu diperiksa, terima kasih."/>}</div><Link to="/admin/ajukan-jadi-admin" className="small d-inline-block mt-3">Ajukan akses admin</Link></div></div></div>;
}

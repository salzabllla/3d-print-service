import { useEffect, useState } from 'react';
import { subscribeToPrinters } from '../../services/printerService';
import PrinterCard from '../../components/printer/PrinterCard';
import Loading from '../../components/common/Loading';

export default function StatusPrinterPage() {
  const [printers, setPrinters] = useState(null);

  useEffect(() => {
    const unsub1 = subscribeToPrinters(setPrinters);
    return () => {
      unsub1();
    };
  }, []);

  return (
    <div className="container py-5">
      <h1 className="fw-bold mb-2">Status Printer</h1>
      <p className="text-secondary mb-4">
        Pantau ketersediaan printer 3D. Progres pengajuan dapat dilihat melalui Cek Status.
      </p>

      {!printers ? (
        <Loading label="Memuat status printer..." />
      ) : (
        <div className="row g-4">
          {printers.map((p) => (
            <div className="col-md-6" key={p.id}>
              <PrinterCard printer={p} />
            </div>
          ))}
        </div>
      )}

      <div className="alert alert-light border mt-4 small">
        Catatan: Penentuan printer yang digunakan untuk sebuah pengajuan ditentukan oleh
        operator saat persiapan cetak, berdasarkan kondisi printer (ketersediaan filamen, ukuran
        model, dan jadwal maintenance).
      </div>
    </div>
  );
}

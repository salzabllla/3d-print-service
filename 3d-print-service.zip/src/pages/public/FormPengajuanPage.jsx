import { useEffect, useState } from 'react';
import Swal from 'sweetalert2';
import { useNavigate } from 'react-router-dom';
import { createRequest } from '../../services/requestService';
import { subscribeToPrinters } from '../../services/printerService';
import { useSettings } from '../../context/SettingsContext';
import { KEPERLUAN_OPTIONS, ESTIMASI_STATUS } from '../../utils/constants';
import { isValidGoogleDriveLink, defaultPicIndex } from '../../utils/waLink';
import PaymentTerms from '../../components/form/PaymentTerms';
import { changeNeed, getRate, needLabel, filamentLabel, rupiah, validateSubmission } from '../../utils/billing';
import PrinterCard from '../../components/printer/PrinterCard';
import Loading from '../../components/common/Loading';
import SubmissionSuccess from '../../components/form/SubmissionSuccess';

const initialForm = {
  jenisPemohon: 'mahasiswa',
  kebutuhan: '',
  sumberFilamen: '',
  metodePembayaran: 'tunai',
  dosenId: '',
  nama: '',
  nim: '',
  prodi: '',
  whatsapp: '',
  email: '',
  asalPengguna: '',
  keperluan: KEPERLUAN_OPTIONS[0],
  keperluanLainnya: '',
  dosenPembimbing: '',
  linkStl: '',
  linkScreenshot: '',
  catatan: '',
};

export default function FormPengajuanPage() {
  const navigate = useNavigate();
  const settings = useSettings();
  const [termsOpen, setTermsOpen] = useState(true);
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [createdRequest, setCreatedRequest] = useState(null);
  const lecturers = settings.lecturers || [];
  const [form, setForm] = useState(initialForm);
  const estimasi = { estimasiStatus: ESTIMASI_STATUS.BELUM_DIKETAHUI, estimasiMenit: null };
  const [ketentuanChecked, setKetentuanChecked] = useState(false);
  const [printers, setPrinters] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  // Pilihan PIC tujuan konfirmasi WhatsApp (index ke settings.pics)
  const [chosenPic, setSelectedPic] = useState(null);
  const selectedPic = chosenPic ?? defaultPicIndex(settings.pics);

  useEffect(() => {
    const unsub = subscribeToPrinters(setPrinters);
    return unsub;
  }, []);

  const handleChange = (e) => {
    const {name,value}=e.target;
    setForm(prev=>{if(name==='kebutuhan')return changeNeed(prev,value);const next={...prev,[name]:value};if(name==='dosenId')next.dosenPembimbing=lecturers.find(d=>d.id===value)?.name||'';return next;});
  };

  const isLuarProdi = form.kebutuhan === 'luar';

  const validate = () => {
    try { validateSubmission(form, lecturers); } catch(err) { Swal.fire('Lengkapi data', err.message, 'warning'); return false; }

    if (
      form.keperluan === "Lainnya" &&
      !form.keperluanLainnya.trim()
    ) {
      Swal.fire(
        "Keperluan belum diisi",
        "Silakan jelaskan keperluan Anda.",
        "warning"
      );
      return false;
    }

    if (!isValidGoogleDriveLink(form.linkStl)) {
      Swal.fire('Link STL tidak valid', 'Masukkan link Google Drive (share link) yang valid untuk file STL.', 'warning');
      return false;
    }

    if (!isValidGoogleDriveLink(form.linkScreenshot)) {
      Swal.fire('Link screenshot tidak valid', 'Masukkan link Google Drive (share link) yang valid untuk screenshot desain.', 'warning');
      return false;
    }

    if (!ketentuanChecked) {
      Swal.fire('Ketentuan belum disetujui', 'Centang bahwa kamu telah membaca seluruh ketentuan.', 'warning');
      return false;
    }

    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validate()) return;

    setSubmitting(true);

    try {
      // Fix: keluarkan keperluanLainnya lewat destructuring, JANGAN di-set undefined.
      // Firestore addDoc() menolak field dengan value undefined (beda dengan null/'').
      const { keperluanLainnya, ...rest } = form;

      const payload = {
        ...rest,
        keperluan:
          form.keperluan === "Lainnya"
            ? keperluanLainnya
            : form.keperluan,
        estimasiStatus: estimasi.estimasiStatus,
        estimasiMenit:
          estimasi.estimasiStatus === ESTIMASI_STATUS.DIKETAHUI
            ? estimasi.estimasiMenit
            : null,
        nim: form.nim.trim().toUpperCase(),
        berbayar: true,
        picIndex: selectedPic,
      };
      
      const created = await createRequest(payload);
      setCreatedRequest(created);
    } catch (err) {
      Swal.fire(
        'Gagal',
        err.message || 'Terjadi kesalahan saat mengirim pengajuan.',
        'error'
      );
    } finally {
      setSubmitting(false);
    }
  };

  if (createdRequest) return <SubmissionSuccess request={createdRequest} pics={settings.pics} selectedPic={selectedPic} onSelectPic={setSelectedPic}/>;

  return (
    <div className="container py-5 elektro-feature" style={{ maxWidth: 720 }}>
      <h1 className="fw-bold mb-1">Form Pengajuan Print</h1>
      <p className="text-secondary mb-4">Isi data di bawah dengan lengkap dan benar.</p>

      <button className="btn btn-sm btn-outline-primary mb-3" onClick={()=>setTermsOpen(true)}>Lihat ketentuan pembayaran</button>
      {termsOpen&&<PaymentTerms readOnly={termsAccepted} onClose={()=>{if(termsAccepted)setTermsOpen(false);else navigate('/');}} onAccept={()=>{setTermsAccepted(true);setKetentuanChecked(true);setTermsOpen(false);}}/>}
      {termsAccepted&&<form onSubmit={handleSubmit}>
        <div className="card border-0 shadow-sm mb-3">
          <div className="card-body">
            <h6 className="fw-bold mb-3">Data Diri</h6>
            <div className="row g-3">
              <div className="col-12"><label className="form-label" htmlFor="jenisPemohon">Jenis pemohon</label><select id="jenisPemohon" name="jenisPemohon" className="form-select" value={form.jenisPemohon} onChange={handleChange}><option value="mahasiswa">Mahasiswa</option><option value="dosen">Dosen</option></select></div>
              <div className="col-12">
                <label className="form-label">Nama lengkap</label>
                <input className="form-control" name="nama" value={form.nama} onChange={handleChange} required />
              </div>
              <div className="col-md-6">
                <label className="form-label">{form.jenisPemohon === 'dosen' ? 'NIP / Identitas (opsional)' : 'NIM'}</label>
                <input className="form-control" name="nim" value={form.nim} onChange={handleChange} required={form.jenisPemohon==='mahasiswa'} />
              </div>
              <div className="col-md-6">
                <label className="form-label">Program Studi pemohon</label>
                <input className="form-control" name="prodi" value={form.prodi} onChange={handleChange} required />
                <div className="form-text">Prodi asal Anda. Kebutuhan cetak dipilih di bawah.</div>
              </div>
              <div className="col-md-6">
                <label className="form-label">Nomor WhatsApp</label>
                <input className="form-control" name="whatsapp" value={form.whatsapp} onChange={handleChange} placeholder="08xxxxxxxxxx" required />
              </div>
              <div className="col-md-6">
                <label className="form-label">Email sso</label>
                <input type="email" className="form-control" name="email" value={form.email} onChange={handleChange} required />
              </div>
            </div>
          </div>
        </div>

        <div className="card border-0 shadow-sm mb-3">
          <div className="card-body">
            <h6 className="fw-bold mb-3">Detail Pengajuan</h6>
            <div className="row g-3">
              <fieldset className="col-12">
                <legend className="form-label fs-6">Kebutuhan cetak</legend>
                <div className="form-text mt-0 mb-2">Pilih sesuai kegiatan. Mahasiswa Elektro juga boleh memilih Luar Elektro.</div>
                <div className="row g-2">{[['elektro','Internal Elektro','Akademik, PKE, MBKM, atau riset dengan pembimbing dari PSTE.'],['luar','Luar Elektro','Kebutuhan umum, Chem, Bengawan, atau kegiatan dengan pembimbing di luar PSTE.']].map(([value,label,hint])=><div className="col-sm-6" key={value}><label className={`need-choice border rounded p-3 d-flex gap-2 h-100 ${form.kebutuhan===value?'border-primary bg-light':''}`}><input type="radio" className="form-check-input flex-shrink-0" name="kebutuhan" value={value} checked={form.kebutuhan===value} onChange={handleChange} required/><span><strong className="d-block">{label}</strong><small className="text-secondary">{hint}</small></span></label></div>)}</div>
              </fieldset>
              <div className="col-md-6">
                <label className="form-label">Penggunaan</label>
                <select className="form-select" name="keperluan" value={form.keperluan} onChange={handleChange}>
                  {KEPERLUAN_OPTIONS.map((opt) => (
                    <option key={opt} value={opt}>{opt}</option>
                  ))}
                </select>
                {form.keperluan === "Lainnya" && (
                  <div className="mt-3">
                    <label className="form-label">
                      Sebutkan Keperluan <span className="text-danger">*</span>
                    </label>
                    <input
                      type="text"
                      className="form-control"
                      name="keperluanLainnya"
                      value={form.keperluanLainnya}
                      onChange={handleChange}
                      placeholder="Contoh: Organisasi, KKN, Prototype, dll."
                      required
                    />
                  </div>
                )}
              </div>
              {form.kebutuhan==='elektro'&&<div className="col-md-6">
                <label className="form-label" htmlFor="dosenId">Dosen Pembimbing / Pengampu *</label>
                <select id="dosenId" className="form-select" name="dosenId" value={form.dosenId} onChange={handleChange} required><option value="">Pilih dosen</option>{lecturers.map(d=><option key={d.id} value={d.id}>{d.name}</option>)}</select>
                <div className="form-text">{form.jenisPemohon==='dosen'?'Untuk pengajuan dosen, pilih nama sendiri sebagai penanggung jawab.':'Untuk tugas kuliah, pilih dosen pengampu.'}{!lecturers.length&&' Daftar dosen belum tersedia. Hubungi operator.'}</div>
              </div>}
              <div className="col-md-6"><label className="form-label" htmlFor="sumberFilamen">Sumber filamen</label><select id="sumberFilamen" name="sumberFilamen" className="form-select" value={form.sumberFilamen} disabled={!form.kebutuhan} onChange={handleChange} required>{!form.kebutuhan&&<option value="">Pilih kebutuhan cetak dahulu</option>}<option value={isLuarProdi?'pengelola':'prodi'}>{isLuarProdi?'Filamen pengelola':'Filamen prodi'}</option><option value="sendiri">Bawa sendiri</option></select><div className="form-text">{form.kebutuhan?`Tarif: ${rupiah(getRate(form))}/gram. Total dikonfirmasi operator.`:'Tarif mengikuti kebutuhan dan sumber filamen.'}</div></div>
              <div className="col-12">
                <a
                  href="https://drive.google.com/drive/folders/DEMO_FOLDER"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn btn-sm btn-outline-primary"
                >
                  Klik untuk Upload File ke Folder Drive
                </a>
                <div className="form-text">
                  Upload file STL dan screenshot desain kamu ke folder Drive di atas, lalu tempel link share-nya pada kolom di bawah.
                </div>
              </div>
              <div className="col-12">
                <label className="form-label">Link Google Drive - File STL</label>
                <input
                  className="form-control"
                  name="linkStl"
                  value={form.linkStl}
                  onChange={handleChange}
                  placeholder="https://drive.google.com/..."
                  required
                />
                <div className="form-text">Pastikan akses link diatur "Anyone with the link can view".</div>
              </div>
              <div className="col-12">
                <label className="form-label">Link Google Drive - Screenshot Desain</label>
                <input
                  className="form-control"
                  name="linkScreenshot"
                  value={form.linkScreenshot}
                  onChange={handleChange}
                  placeholder="https://drive.google.com/..."
                  required
                />
              </div>
              <div className="col-12">
                <label className="form-label">Catatan</label>
                <textarea className="form-control" name="catatan" rows="3" value={form.catatan} onChange={handleChange} placeholder="Opsional" />
              </div>
            </div>
          </div>
        </div>

        {settings.pics?.length > 0 && (
          <div className="card border-0 shadow-sm mb-3">
            <div className="card-body">
              <h6 className="fw-bold mb-2">Konfirmasi Pengajuan</h6>
              <p className="small text-secondary mb-3">
                Pilih untuk konfirmasi via WhatsApp setelah pengajuan dikirim.
              </p>
              <div className="d-flex flex-wrap gap-3">
                {settings.pics.map((pic, i) => (
                  <div className="form-check" key={i}>
                    <input
                      className="form-check-input"
                      type="radio"
                      name="picChoice"
                      id={`pic-${i}`}
                      checked={selectedPic === i}
                      onChange={() => setSelectedPic(i)}
                    />
                    <label className="form-check-label" htmlFor={`pic-${i}`}>
                      <strong>{pic.name}</strong>
                      <br />
                      <small className="text-secondary">{pic.whatsapp}</small>
                    </label>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        <div className="mb-3">
          <h6 className="fw-bold mb-2">Status Printer Saat Ini</h6>
          <p className="small text-secondary mb-3">
            Printer yang akan digunakan ditentukan oleh operator saat pengajuan diterima (ACC).
          </p>
          {!printers ? (
            <Loading label="Memuat status printer..." />
          ) : (
            <div className="row g-3">
              {printers.map((p) => (
                <div className="col-md-6" key={p.id}>
                  <PrinterCard printer={p} showDetailLink={false} />
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="card border-0 shadow-sm mb-3"><div className="card-body"><h6 className="fw-bold">Pembayaran</h6><div className="d-flex flex-wrap gap-4">{[['tunai','Bayar langsung (tunai)'],['qris','QRIS']].map(([value,label])=><label className="form-check" key={value}><input type="radio" className="form-check-input" name="metodePembayaran" value={value} checked={form.metodePembayaran===value} onChange={handleChange}/>{label}</label>)}</div><p className="small text-secondary mb-2">Pembayaran dilakukan di akhir, saat pengambilan hasil cetak. Nota lunas tersedia setelah operator memverifikasi pembayaran.</p><label className="form-check"><input className="form-check-input" type="checkbox" checked={ketentuanChecked} onChange={e=>setKetentuanChecked(e.target.checked)}/>Saya telah membaca ketentuan layanan dan pembayaran.</label></div></div>

        {form.kebutuhan&&<div className="bg-light rounded p-3 mb-3 small"><strong>Periksa pilihan Anda</strong><div>Kebutuhan: <strong>{needLabel(form)}</strong> · {filamentLabel(form)} · {rupiah(getRate(form))}/gram</div><div>Pembayaran: {form.metodePembayaran==='qris'?'QRIS':'Tunai'}, saat pengambilan hasil cetak.</div></div>}
        <button
          type="submit"
          className="btn w-100 text-white fw-semibold py-2"
          style={{ background: '#005BAC' }}
          disabled={!ketentuanChecked || submitting}
        >
          {submitting ? 'Mengirim...' : 'Kirim Pengajuan'}
        </button>
      </form>}
    </div>
  );
}

import { useState } from 'react';
import Swal from 'sweetalert2';
import { useNavigate } from 'react-router-dom';
import { createAdminRequest, ADMIN_ROLE_OPTIONS } from '../../services/adminRequestService';
import { notifyNewAdminRequest } from '../../utils/emailNotify';

export default function AjukanAdminPage() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ nama: '', email: '', peran: ADMIN_ROLE_OPTIONS[0] });
  const [submitting, setSubmitting] = useState(false);

  const handleChange = (e) => setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.nama.trim() || !form.email.trim()) {
      Swal.fire('Lengkapi data', 'Nama dan email wajib diisi.', 'warning');
      return;
    }

    setSubmitting(true);
    try {
      await createAdminRequest(form);
      // Notifikasi email tidak boleh menggagalkan alur utama kalau EmailJS
      // gagal/belum dikonfigurasi jadi dibungkus try/catch terpisah.
      try {
        await notifyNewAdminRequest(form);
      } catch (notifErr) {
        console.warn('Gagal mengirim notifikasi email:', notifErr);
      }

      await Swal.fire({
        icon: 'success',
        title: 'Pengajuan terkirim',
        text: 'Pengajuan kamu akan ditinjau oleh penanggung jawab sistem. Kamu akan diinfokan setelah disetujui.',
        confirmButtonColor: '#005BAC',
      });
      navigate('/');
    } catch (err) {
      Swal.fire('Gagal', err.message || 'Terjadi kesalahan saat mengirim pengajuan.', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="d-flex align-items-center justify-content-center" style={{ minHeight: '100vh', background: '#EAF3FB' }}>
      <div className="card border-0 shadow-sm" style={{ width: 420 }}>
        <div className="card-body p-4">
          <h5 className="fw-bold mb-1" style={{ color: '#005BAC' }}>Ajukan jadi Admin</h5>
          <p className="text-secondary small mb-4">
            Isi data di bawah untuk mengajukan akses admin sistem 3D Print Service.
          </p>
          <form onSubmit={handleSubmit}>
            <div className="mb-3">
              <label className="form-label small">Nama lengkap</label>
              <input className="form-control" name="nama" value={form.nama} onChange={handleChange} required />
            </div>
            <div className="mb-3">
              <label className="form-label small">Email</label>
              <input type="email" className="form-control" name="email" value={form.email} onChange={handleChange} required />
            </div>
            <div className="mb-4">
              <label className="form-label small">Mengajukan sebagai</label>
              <select className="form-select" name="peran" value={form.peran} onChange={handleChange}>
                {ADMIN_ROLE_OPTIONS.map((opt) => (
                  <option key={opt} value={opt}>{opt}</option>
                ))}
              </select>
            </div>
            <button type="submit" className="btn w-100 text-white" style={{ background: '#005BAC' }} disabled={submitting}>
              {submitting ? 'Mengirim...' : 'Kirim Pengajuan'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import AdminLayout from '../../components/admin/AdminLayout';
import { useAdminTour } from '../../context/AdminTourContext';
import { ADMIN_GUIDE_STEPS, ADMIN_GUIDE_STATUSES, ADMIN_GUIDE_MENUS, WA_CONSENT_EXAMPLE, WA_CONSENT_NAME_HELP, guideSeenKey } from '../../data/adminGuide';
export default function AdminGuidePage(){
 const [params,setParams]=useSearchParams(),navigate=useNavigate();
 const {currentUser}=useAuth();
 const tour=useAdminTour();
 const requested=Number(params.get('langkah')||1);
 const index=Number.isInteger(requested)&&requested>=1&&requested<=ADMIN_GUIDE_STEPS.length?requested-1:0;
 const step=ADMIN_GUIDE_STEPS[index],last=index===ADMIN_GUIDE_STEPS.length-1;
 const go=value=>setParams({langkah:String(value+1)});
 const finish=()=>{if(currentUser){try{localStorage.setItem(guideSeenKey(currentUser.uid),'read');}catch{/* Reading the guide never requires browser storage. */}}navigate('/admin/dashboard');};
 return <AdminLayout feature><div className="mx-auto" style={{maxWidth:800}}>
  <Link to="/admin/dashboard" className="small d-inline-block mb-3">Kembali ke Dashboard</Link>
  <h4 className="fw-bold mb-1">Panduan Admin</h4><p className="small text-secondary mb-3">Ikuti satu langkah setiap kali. Panduan ini bisa dibuka lagi melalui menu Panduan.</p>
  {tour&&<div className="d-flex flex-wrap align-items-center gap-2 mb-3"><button type="button" className="btn btn-sm btn-primary" disabled={tour.active} onClick={tour.ask}>Tutorial Klik Langsung</button><span className="small text-secondary">Atau baca langkah kerja di bawah.</span></div>}
  <nav data-tour="written-guide" aria-label="Langkah panduan" className="d-flex flex-wrap gap-2 mb-3">{ADMIN_GUIDE_STEPS.map((item,i)=><button key={item.title} type="button" title={item.title} aria-label={`Langkah ${i+1}: ${item.title}`} aria-current={i===index?'step':undefined} className={`btn btn-sm ${i===index?'btn-primary':'btn-outline-secondary'}`} style={{minWidth:36,minHeight:36}} onClick={()=>go(i)}>{i+1}</button>)}</nav>
  <section className="card border-0 shadow-sm p-3" aria-labelledby="admin-guide-step-title">
   <p className="small text-secondary mb-1" role="status">Langkah {index+1} dari {ADMIN_GUIDE_STEPS.length}{step.optional?' · Jika diperlukan':''}</p>
   <h5 id="admin-guide-step-title" className="fw-bold mb-3">{step.title}</h5>
   <ol className="small ps-3 mb-3">{step.lines.map(line=><li key={line} className="mb-2">{line}</li>)}</ol>
   {step.note&&<p className="small text-secondary mb-3">{step.note}</p>}
   {step.consentExample&&<details className="small border-top pt-2 mb-3"><summary className="fw-semibold">Pemohon sudah setuju lewat WhatsApp?</summary><p className="mt-2 mb-1">Klik Catat Persetujuan WhatsApp, lalu isi catatan seperti ini.</p><p className="bg-light rounded p-2 mb-1">{WA_CONSENT_EXAMPLE}</p><p className="text-secondary mb-1">{WA_CONSENT_NAME_HELP}</p><p className="text-secondary mb-0">Jika pemohon sudah setuju lewat Cek Status, catatan ini tidak perlu diisi.</p></details>}
   {step.extra&&<details className="small border-top pt-2 mb-3"><summary className="fw-semibold">{step.extraTitle}</summary><p className="text-secondary mt-2 mb-0">{step.extra}</p></details>}
   {step.link&&<Link className="btn btn-sm btn-outline-primary align-self-start mb-3" to={step.link}>{step.linkLabel}</Link>}
   <div className="d-flex flex-wrap justify-content-between gap-2 border-top pt-3"><button type="button" className="btn btn-sm btn-outline-secondary" disabled={index===0} onClick={()=>go(index-1)}>Sebelumnya</button>{last?<button type="button" className="btn btn-sm btn-primary" onClick={finish}>Selesai Membaca</button>:<button type="button" className="btn btn-sm btn-primary" onClick={()=>go(index+1)}>Berikutnya</button>}</div>
  </section>
  <details className="small card border-0 shadow-sm p-3 mt-3"><summary className="fw-semibold">Arti status pengajuan</summary><dl className="mb-0 mt-3">{ADMIN_GUIDE_STATUSES.map(([label,text])=><div key={label} className="mb-2"><dt>{label}</dt><dd className="text-secondary mb-0">{text}</dd></div>)}</dl></details>
  <details className="small card border-0 shadow-sm p-3 mt-2"><summary className="fw-semibold">Fungsi menu admin</summary><dl className="mb-0 mt-3">{ADMIN_GUIDE_MENUS.map(([label,text])=><div key={label} className="mb-2"><dt>{label}</dt><dd className="text-secondary mb-0">{text}</dd></div>)}</dl></details>
 </div></AdminLayout>;
}

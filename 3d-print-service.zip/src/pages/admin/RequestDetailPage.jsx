import { WA_CONSENT_EXAMPLE, WA_CONSENT_NAME_HELP } from '../../data/adminGuide';
import { useEffect, useState } from 'react';
import { Link, useLocation, useParams } from 'react-router-dom';
import { doc, onSnapshot } from 'firebase/firestore';
import Swal from 'sweetalert2';
import { db } from '../../services/firebase';
import { subscribeToPrinters } from '../../services/printerService';
import { subscribeFilaments } from '../../services/filamentService';
import { acceptRequest, approveQuote, markPickedUp, verifyPayment, recordWhatsAppConsent } from '../../services/requestService';
import { needLabel, filamentLabel, isExternal, paymentSettled, rupiah, amountReceived, outstandingAmount } from '../../utils/billing';
import { workflowStage } from '../../utils/workflow';
import { sponsorApproved, hasQuote } from '../../utils/sponsorship';
import { lecturerName } from '../../utils/lecturerNames';
import { nextMessageStage, requestMessage } from '../../utils/requestMessages';
import AdminLayout from '../../components/admin/AdminLayout';
import QuoteEditor from '../../components/admin/QuoteEditor';
import SponsorshipReview from '../../components/admin/SponsorshipReview';
import RequestEditAccess from '../../components/admin/RequestEditAccess';
import LegacyRequestWorkflow from '../../components/admin/LegacyRequestWorkflow';
import StatusBadge from '../../components/common/StatusBadge';
import CostBreakdown from '../../components/common/CostBreakdown';
import Invoice from '../../components/common/Invoice';
import AdminWhatsAppButton from '../../components/admin/AdminWhatsAppButton';
import WorkflowProgress from '../../components/common/WorkflowProgress';
import PaymentHistory from '../../components/common/PaymentHistory';
import PrintRunControls from '../../components/admin/PrintRunControls';
import PrintAttemptHistory from '../../components/admin/PrintAttemptHistory';
import { currentPrintAttempt, needsPrintAllocation } from '../../services/printAttemptService';

export default function RequestDetailPage(){
 const {id}=useParams(),location=useLocation();
 const back=location.state?.returnTo?.startsWith('/admin/')?location.state.returnTo:'/admin/pengajuan';
 const [r,setR]=useState(undefined),[printers,setPrinters]=useState([]),[lots,setLots]=useState([]),[error,setError]=useState(''),[busy,setBusy]=useState(false),[revising,setRevising]=useState(false),[preview,setPreview]=useState(null);
 const [printer,setPrinter]=useState(''),[lot,setLot]=useState('');
 const [payer,setPayer]=useState(''),[method,setMethod]=useState(''),[amount,setAmount]=useState(''),[reference,setReference]=useState('');
 const [paymentId,setPaymentId]=useState(()=>crypto.randomUUID());
 const [place,setPlace]=useState(''),[time,setTime]=useState('');
 useEffect(()=>onSnapshot(doc(db,'requests',id),s=>setR(s.exists()?{id:s.id,...s.data()}:null),e=>setError(e.message)),[id]);
 useEffect(()=>subscribeToPrinters(setPrinters,e=>setError(e.message)),[]);
 useEffect(()=>subscribeFilaments(setLots,e=>setError(e.message)),[]);
 const act=async(fn,confirmation)=>{
  if(confirmation){const result=await Swal.fire({title:confirmation,icon:'question',showCancelButton:true,confirmButtonText:'Ya, lanjutkan',cancelButtonText:'Kembali'});if(!result.isConfirmed)return;}
  setBusy(true);setError('');try{await fn();}catch(e){setError(e.message);}finally{setBusy(false);}
 };
 if(!r)return <AdminLayout feature><Link to={back} className="small">Kembali ke daftar</Link><p role={error?'alert':'status'} className="mt-3">{error|| (r===null?'Pengajuan tidak ditemukan.':'Memuat pengajuan...')}</p></AdminLayout>;
 if(!r.pricingVersion)return <AdminLayout feature><Link to={back}>Kembali ke daftar</Link><LegacyRequestWorkflow request={r} onClose={()=>window.history.back()}/></AdminLayout>;
 const flow=workflowStage(r),paid=paymentSettled(r),sponsored=sponsorApproved(r),queue=flow.key==='queue',finished=['pickup','complete'].includes(flow.key);
 const displayQuote=(flow.key==='review'||revising)&&preview?preview:r;
 const isPreview=displayQuote!==r;
 const allocate=needsPrintAllocation(r);
 const chosenLot=allocate?lot:r.filamentLotId;
 const [messageStage,messageLabel]=nextMessageStage(r);
 const payerValue=payer||(sponsored?lecturerName(r):r.nama);
 const methodValue=method||r.metodePembayaran;
 const amountValue=amount===''?outstandingAmount(r):amount;
 const files=<div className="d-flex flex-wrap gap-3 small">{[['Buka file STL',r.linkStl],['Buka screenshot',r.linkScreenshot]].map(([label,url])=>/^https:\/\/(drive\.google\.com|docs\.google\.com)\//.test(url||'')&&<a key={label} href={url} target="_blank" rel="noopener noreferrer">{label} ↗</a>)}</div>;
 return <AdminLayout feature><div className="workflow-page">
  <Link to={back} className="small d-inline-block mb-3">‹ Kembali ke daftar</Link>
  <div className="d-flex flex-wrap align-items-start justify-content-between gap-2 mb-3"><div><h4 className="fw-bold mb-1">Detail Pengajuan</h4><p className="small text-secondary mb-0">{r.trackingCode} · {r.nama}</p></div><StatusBadge request={r} status={r.status}/></div>
  <WorkflowProgress request={r}/>
  <div className="workflow-context small"><span>{needLabel(r)} · {filamentLabel(r)}</span><strong>Berikutnya: {flow.next}</strong></div>
  {error&&<div role="alert" className="alert alert-danger py-2 small">{error}</div>}
  <div className="workflow-columns"><div className="workflow-main">
   <section className="card border-0 shadow-sm"><div className="card-body">
    {flow.key==='review'||revising?<><div className="mb-3">{files}</div>{r.customerRevision>0&&<p className="small text-primary">Pemohon merevisi data. Periksa ulang file dan biaya.</p>}<QuoteEditor key={`${id}:${r.customerRevision||0}:${r.quoteUpdatedAt?.toMillis?.()||0}`} request={r} onPreview={setPreview} onSaved={()=>setRevising(false)}/>{revising&&<button className="btn btn-sm btn-link mt-2" onClick={()=>setRevising(false)}>Kembali ke penawaran</button>}</>:flow.key==='decision'?<>
     <h6 className="fw-bold">Menunggu persetujuan pemohon</h6><p className="small text-secondary">Penawaran sudah tersimpan. Pemohon menyetujui melalui tautan pribadi atau mengirim form pembimbing jika terkendala biaya.</p>
     <AdminWhatsAppButton request={r} message={requestMessage(r,'quote')} label="Buka Pesan WhatsApp"/>
     <div className="mt-3"><button className="btn btn-sm btn-outline-secondary" onClick={()=>setRevising(true)}>Revisi Penawaran</button></div>
     <details className="workflow-detail mt-3"><summary>Persetujuan sudah diterima melalui WhatsApp?</summary><p className="small text-secondary mt-2 mb-1">Isi setelah pemohon setuju biaya lewat WhatsApp.</p><p className="small mb-1">Contoh: {WA_CONSENT_EXAMPLE}</p><p className="small text-secondary mb-2">{WA_CONSENT_NAME_HELP}</p><button className="btn btn-sm btn-outline-primary" disabled={busy} onClick={async()=>{const result=await Swal.fire({title:`Catat persetujuan ${rupiah(r.totalBiaya)}?`,input:'text',inputLabel:'Catatan persetujuan pemohon',inputPlaceholder:WA_CONSENT_EXAMPLE,inputAttributes:{maxlength:500},showCancelButton:true,confirmButtonText:'Catat Persetujuan',cancelButtonText:'Kembali',inputValidator:v=>v?.trim()?undefined:'Isi keterangan persetujuan.'});if(result.isConfirmed)await act(()=>recordWhatsAppConsent(r,result.value));}}>Catat Persetujuan WhatsApp</button></details>
     {!isExternal(r)&&<details className="workflow-detail mt-3"><summary>Form pembimbing diserahkan langsung</summary><SponsorshipReview request={r}/></details>}
    </>:flow.key==='sponsor'?<SponsorshipReview request={r}/>:queue?<>
     <h6 className="fw-bold">{r.failedPrints>0?'Siapkan cetak ulang':'Siapkan cetak'}</h6><p className="small text-secondary">{sponsored?'Form pembimbing sudah diverifikasi.':'Biaya sudah disetujui.'} Pilih printer dan gulungan fisik yang akan digunakan.</p>
     {r.failedPrints>0&&<p className="small text-secondary">Cetakan sebelumnya gagal: {r.lastPrintFailureReason}. Pemakaian gagal {r.failedGram} g sudah dicatat. Periksa printer sebelum mengulang; biaya tetap.</p>}
     {r.sumberFilamen!=='sendiri'&&(!allocate?<p className="small">Filamen: {lots.find(l=>l.id===r.filamentLotId)?.nama||'Gulungan sudah dialokasikan'}</p>:<div className="mb-3"><label className="form-label small" htmlFor="workflow-lot">Gulungan fisik</label><select id="workflow-lot" className="form-select form-select-sm" value={lot} onChange={e=>setLot(e.target.value)}><option value="">Pilih gulungan tersedia</option>{lots.filter(l=>l.pemilik===r.sumberFilamen).map(l=><option key={l.id} value={l.id} disabled={l.gram-(l.reserved||0)<r.beratGram}>{l.nama} · tersedia {l.gram-(l.reserved||0)} g</option>)}</select></div>)}
     <label className="form-label small" htmlFor="workflow-printer">Printer</label><select id="workflow-printer" className="form-select form-select-sm mb-3" value={printer} onChange={e=>setPrinter(e.target.value)}><option value="">Pilih printer tersedia</option>{printers.filter(p=>p.status==='available').map(p=><option key={p.id} value={p.id}>{p.name}</option>)}</select>
     <button className="btn btn-sm btn-primary" disabled={busy||!printer||(r.sumberFilamen!=='sendiri'&&!chosenLot)} onClick={()=>act(async()=>{if(r.quoteStatus!=='approved'||r.printRetryPending)await approveQuote(id,{filamentLotId:lot});await acceptRequest(id,{printerId:printer,jamMulai:new Date().toISOString(),estimasiMenit:Number(r.estimasiMenit)});},'Mulai cetak dengan printer dan filamen ini?')}>{r.failedPrints>0?'Mulai Cetak Ulang':'Mulai Cetak'}</button>
    </>:flow.key==='printing'?<><PrintRunControls key={`${id}:${currentPrintAttempt(r)}`} request={r} printerName={printers.find(p=>p.id===r.printerId)?.name||r.printerId} busy={busy} onAction={act}/></>:finished?<>
     <h6 className="fw-bold">{r.pickedUp?'Hasil sudah diserahkan':'Pembayaran dan pengambilan'}</h6>
     {sponsored&&!paid&&<p className="small text-primary">Form pembimbing terverifikasi. Hasil boleh diserahkan tanpa membayar di tempat. Sisa tagihan {rupiah(outstandingAmount(r))} menunggu pembayaran pembimbing.</p>}
     {r.totalBiaya===0&&<p className="small text-secondary">Total akhir Rp0. Tidak ada pemasukan kas yang dicatat.</p>}
     {amountReceived(r)>0&&<p className="small">Sudah diterima: <strong>{rupiah(amountReceived(r))}</strong> · Sisa: <strong>{rupiah(outstandingAmount(r))}</strong></p>}
     {!paid&&r.totalBiaya>0?<form onSubmit={e=>{e.preventDefault();act(async()=>{await verifyPayment(id,{pembayar:payerValue,metode:methodValue,nominal:Number(amountValue),refBayar:reference,operationId:paymentId});setAmount('');setReference('');setPaymentId(crypto.randomUUID());},methodValue==='qris'?'Transaksi sudah berhasil dicek di merchant QRIS?':'Uang tunai sudah diterima operator?');}}><fieldset disabled={busy}><div className="row g-3 mb-3">
      <div className="col-sm-6"><label className="form-label small" htmlFor="workflow-payer">Nama pembayar</label><input id="workflow-payer" className="form-control form-control-sm" required value={payerValue} onChange={e=>setPayer(e.target.value)}/></div>
      <div className="col-sm-6"><label className="form-label small" htmlFor="workflow-method">Metode transaksi sebenarnya</label><select id="workflow-method" className="form-select form-select-sm" value={methodValue} onChange={e=>setMethod(e.target.value)}><option value="tunai">Tunai</option><option value="qris">QRIS</option></select></div>
      <div className="col-sm-6"><label className="form-label small" htmlFor="workflow-amount">Nominal diterima (Rp)</label><input id="workflow-amount" className="form-control form-control-sm" type="number" step="1" min="1" max={outstandingAmount(r)} required value={amountValue??''} onChange={e=>setAmount(e.target.value)}/></div>
      <div className="col-sm-6"><label className="form-label small" htmlFor="workflow-reference">Referensi transaksi (opsional)</label><input id="workflow-reference" className="form-control form-control-sm" maxLength={200} value={reference} onChange={e=>setReference(e.target.value)}/></div>
     </div>{r.paymentProof&&/^https:\/\/(drive\.google\.com|docs\.google\.com)\//.test(r.paymentProof)&&<a className="small d-block mb-3" href={r.paymentProof} target="_blank" rel="noopener noreferrer">Buka bukti pembayaran ↗</a>}
     <button className="btn btn-sm btn-primary">Verifikasi Pembayaran</button><p className="small text-secondary mt-2 mb-3">Isi uang yang benar-benar diterima, boleh sebagian. Setiap pembayaran masuk kas; invoice lunas setelah sisa Rp0.</p></fieldset></form>:<p className="small fw-semibold">{r.paymentStatus==='waived'?'Tanpa biaya':'Pembayaran lunas'}</p>}
     {!r.pickedUp&&<button className={`btn btn-sm ${paid?'btn-primary':'btn-outline-primary'}`} disabled={busy||(!paid&&!sponsored)} onClick={()=>act(()=>markPickedUp(id),'Hasil sudah diserahkan kepada pemohon?')}>Tandai Sudah Diambil</button>}
    </>:<p className="small mb-0">{r.status==='ditolak'?r.alasanPenolakan:r.cancelReason}</p>}
   </div></section>
   {sponsored&&flow.key!=='sponsor'&&<details className="workflow-detail card border-0 shadow-sm p-3 mt-3"><summary>Form pembimbing terverifikasi</summary><div className="mt-3"><SponsorshipReview request={r}/></div></details>}
   {r.paymentSequence>0&&<section className="card border-0 shadow-sm p-3 mt-3"><PaymentHistory request={r}/></section>}
   {(r.printAttempt||r.failedPrints)>0&&<PrintAttemptHistory requestId={id}/>}
   <details className="workflow-detail card border-0 shadow-sm p-3 mt-3"><summary>Data pemohon dan file</summary><dl className="row small pt-3 mb-0"><dt className="col-sm-4">Nama</dt><dd className="col-sm-8">{r.nama}</dd><dt className="col-sm-4">NIM / identitas</dt><dd className="col-sm-8">{r.nim||'Tidak dicantumkan'}</dd><dt className="col-sm-4">Program Studi</dt><dd className="col-sm-8">{r.prodi}</dd>{!isExternal(r)&&<><dt className="col-sm-4">Dosen Pembimbing</dt><dd className="col-sm-8">{lecturerName(r)}</dd></>}<dt className="col-sm-4">Keperluan</dt><dd className="col-sm-8">{r.keperluan}</dd></dl>{files}{r.catatan&&<p className="small mt-2 mb-0">{r.catatan}</p>}</details>
   {<details className="workflow-detail card border-0 shadow-sm p-3 mt-3"><summary>Bantuan tautan pribadi pemohon</summary><RequestEditAccess request={r}/></details>}
   {messageStage&&flow.key!=='decision'&&<details className="workflow-detail card border-0 shadow-sm p-3 mt-3"><summary>WhatsApp pemohon</summary><div className="pt-3">{messageStage==='ready'&&<div className="row g-2 mb-3"><div className="col-sm-6"><label className="form-label small" htmlFor="pickup-place">Lokasi pengambilan</label><input id="pickup-place" className="form-control form-control-sm" value={place} onChange={e=>setPlace(e.target.value)}/></div><div className="col-sm-6"><label className="form-label small" htmlFor="pickup-time">Waktu pengambilan</label><input id="pickup-time" className="form-control form-control-sm" value={time} onChange={e=>setTime(e.target.value)}/></div></div>}<AdminWhatsAppButton request={r} label={messageLabel} message={requestMessage(r,messageStage,{lokasi:place,waktu:time})}/></div></details>}
  </div><aside className="workflow-summary card border-0 shadow-sm align-self-start"><div className="card-body"><h6 className="fw-bold">Rincian Biaya</h6>{(hasQuote(r)||isPreview)?<>{isPreview&&<p className="small text-secondary">Pratinjau belum disimpan</p>}<CostBreakdown request={displayQuote}/><p className="small text-secondary mt-3">{paid?r.paymentStatus==='waived'?'Tanpa biaya':'Lunas':amountReceived(r)>0?`Sisa ${rupiah(outstandingAmount(r))}`:sponsored?'Ditagihkan ke pembimbing':'Belum bayar'}</p>{!isPreview&&<Invoice request={r} phone={r.whatsapp}/>}</>:<p className="small text-secondary mb-0">Tersedia setelah file diperiksa dan penawaran disimpan.</p>}</div></aside></div>
 </div></AdminLayout>;
}

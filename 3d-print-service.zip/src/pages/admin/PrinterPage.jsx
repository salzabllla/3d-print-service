import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Swal from 'sweetalert2';
import AdminLayout from '../../components/admin/AdminLayout';
import CountdownTimer from '../../components/common/CountdownTimer';
import Loading from '../../components/common/Loading';
import { subscribeToPrinters, addMaintenanceLog } from '../../services/printerService';
import PrinterPhotoUploadModal from '../../components/admin/PrinterPhotoUploadModal';
import { subscribeToRequestsByStatus, finishRequest } from '../../services/requestService';
import { REQUEST_STATUS, PRINTER_STATUS } from '../../utils/constants';
import { useAuth } from '../../context/AuthContext';

export default function PrinterPage() {
  const { currentUser } = useAuth();
  const [printers, setPrinters] = useState(null);
  const [activeRequests, setActiveRequests] = useState([]);
  const [maintenanceNote, setMaintenanceNote] = useState({});
  const [photoTarget, setPhotoTarget] = useState(null);

  useEffect(() => {
    const unsub1 = subscribeToPrinters(setPrinters);
    const unsub2 = subscribeToRequestsByStatus([REQUEST_STATUS.SEDANG_PRINT], setActiveRequests);
    return () => {
      unsub1();
      unsub2();
    };
  }, []);

  const getActiveRequest = (printerId) => activeRequests.find((r) => r.printerId === printerId);

  const handleFinish = async (printer, request) => {
    const confirm = await Swal.fire({
      title: 'Tandai selesai?',
      text: `Printer ${printer.name} akan kembali berstatus Available.`,
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#005BAC',
    });
    if (!confirm.isConfirmed) return;

    let grams;
    if(request.pricingVersion){const result=await Swal.fire({title:'Gram aktual filamen terpakai',input:'number',inputValue:request.beratGram,inputAttributes:{min:'0.01',step:'0.01'},showCancelButton:true,inputValidator:v=>Number(v)>0?undefined:'Isi gram aktual yang valid.'});if(!result.isConfirmed)return;grams=Number(result.value);}
    try { await finishRequest(request.id, printer.id, grams); } catch(error) { Swal.fire('Gagal',error.message,'error'); return; }
    Swal.fire('Selesai', 'Printer kembali tersedia.', 'success');
  };

  const handleAddMaintenance = async (printerId) => {
    const note = maintenanceNote[printerId];
    if (!note?.trim()) return;
    await addMaintenanceLog(printerId, { catatan: note, oleh: currentUser?.email || 'admin' });
    setMaintenanceNote((prev) => ({ ...prev, [printerId]: '' }));
    Swal.fire('Tersimpan', 'Catatan maintenance ditambahkan.', 'success');
  };

  if (!printers) {
    return (
      <AdminLayout>
        <Loading />
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <h4 className="fw-bold mb-4">Printer</h4>
      <div className="row g-4" data-tour="printer-list">
        {printers.map((printer) => {
          const activeRequest = getActiveRequest(printer.id);
          const isInUse = printer.status === PRINTER_STATUS.IN_USE;

          return (
            <div className="col-md-6" key={printer.id}>
              <div className="card border-0 shadow-sm h-100">
                <img
                  src={printer.photoUrl || 'https://placehold.co/400x220?text=Printer+3D'}
                  alt={printer.name}
                  style={{ height: 180, objectFit: 'cover' }}
                  className="printer-image"
                />
                <div className="card-body">
                  <div className="d-flex justify-content-between align-items-start mb-2">
                    <h5 className="mb-0">{printer.name}</h5>
                    <span className={`badge ${isInUse ? 'bg-danger-subtle text-danger-emphasis' : 'bg-success-subtle text-success-emphasis'} border`}>
                      {isInUse ? 'In use' : 'Available'}
                    </span>
                  </div>

                  {isInUse && activeRequest ? (
                    <div className="bg-light rounded p-2 mb-2 small">
                      <div>Pengguna: <strong>{activeRequest.nama}</strong></div>
                      <div>Mulai: {new Date(activeRequest.jamMulai).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })} · Selesai: {new Date(activeRequest.jamSelesai).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}</div>
                      <div>Sisa waktu: <CountdownTimer targetTime={activeRequest.jamSelesai} /></div>
                    </div>
                  ) : (
                    <p className="small text-secondary mb-2">Belum ada antrean aktif.</p>
                  )}

                  <div className="d-flex gap-2 mb-3">
                    <button className="btn btn-sm btn-outline-secondary" onClick={() => setPhotoTarget(printer)}>
                      Ganti foto printer
                    </button>
                    {isInUse && activeRequest && (activeRequest.pricingVersion?<Link className="btn btn-sm btn-primary" to={`/admin/pengajuan/${activeRequest.id}`}>Kelola Cetak</Link>:(
                      <button className="btn btn-sm text-white" style={{ background: '#005BAC' }} onClick={() => handleFinish(printer, activeRequest)}>
                        Tandai selesai
                      </button>
                    ))}
                  </div>

                  <hr />
                  <p className="small fw-semibold mb-2">Log Maintenance</p>
                  <ul className="small text-secondary" style={{ maxHeight: 100, overflowY: 'auto' }}>
                    {(printer.maintenanceLog || []).length === 0 && <li>Belum ada catatan.</li>}
                    {(printer.maintenanceLog || []).slice().reverse().map((log, idx) => (
                      <li key={idx}>
                        {new Date(log.tanggal).toLocaleDateString('id-ID')} {log.catatan} ({log.oleh})
                      </li>
                    ))}
                  </ul>
                  <div className="input-group input-group-sm">
                    <input
                      className="form-control"
                      placeholder="Tambah catatan maintenance..."
                      value={maintenanceNote[printer.id] || ''}
                      onChange={(e) => setMaintenanceNote((prev) => ({ ...prev, [printer.id]: e.target.value }))}
                    />
                    <button className="btn btn-outline-secondary" onClick={() => handleAddMaintenance(printer.id)}>
                      Tambah
                    </button>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {photoTarget && (
        <PrinterPhotoUploadModal printer={photoTarget} onClose={() => setPhotoTarget(null)} />
      )}
    </AdminLayout>
  );
}

import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import Swal from 'sweetalert2';
import { sendPasswordResetEmail, sendEmailVerification } from 'firebase/auth';
import { auth } from '../../services/firebase';
import { loginAdmin } from '../../services/authService';

export default function LoginPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await loginAdmin(email, password);
      navigate('/admin/dashboard');
    } catch (err) {
      if(err.code==='admin/email-unverified'){
       const result=await Swal.fire({title:'Verifikasi Email Admin',text:'Kirim tautan verifikasi ke email akun ini, lalu login kembali setelah memverifikasinya.',showCancelButton:true,confirmButtonText:'Kirim Email Verifikasi',cancelButtonText:'Kembali'});
       if(result.isConfirmed){try{await sendEmailVerification(auth.currentUser);await Swal.fire('Email dikirim','Periksa email akun, verifikasi, lalu login kembali.','success');}catch{await Swal.fire('Belum terkirim','Tunggu sebentar lalu coba kembali.','error');}}
      }else await Swal.fire('Login gagal',err.code?.startsWith('auth/')?'Periksa email dan password.':err.message||'Akses admin belum tersedia.','error');
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPassword = async () => {
    const { value: resetEmail } = await Swal.fire({
      title: 'Lupa Password',
      input: 'email',
      inputLabel: 'Masukkan email admin kamu',
      inputValue: email,
      showCancelButton: true,
      confirmButtonText: 'Kirim link reset',
      confirmButtonColor: '#005BAC',
    });
    if (!resetEmail) return;

    try {
      await sendPasswordResetEmail(auth, resetEmail.trim().toLowerCase());
      Swal.fire('Terkirim', 'Cek email kamu untuk link reset password.', 'success');
    } catch (err) {
      Swal.fire('Gagal', 'Email tidak ditemukan atau terjadi kesalahan.', 'error');
    }
  };

  return (
    <div className="d-flex align-items-center justify-content-center" style={{ minHeight: '100vh', background: '#EAF3FB' }}>
      <div className="card border-0 shadow-sm" style={{ width: 380 }}>
        <div className="card-body p-4">
          <h5 className="fw-bold mb-1" style={{ color: '#005BAC' }}>3D Print Service</h5>
          <p className="text-secondary small mb-4">Login Admin</p>
          <form onSubmit={handleSubmit}>
            <div className="mb-3">
              <label className="form-label small">Email</label>
              <input type="email" className="form-control" value={email} onChange={(e) => setEmail(e.target.value)} required />
            </div>
            <div className="mb-1">
              <label className="form-label small">Password</label>
              <input type="password" className="form-control" value={password} onChange={(e) => setPassword(e.target.value)} required />
            </div>
            <div className="text-end mb-3">
              <button type="button" onClick={handleForgotPassword} className="btn btn-link btn-sm p-0" style={{ color: '#005BAC' }}>
                Lupa password?
              </button>
            </div>
            <button type="submit" className="btn w-100 text-white" style={{ background: '#005BAC' }} disabled={loading}>
              {loading ? 'Memproses...' : 'Login'}
            </button>
          </form>
          <div className="text-center mt-3">
            <Link to="/admin/ajukan-jadi-admin" className="small" style={{ color: '#005BAC' }}>
              Ajukan jadi Admin
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
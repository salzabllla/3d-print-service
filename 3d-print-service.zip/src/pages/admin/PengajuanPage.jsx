import { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import Swal from 'sweetalert2';
import AdminLayout from '../../components/admin/AdminLayout';
import StatusBadge from '../../components/common/StatusBadge';
import Loading from '../../components/common/Loading';
import AccRequestModal from '../../components/admin/AccRequestModal';
import RejectRequestModal from '../../components/admin/RejectRequestModal';
import RequestDetailModal from '../../components/admin/RequestWorkflow';
import { subscribeToAllRequests, acceptRequest, rejectRequest } from '../../services/requestService';
import { subscribeToPrinters } from '../../services/printerService';
import { getDriveThumbnail } from '../../utils/driveThumbnail';
import { requestFilterStage } from '../../utils/workflow';
import { REQUEST_STATUS } from '../../utils/constants';

export default function PengajuanPage() {
  const [params,setParams]=useSearchParams();
  const [requests, setRequests] = useState(null);
  const [printers, setPrinters] = useState(null);
  const [filterStatus, setFilterStatus] = useState('semua');
  const [filterPrinter, setFilterPrinter] = useState('semua');
  const [sortBy, setSortBy] = useState('terbaru');
  const [search, setSearch] = useState('');

  const [accTarget, setAccTarget] = useState(null);
  const [rejectTarget, setRejectTarget] = useState(null);
  const [detailTarget, setDetailTarget] = useState(null);

  useEffect(() => {
    const unsub1 = subscribeToAllRequests(setRequests,err=>Swal.fire('Gagal memuat',err.message,'error'));
    const unsub2 = subscribeToPrinters(setPrinters);
    return () => {
      unsub1();
      unsub2();
    };
  }, []);

  useEffect(()=>{const id=params.get('id');if(id&&requests){setDetailTarget(requests.find(r=>r.id===id)||null);setParams({}, {replace:true});}},[params,requests,setParams]);

  const filtered = useMemo(() => {
    if (!requests) return [];
    let items = [...requests];

    if (filterStatus !== 'semua') {
      items = items.filter((r) => requestFilterStage(r) === filterStatus);
    }
    if (filterPrinter !== 'semua') {
      items = items.filter((r) => r.printerId === filterPrinter);
    }
    if (search.trim()) {
      const q = search.trim().toLowerCase();
      items = items.filter(
        (r) => r.nama?.toLowerCase().includes(q) || r.nim?.toLowerCase().includes(q)
      );
    }

    items.sort((a, b) => {
      const at = a.createdAt?.toMillis?.() || 0;
      const bt = b.createdAt?.toMillis?.() || 0;
      return sortBy === 'terbaru' ? bt - at : at - bt;
    });

    return items;
  }, [requests, filterStatus, filterPrinter, search, sortBy]);

  const handleAccConfirm = async (data) => {
    try {
      await acceptRequest(accTarget.id, data);
      Swal.fire('Berhasil', 'Pengajuan diterima (ACC).', 'success');
      setAccTarget(null);
    } catch (err) {
      Swal.fire('Gagal', err.message, 'error');
    }
  };

  const handleRejectConfirm = async (alasan) => {
    try {
      await rejectRequest(rejectTarget.id, alasan);
      Swal.fire('Berhasil', 'Pengajuan ditolak.', 'success');
      setRejectTarget(null);
    } catch (err) {
      Swal.fire('Gagal', err.message, 'error');
    }
  };

  return (
    <AdminLayout>
      <h4 className="fw-bold mb-4">Pengajuan</h4>

      <div className="row g-2 mb-3">
        <div className="col-md-3">
          <select className="form-select form-select-sm" value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)}>
            <option value="semua">Semua Status</option>
            {Object.entries({review:'Pemeriksaan',decision:'Persetujuan biaya',sponsor:'Form pembimbing',queue:'Antrean cetak',printing:'Sedang dicetak',pickup:'Siap diambil',complete:'Sudah diambil','legacy-complete':'Selesai (data lama)',rejected:'Ditolak',cancelled:'Dibatalkan'}).map(([key, label]) => (
              <option key={key} value={key}>{label}</option>
            ))}
          </select>
        </div>
        <div className="col-md-3">
          <select className="form-select form-select-sm" value={filterPrinter} onChange={(e) => setFilterPrinter(e.target.value)}>
            <option value="semua">Semua Printer</option>
            {printers?.map((p) => (
              <option key={p.id} value={p.id}>{p.name}</option>
            ))}
          </select>
        </div>
        <div className="col-md-3">
          <select className="form-select form-select-sm" value={sortBy} onChange={(e) => setSortBy(e.target.value)}>
            <option value="terbaru">Terbaru</option>
            <option value="terlama">Terlama</option>
          </select>
        </div>
        <div className="col-md-3">
          <input
            className="form-control form-control-sm"
            placeholder="Cari nama / NIM"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      <div className="card border-0 shadow-sm" data-tour="request-list">
        <div className="table-responsive">
          <table className="table align-middle mb-0">
            <thead className="table-light">
              <tr>
                <th>Preview</th>
                <th>Nama</th>
                <th>NIM</th>
                <th>Tanggal</th>
                <th>Printer</th>
                <th>Estimasi</th>
                <th>Status</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              {!requests ? (
                <tr><td colSpan="8"><Loading /></td></tr>
              ) : filtered.length === 0 ? (
                <tr><td colSpan="8" className="text-center text-secondary py-4">Tidak ada data.</td></tr>
              ) : (
                filtered.map((r) => {
                  const thumb = getDriveThumbnail(r.linkScreenshot);
                  const printerName = printers?.find((p) => p.id === r.printerId)?.name || '-';
                  return (
                    <tr key={r.id}>
                      <td>
                        {thumb ? (
                          <img src={thumb} alt="preview" style={{ width: 48, height: 48, objectFit: 'cover', borderRadius: 6 }} />
                        ) : (
                          <span className="small text-secondary">-</span>
                        )}
                      </td>
                      <td className="small">{r.nama}</td>
                      <td className="small">{r.nim}</td>
                      <td className="small">{r.createdAt?.toDate?.().toLocaleDateString('id-ID') || '-'}</td>
                      <td className="small">{printerName}</td>
                      <td className="small">
                        {r.estimasiStatus === 'belum diketahui' ? (
                          <span className="text-warning">Belum diketahui</span>
                        ) : (
                          `${r.estimasiMenit || '-'} menit`
                        )}
                      </td>
                      <td><StatusBadge request={r} status={r.status} /></td>
                      <td>
                        <div className="d-flex gap-1">
                          <button className="btn btn-sm btn-outline-secondary" onClick={() => setDetailTarget(r)}>Detail</button>
                          {r.status === REQUEST_STATUS.MENUNGGU && (
                            <>
                              {!r.pricingVersion&&<button className="btn btn-sm btn-success" onClick={() => setAccTarget(r)}>ACC</button>}
                              <button className="btn btn-sm btn-danger" onClick={() => setRejectTarget(r)}>Tolak</button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {accTarget && printers && (
        <AccRequestModal
          request={accTarget}
          printers={printers}
          onCancel={() => setAccTarget(null)}
          onConfirm={handleAccConfirm}
        />
      )}
      {rejectTarget && (
        <RejectRequestModal
          request={rejectTarget}
          onCancel={() => setRejectTarget(null)}
          onConfirm={handleRejectConfirm}
        />
      )}
      {detailTarget && (
        <RequestDetailModal request={detailTarget} onClose={() => setDetailTarget(null)} />
      )}
    </AdminLayout>
  );
}

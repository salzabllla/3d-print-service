import { useEffect, useState } from 'react';
import Swal from 'sweetalert2';
import AdminLayout from '../../components/admin/AdminLayout';
import {
  subscribeToAllAdminRequests,
  approveAdminRequest,
  rejectAdminRequest,
  ADMIN_REQUEST_STATUS,
} from '../../services/adminRequestService';
import Loading from '../../components/common/Loading';

const STATUS_LABEL = {
  pending: 'Menunggu',
  approved: 'Disetujui',
  rejected: 'Ditolak',
};
const STATUS_VARIANT = {
  pending: 'warning',
  approved: 'success',
  rejected: 'danger',
};

export default function PermintaanAdminPage() {
  const [requests, setRequests] = useState(null);

  useEffect(() => {
    const unsub = subscribeToAllAdminRequests(setRequests);
    return unsub;
  }, []);

  const handleApprove = async (req) => {
    const confirm = await Swal.fire({
      title: `Setujui ${req.nama} sebagai ${req.peran}?`,
      text: 'Setelah disetujui, akun dibuat oleh PIC. Akun baru perlu memverifikasi email sebelum mengakses admin.',
      icon: 'question',
      showCancelButton: true,
      confirmButtonText: 'Ya, setujui',
      confirmButtonColor: '#005BAC',
    });
    if (!confirm.isConfirmed) return;
    await approveAdminRequest(req.id);
    Swal.fire('Disetujui', `${req.nama} sudah disetujui. PIC dapat membuat akun Firebase dengan email yang sama.`, 'success');
  };

  const handleReject = async (req) => {
    const { value: alasan } = await Swal.fire({
      title: `Tolak pengajuan ${req.nama}?`,
      input: 'textarea',
      inputLabel: 'Alasan penolakan (opsional)',
      showCancelButton: true,
      confirmButtonText: 'Tolak',
      confirmButtonColor: '#d33',
    });
    if (alasan === undefined) return;
    await rejectAdminRequest(req.id, alasan || '-');
    Swal.fire('Ditolak', 'Pengajuan sudah ditolak.', 'success');
  };

  return (
    <AdminLayout>
      <h4 className="fw-bold mb-1">Permintaan Admin</h4>
      <p className="text-secondary small mb-4">
        Daftar orang yang mengajukan akses admin melalui link pengajuan.
      </p>

      <div className="card border-0 shadow-sm">
        <div className="table-responsive">
          <table className="table align-middle mb-0">
            <thead className="table-light">
              <tr>
                <th>Nama</th>
                <th>Email</th>
                <th>Peran diajukan</th>
                <th>Status</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              {!requests ? (
                <tr><td colSpan="5"><Loading /></td></tr>
              ) : requests.length === 0 ? (
                <tr><td colSpan="5" className="text-center text-secondary py-4">Belum ada pengajuan.</td></tr>
              ) : (
                requests.map((r) => (
                  <tr key={r.id}>
                    <td className="small">{r.nama}</td>
                    <td className="small">{r.email}</td>
                    <td className="small">{r.peran}</td>
                    <td>
                      <span className={`badge bg-${STATUS_VARIANT[r.status]}-subtle text-${STATUS_VARIANT[r.status]}-emphasis border`}>
                        {STATUS_LABEL[r.status]}
                      </span>
                      {r.status === ADMIN_REQUEST_STATUS.APPROVED && (
                        <div className="small text-secondary mt-1">
                          {r.accountCreated ? 'Akun sudah dibuat' : 'Menunggu dibuat akunnya'}
                        </div>
                      )}
                      {r.status === ADMIN_REQUEST_STATUS.REJECTED && r.alasanPenolakan && r.alasanPenolakan !== '-' && (
                        <div className="small text-secondary mt-1">Alasan: {r.alasanPenolakan}</div>
                      )}
                    </td>
                    <td>
                      {r.status === ADMIN_REQUEST_STATUS.APPROVED&&<button className="btn btn-sm btn-outline-danger" onClick={()=>handleReject(r)}>Cabut Akses</button>}
                      {r.status === ADMIN_REQUEST_STATUS.PENDING && (
                        <div className="d-flex gap-1">
                          <button className="btn btn-sm btn-success" onClick={() => handleApprove(r)}>Setujui</button>
                          <button className="btn btn-sm btn-danger" onClick={() => handleReject(r)}>Tolak</button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </AdminLayout>
  );
}

import { useEffect, useMemo, useState } from 'react';
import AdminLayout from '../../components/admin/AdminLayout';
import StatusBadge from '../../components/common/StatusBadge';
import Loading from '../../components/common/Loading';
import { subscribeToRequestsByStatus } from '../../services/requestService';
import { subscribeToPrinters } from '../../services/printerService';
import { exportRiwayatToExcel, exportRiwayatToPdf } from '../../utils/exportRiwayat';
import { REQUEST_STATUS } from '../../utils/constants';

export default function RiwayatPage() {
  const [requests, setRequests] = useState(null);
  const [printers, setPrinters] = useState(null);
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('semua');
  const [filterPrinter, setFilterPrinter] = useState('semua');
  const [loadError, setLoadError] = useState(null);

  useEffect(() => {
    const unsub1 = subscribeToRequestsByStatus(
      [REQUEST_STATUS.SELESAI, REQUEST_STATUS.DITOLAK, REQUEST_STATUS.DIBATALKAN, REQUEST_STATUS.SEDANG_PRINT],
      (items) => {
        setRequests(items);
        setLoadError(null);
      },
      (err) => {
        console.error('Gagal memuat riwayat:', err);
        setLoadError(err.message || 'Terjadi kesalahan saat memuat data.');
      }
    );
    const unsub2 = subscribeToPrinters(setPrinters);
    return () => {
      unsub1();
      unsub2();
    };
  }, []);

  const filtered = useMemo(() => {
    if (!requests) return [];
    let items = [...requests];

    if (dateFrom) {
      items = items.filter((r) => r.createdAt?.toDate?.() >= new Date(dateFrom));
    }
    if (dateTo) {
      const end = new Date(dateTo);
      end.setHours(23, 59, 59, 999);
      items = items.filter((r) => r.createdAt?.toDate?.() <= end);
    }
    if (search.trim()) {
      const q = search.trim().toLowerCase();
      items = items.filter((r) => r.nama?.toLowerCase().includes(q) || r.nim?.toLowerCase().includes(q));
    }
    if (filterStatus !== 'semua') {
      items = items.filter((r) => r.status === filterStatus);
    }
    if (filterPrinter !== 'semua') {
      items = items.filter((r) => r.printerId === filterPrinter);
    }
    return items;
  }, [requests, dateFrom, dateTo, search, filterStatus, filterPrinter]);

  return (
    <AdminLayout>
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h4 className="fw-bold mb-0">Riwayat</h4>
        <div className="d-flex gap-2">
          <button className="btn btn-sm btn-outline-secondary" onClick={() => exportRiwayatToExcel(filtered, printers || [])}>
            Export Excel
          </button>
          <button className="btn btn-sm btn-outline-secondary" onClick={() => exportRiwayatToPdf(filtered, printers || [])}>
            Export PDF
          </button>
        </div>
      </div>

      <div className="row g-2 mb-3">
        <div className="col-md-2">
          <input type="date" className="form-control form-control-sm" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} />
        </div>
        <div className="col-md-2">
          <input type="date" className="form-control form-control-sm" value={dateTo} onChange={(e) => setDateTo(e.target.value)} />
        </div>
        <div className="col-md-2">
          <select className="form-select form-select-sm" value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)}>
            <option value="semua">Semua Status</option>
            <option value={REQUEST_STATUS.SEDANG_PRINT}>Sedang print</option>
            <option value={REQUEST_STATUS.SELESAI}>Selesai</option>
            <option value={REQUEST_STATUS.DITOLAK}>Ditolak</option>
            <option value={REQUEST_STATUS.DIBATALKAN}>Dibatalkan</option>
          </select>
        </div>
        <div className="col-md-2">
          <select className="form-select form-select-sm" value={filterPrinter} onChange={(e) => setFilterPrinter(e.target.value)}>
            <option value="semua">Semua Printer</option>
            {printers?.map((p) => (
              <option key={p.id} value={p.id}>{p.name}</option>
            ))}
          </select>
        </div>
        <div className="col-md-4">
          <input className="form-control form-control-sm" placeholder="Cari nama atau NIM" value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
      </div>

      <div className="card border-0 shadow-sm">
        <div className="table-responsive">
          <table className="table align-middle mb-0">
            <thead className="table-light">
              <tr>
                <th>Tanggal</th>
                <th>Nama</th>
                <th>NIM</th>
                <th>Printer</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {loadError ? (
                <tr>
                  <td colSpan="5" className="text-center text-danger py-4">
                    Gagal memuat data: {loadError}
                  </td>
                </tr>
              ) : !requests ? (
                <tr><td colSpan="5"><Loading /></td></tr>
              ) : filtered.length === 0 ? (
                <tr><td colSpan="5" className="text-center text-secondary py-4">Tidak ada data.</td></tr>
              ) : (
                filtered.map((r) => (
                  <tr key={r.id}>
                    <td className="small">{r.createdAt?.toDate?.().toLocaleDateString('id-ID') || '-'}</td>
                    <td className="small">{r.nama}</td>
                    <td className="small">{r.nim}</td>
                    <td className="small">{printers?.find((p) => p.id === r.printerId)?.name || '-'}</td>
                    <td><StatusBadge request={r} status={r.status} /></td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </AdminLayout>
  );
}

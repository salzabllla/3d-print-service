import { useState } from 'react';
import Swal from 'sweetalert2';
import AdminLayout from '../../components/admin/AdminLayout';
import { useAuth } from '../../context/AuthContext';
import { changePassword, changeEmail } from '../../services/authService';

export default function ProfilPage() {
  const { currentUser } = useAuth();

  const [currentPasswordPw, setCurrentPasswordPw] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [savingPw, setSavingPw] = useState(false);

  const [currentPasswordEmail, setCurrentPasswordEmail] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [savingEmail, setSavingEmail] = useState(false);

  const handleChangePassword = async (e) => {
    e.preventDefault();

    if (newPassword.length < 6) {
      Swal.fire('Password terlalu pendek', 'Minimal 6 karakter.', 'warning');
      return;
    }

    if (newPassword !== confirmPassword) {
      Swal.fire(
        'Password tidak cocok',
        'Konfirmasi password baru harus sama.',
        'warning'
      );
      return;
    }

    setSavingPw(true);

    try {
      await changePassword(currentPasswordPw, newPassword);

      Swal.fire('Berhasil', 'Password berhasil diperbarui.', 'success');

      setCurrentPasswordPw('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (err) {
      let message = 'Terjadi kesalahan.';

      if (
        err.code === 'auth/wrong-password' ||
        err.code === 'auth/invalid-credential'
      ) {
        message = 'Password lama salah.';
      } else if (err.message) {
        message = err.message;
      }

      Swal.fire('Gagal', message, 'error');
    } finally {
      setSavingPw(false);
    }
  };

  const handleChangeEmail = async (e) => {
    e.preventDefault();

    setSavingEmail(true);

    try {
      await changeEmail(currentPasswordEmail, newEmail);

      Swal.fire(
        'Berhasil',
        `Link verifikasi telah dikirim ke ${newEmail}. Silakan cek inbox dan klik link tersebut untuk mengaktifkan email baru.`,
        'success'
      );

      setCurrentPasswordEmail('');
      setNewEmail('');
    } catch (err) {
      let message = 'Terjadi kesalahan.';

      if (
        err.code === 'auth/wrong-password' ||
        err.code === 'auth/invalid-credential'
      ) {
        message = 'Password yang dimasukkan salah.';
      } else if (err.code === 'auth/email-already-in-use') {
        message = 'Email tersebut sudah digunakan akun lain.';
      } else if (err.message) {
        message = err.message;
      }

      Swal.fire('Gagal', message, 'error');
    } finally {
      setSavingEmail(false);
    }
  };

  return (
    <AdminLayout>
      <h4 className="fw-bold mb-1">Profil Saya</h4>
      <p className="text-secondary small mb-4">
        Kelola email dan password akun admin.
      </p>

      <div className="card border-0 shadow-sm mb-4">
        <div className="card-body p-4">
          <h6 className="fw-bold mb-2">Email Saat Ini</h6>
          <p className="mb-0">{currentUser?.email}</p>
        </div>
      </div>

      <div className="row g-4">
        <div className="col-lg-6">
          <div className="card border-0 shadow-sm h-100">
            <div className="card-body p-4">
              <h6 className="fw-bold mb-3">Ganti Password</h6>

              <form onSubmit={handleChangePassword}>
                <div className="mb-3">
                  <label className="form-label">Password Lama</label>
                  <input
                    type="password"
                    className="form-control"
                    value={currentPasswordPw}
                    onChange={(e) => setCurrentPasswordPw(e.target.value)}
                    required
                  />
                </div>

                <div className="mb-3">
                  <label className="form-label">Password Baru</label>
                  <input
                    type="password"
                    className="form-control"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    minLength={6}
                    required
                  />
                </div>

                <div className="mb-3">
                  <label className="form-label">
                    Konfirmasi Password Baru
                  </label>
                  <input
                    type="password"
                    className="form-control"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    minLength={6}
                    required
                  />
                </div>

                <button
                  type="submit"
                  className="btn text-white"
                  style={{ backgroundColor: '#005BAC' }}
                  disabled={savingPw}
                >
                  {savingPw ? 'Menyimpan...' : 'Simpan Password'}
                </button>
              </form>
            </div>
          </div>
        </div>

        <div className="col-lg-6">
          <div className="card border-0 shadow-sm h-100">
            <div className="card-body p-4">
              <h6 className="fw-bold mb-3">Ganti Email</h6>

              <p className="small text-secondary">
                Link verifikasi akan dikirim ke email baru. Email login akan
                berubah setelah link tersebut diklik.
              </p>

              <form onSubmit={handleChangeEmail}>
                <div className="mb-3">
                  <label className="form-label">Email Baru</label>
                  <input
                    type="email"
                    className="form-control"
                    value={newEmail}
                    onChange={(e) => setNewEmail(e.target.value)}
                    required
                  />
                </div>

                <div className="mb-3">
                  <label className="form-label">Password Saat Ini</label>
                  <input
                    type="password"
                    className="form-control"
                    value={currentPasswordEmail}
                    onChange={(e) =>
                      setCurrentPasswordEmail(e.target.value)
                    }
                    required
                  />
                </div>

                <button
                  type="submit"
                  className="btn text-white"
                  style={{ backgroundColor: '#005BAC' }}
                  disabled={savingEmail}
                >
                  {savingEmail ? 'Mengirim...' : 'Kirim Link Verifikasi'}
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}
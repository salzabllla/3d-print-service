import { useEffect, useState } from 'react';
import { lecturerReference } from '../../data/lecturers';
import Swal from 'sweetalert2';
import AdminLayout from '../../components/admin/AdminLayout';
import { getSettings, updateSettings } from '../../services/settingsService';

const emptyPics = [
  { name: '', whatsapp: '' },
  { name: '', whatsapp: '' },
];

export default function PengaturanPage() {
  const [pics, setPics] = useState(emptyPics);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [lecturers,setLecturers]=useState([]);
  const [lecturerText,setLecturerText]=useState('');

  useEffect(() => {
    (async () => {
      try {
      const data = await getSettings();
      if (data?.pics?.length) {
        setPics(data.pics);
      }
      if(data?.lecturers){setLecturers(data.lecturers);setLecturerText(data.lecturers.map(d=>d.name).join('\n'));}
      } catch(error) { Swal.fire('Gagal memuat pengaturan',error.message,'error'); } finally { setLoading(false); }
    })();
  }, []);

  const handlePicChange = (index, field, value) => {
    setPics((prev) =>
      prev.map((p, i) => (i === index ? { ...p, [field]: value } : p))
    );
  };

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const names=[...new Set(lecturerText.split('\n').map(n=>n.trim()).filter(Boolean))];
      const list=names.map(name=>lecturers.find(d=>d.name===name)||{id:crypto.randomUUID(),name});
      await updateSettings({ pics, lecturers:list, lecturerNames:Object.fromEntries(list.map(d=>[d.id,d.name])) });
      setLecturers(list);
      Swal.fire('Tersimpan', 'Pengaturan berhasil diperbarui.', 'success');
    } catch (err) {
      Swal.fire('Gagal', err.message, 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <AdminLayout>
      <h4 className="fw-bold mb-4">Pengaturan</h4>

      {loading ? (
        <p className="text-secondary small">Memuat...</p>
      ) : (
        <div className="card border-0 shadow-sm" style={{ maxWidth: 560 }}>
          <div className="card-body">
            <h6 className="fw-bold mb-3">Kontak PIC Sistem</h6>
            <p className="small text-secondary mb-3">
              Kedua PIC akan ditampilkan di footer dan sebagai pilihan konfirmasi WhatsApp setelah user mengirim pengajuan.
            </p>
            <form onSubmit={handleSave}>
              {pics.map((pic, i) => (
                <div key={i} className="mb-4 pb-3 border-bottom">
                  <h6 className="small fw-bold text-secondary mb-2">PIC {i + 1}</h6>
                  <div className="mb-3">
                    <label className="form-label small">Nama PIC</label>
                    <input
                      className="form-control"
                      value={pic.name}
                      onChange={(e) => handlePicChange(i, 'name', e.target.value)}
                    />
                  </div>
                  <div className="mb-0">
                    <label className="form-label small">Nomor WhatsApp (format 62xxxxxxxxxx)</label>
                    <input
                      className="form-control"
                      value={pic.whatsapp}
                      onChange={(e) => handlePicChange(i, 'whatsapp', e.target.value)}
                    />
                  </div>
                </div>
              ))}
              <h6 className="fw-bold">Daftar Dosen Pembimbing / Pengampu</h6>
              <label className="form-label small" htmlFor="lecturer-list">Satu nama lengkap per baris</label>
              <button type="button" className="btn btn-sm btn-outline-primary d-block mb-2" onClick={()=>{const combined=[...lecturers,...lecturerReference.filter(d=>!lecturers.some(old=>old.name===d.name))];setLecturers(combined);setLecturerText([...new Set([...lecturerText.split('\n').filter(Boolean),...lecturerReference.map(d=>d.name)])].join('\n'));}}>Tambahkan daftar referensi 3D Print Service</button><textarea id="lecturer-list" rows="8" className="form-control mb-2" value={lecturerText} onChange={e=>setLecturerText(e.target.value)} />
              <p className="small text-secondary">Daftar ini menjadi pilihan resmi pada form. Nama pada pengajuan lama tetap disimpan sesuai saat diajukan.</p>
              <button type="submit" className="btn text-white" style={{ background: '#005BAC' }} disabled={saving}>
                {saving ? 'Menyimpan...' : 'Simpan Perubahan'}
              </button>
            </form>
          </div>
        </div>
      )}
    </AdminLayout>
  );
}

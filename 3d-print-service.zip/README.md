# 3D Print Service

Project website untuk pengajuan dan pengelolaan antrean cetak 3D.

## Fitur

1. Formulir pengajuan dan tautan file.
2. Penentuan biaya serta antrean cetak.
3. Status pesanan dan invoice.

## Cara kerja

Pengguna mengirim pengajuan. Admin memeriksa file dan mengatur biaya serta antrean.

Siapkan konfigurasi demo untuk menjalankan salinan portofolio ini.
